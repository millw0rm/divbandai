import type { Metadata } from "next";
import { Vazirmatn, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const vazirmatn = Vazirmatn({
  subsets: ["arabic", "latin"],
  weight: ["300", "400", "500", "600", "700", "800"],
  variable: "--font-sans",
  display: "swap",
});

const jetbrains = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["400", "500"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Divband Studio — استودیو راهکارهای هوش مصنوعی",
  description:
    "از چت‌بات و گرافِ دانش تا یادگیریِ ماشینی و اینترنتِ اشیا — دیوبند سامانه‌های هوشمند را برای کسب‌وکارهای جدی طراحی و مستقر می‌کند.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fa" dir="rtl" className={`${vazirmatn.variable} ${jetbrains.variable}`}>
      <body>{children}</body>
    </html>
  );
}
