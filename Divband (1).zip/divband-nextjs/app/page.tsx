import Nav from "@/components/Nav";
import Hero from "@/components/Hero";
import Services from "@/components/Services";
import Demo from "@/components/Demo";
import Stats from "@/components/Stats";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

export default function Page() {
  return (
    <main className="site site-a" dir="rtl">
      <Nav />
      <Hero />
      <Services />
      <Demo />
      <Stats />
      <Contact />
      <Footer />
    </main>
  );
}
