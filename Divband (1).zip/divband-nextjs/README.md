# Divband Studio — Next.js

وب‌سایت استودیو دیوبند با Next.js 14 (App Router) + TypeScript.

## ساختار

```
app/
  layout.tsx          — RTL shell, Vazirmatn font, viewer chrome
  page.tsx            — صفحه‌ی اصلی (مونتاژ بخش‌ها)
  globals.css         — همه‌ی استایل‌ها (توکن‌ها + بخش‌ها)
  api/chat/route.ts   — endpoint سرور برای چت با Claude
components/
  Nav.tsx
  Hero.tsx            — server-side markup + کلاینت‌کامپوننت کنوس
  HeroCanvas.tsx      — انیمیشن شبکه‌ی گره‌ها (Canvas API)
  Services.tsx
  Demo.tsx            — چت لایو
  AIChat.tsx          — کلاینت‌کامپوننت چت
  Stats.tsx
  Contact.tsx
  Footer.tsx
lib/
  data.ts             — لیست خدمات و آمار
```

## اجرا

۱. کلیدِ API را تنظیم کنید:

```bash
cp .env.example .env.local
# سپس ANTHROPIC_API_KEY را در .env.local قرار دهید
```

۲. نصب وابستگی‌ها و اجرا:

```bash
npm install
npm run dev
```

سپس به <http://localhost:3000> بروید.

## دیپلوی

این پروژه روی Vercel آماده است:

```bash
vercel
```

فقط در محیطِ پروژه‌ی Vercel متغیرِ `ANTHROPIC_API_KEY` را اضافه کنید.

## نکات فنی

- **چت AI** از API سرور (`/api/chat`) به Anthropic می‌زند، نه از مرورگر. کلید روی سرور می‌ماند.
- **انیمیشنِ هیرو** یک Canvas کلاینتی است؛ گره‌ها به نشانگر ماوس کشیده می‌شوند و در شعاع مشخصی به چرخش درمی‌آیند.
- **فونت**: Vazirmatn از Google Fonts با `next/font` لود می‌شود.
- **RTL** در `<html dir="rtl" lang="fa">` تعریف شده.
