export default function Nav() {
  return (
    <nav className="navA">
      <div className="brand">
        <span className="brand-mark">◇</span>
        <span className="brand-word">
          DIVBAND<span className="brand-sub">/studio</span>
        </span>
      </div>
      <ul className="nav-links">
        <li>خانه</li>
        <li>خدمات</li>
        <li>دموی هوشمند</li>
        <li>درباره ما</li>
        <li>تماس</li>
      </ul>
      <a className="nav-cta" href="#contact">گفت‌وگو با ما ←</a>
    </nav>
  );
}
