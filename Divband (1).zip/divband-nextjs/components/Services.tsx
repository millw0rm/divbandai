import { SERVICES } from "@/lib/data";

export default function Services() {
  return (
    <>
      <section className="section-headA" id="services">
        <div className="sh-left">
          <span className="sh-num">/ ۰۱</span>
          <span className="sh-en">SERVICES</span>
        </div>
        <h2>
          هفت حوزه‌ی تخصصی،
          <br />
          یک تیمِ یکپارچه.
        </h2>
        <div className="sh-right">
          هر راهکار با نقطه‌ی صفر شروع می‌شود: مصاحبه‌ی فنی، ممیزیِ داده و
          طراحیِ معماری. سپس می‌سازیم، آموزش می‌دهیم، مستقر می‌کنیم.
        </div>
      </section>

      <section className="servicesA">
        {SERVICES.map((s) => (
          <article key={s.num} className="svc">
            <div className="svc-top">
              <span className="svc-num">{s.num}</span>
              <span className="svc-en">{s.en}</span>
            </div>
            <h3>{s.fa}</h3>
            <p>{s.desc}</p>
            <div className="svc-arrow">←</div>
          </article>
        ))}
      </section>
    </>
  );
}
