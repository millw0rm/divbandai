"use client";

import { useEffect, useRef } from "react";

type Pt = { x: number; y: number; vx: number; vy: number; r: number };

export default function HeroCanvas() {
  const ref = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Resize canvas buffer to its element size (handles responsive width).
    function resize() {
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      canvas.width = Math.max(1, Math.floor(rect.width));
      canvas.height = Math.max(1, Math.floor(rect.height));
    }
    resize();

    // Node field
    const N = 90;
    const pts: Pt[] = Array.from({ length: N }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      vx: (Math.random() - 0.5) * 0.35,
      vy: (Math.random() - 0.5) * 0.35,
      r: Math.random() < 0.18 ? 3.6 : 2.0,
    }));

    const MESH_R = 175;
    const ATTRACT_R = 240;
    const ATTRACT_STR = 0.18;
    const CAPTURE_R = 70;

    const mouse = { x: -9999, y: -9999, active: false };

    function onMove(e: MouseEvent) {
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const sx = canvas.width / rect.width;
      const sy = canvas.height / rect.height;
      mouse.x = (e.clientX - rect.left) * sx;
      mouse.y = (e.clientY - rect.top) * sy;
      mouse.active = true;
    }
    function onLeave() { mouse.active = false; }

    canvas.addEventListener("mousemove", onMove);
    canvas.addEventListener("mouseleave", onLeave);
    window.addEventListener("resize", resize);

    let raf = 0;
    let last = 0;
    let visible = true;
    let io: IntersectionObserver | null = null;
    if (typeof IntersectionObserver !== "undefined") {
      visible = false;
      io = new IntersectionObserver(
        (es) => { visible = es[0]?.isIntersecting ?? false; },
        { threshold: 0.01 }
      );
      io.observe(canvas);
    }

    function step() {
      for (const p of pts) {
        if (mouse.active) {
          const dx = mouse.x - p.x;
          const dy = mouse.y - p.y;
          const d = Math.hypot(dx, dy) || 0.0001;

          if (d < CAPTURE_R) {
            const target = CAPTURE_R * 0.55;
            const pull = (d - target) * 0.06;
            p.vx += (dx / d) * pull;
            p.vy += (dy / d) * pull;
            p.vx += (-dy / d) * 0.35;
            p.vy += (dx / d) * 0.35;
          } else if (d < ATTRACT_R) {
            const strength = (1 - d / ATTRACT_R) * ATTRACT_STR;
            p.vx += (dx / d) * strength;
            p.vy += (dy / d) * strength;
          }
        }

        p.vx *= 0.93;
        p.vy *= 0.93;

        const sp = Math.hypot(p.vx, p.vy);
        if (sp > 3.5) {
          p.vx = (p.vx / sp) * 3.5;
          p.vy = (p.vy / sp) * 3.5;
        }
        if (sp < 0.12) {
          p.vx += (Math.random() - 0.5) * 0.05;
          p.vy += (Math.random() - 0.5) * 0.05;
        }

        p.x += p.vx;
        p.y += p.vy;

        if (!canvas) continue;
        if (p.x < 0) { p.x = 0; p.vx = Math.abs(p.vx); }
        if (p.x > canvas.width) { p.x = canvas.width; p.vx = -Math.abs(p.vx); }
        if (p.y < 0) { p.y = 0; p.vy = Math.abs(p.vy); }
        if (p.y > canvas.height) { p.y = canvas.height; p.vy = -Math.abs(p.vy); }
      }
    }

    function draw() {
      if (!ctx || !canvas) return;
      const W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);

      ctx.lineWidth = 0.7;
      for (let i = 0; i < pts.length; i++) {
        for (let j = i + 1; j < pts.length; j++) {
          const dx = pts[i].x - pts[j].x;
          const dy = pts[i].y - pts[j].y;
          const d = Math.hypot(dx, dy);
          if (d < MESH_R) {
            const a = (1 - d / MESH_R) * 0.55;
            ctx.strokeStyle = `rgba(15,23,42,${a})`;
            ctx.beginPath();
            ctx.moveTo(pts[i].x, pts[i].y);
            ctx.lineTo(pts[j].x, pts[j].y);
            ctx.stroke();
          }
        }
      }

      if (mouse.active) {
        ctx.beginPath();
        ctx.fillStyle = "rgba(30,58,138,0.05)";
        ctx.arc(mouse.x, mouse.y, ATTRACT_R, 0, Math.PI * 2);
        ctx.fill();

        ctx.beginPath();
        ctx.strokeStyle = "rgba(30,58,138,0.25)";
        ctx.lineWidth = 1;
        ctx.setLineDash([4, 6]);
        ctx.arc(mouse.x, mouse.y, CAPTURE_R, 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([]);

        ctx.lineWidth = 1;
        for (const p of pts) {
          const dx = mouse.x - p.x, dy = mouse.y - p.y;
          const d = Math.hypot(dx, dy);
          if (d < ATTRACT_R) {
            const a = (1 - d / ATTRACT_R) * 0.85;
            ctx.strokeStyle = `rgba(30,58,138,${a})`;
            ctx.beginPath();
            ctx.moveTo(mouse.x, mouse.y);
            ctx.lineTo(p.x, p.y);
            ctx.stroke();
          }
        }

        ctx.beginPath();
        ctx.fillStyle = "#1e3a8a";
        ctx.arc(mouse.x, mouse.y, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.strokeStyle = "rgba(30,58,138,0.4)";
        ctx.lineWidth = 1.5;
        ctx.arc(mouse.x, mouse.y, 10, 0, Math.PI * 2);
        ctx.stroke();
      }

      for (const p of pts) {
        const accent = p.r > 2.5;
        if (accent) {
          ctx.beginPath();
          ctx.fillStyle = "rgba(30,58,138,0.10)";
          ctx.arc(p.x, p.y, p.r * 4, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.beginPath();
        ctx.fillStyle = accent ? "#1e3a8a" : "#0a0f1f";
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    function frame(now: number) {
      raf = requestAnimationFrame(frame);
      if (!visible) { last = now; return; }
      if (now - last < 33) return;
      last = now;
      step();
      draw();
    }
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      canvas.removeEventListener("mousemove", onMove);
      canvas.removeEventListener("mouseleave", onLeave);
      window.removeEventListener("resize", resize);
      io?.disconnect();
    };
  }, []);

  return <canvas ref={ref} style={{ width: "100%", height: "100%", display: "block", cursor: "crosshair" }} />;
}
