import AIChat from "./AIChat";

export default function Demo() {
  return (
    <section className="demoA" id="demo">
      <div className="demo-left">
        <span className="sh-num">/ ۰۲</span>
        <span className="sh-en">LIVE DEMO</span>
        <h2>
          با دستیارِ ما
          <br />
          گفت‌وگو کنید.
        </h2>
        <p>
          این دستیار با همان معماری‌ای ساخته شده که در پروژه‌های مشتریان دیوبند
          به‌کار می‌رود: مدل زبانی، گراف دانشِ دامنه و یک لایه‌ی کنترلی برای
          محدودسازی پاسخ‌ها.
        </p>
        <ul className="demo-feat">
          <li>پاسخ‌ به زبان فارسی و انگلیسی</li>
          <li>کنترل دامنه و پایداری</li>
          <li>قابل استقرار on-prem</li>
        </ul>
      </div>
      <div className="demo-right">
        <AIChat />
      </div>
    </section>
  );
}
