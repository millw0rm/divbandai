export default function Contact() {
  return (
    <section className="contactA" id="contact">
      <div className="contact-left">
        <span className="sh-num">/ ۰۳</span>
        <span className="sh-en">CONTACT</span>
        <h2>پروژه‌ای در ذهن دارید؟</h2>
        <p>
          یک پیام بفرستید؛ ظرف ۲۴ ساعت پاسخ می‌دهیم و جلسه‌ی فنیِ رایگان ترتیب
          می‌دهیم.
        </p>
        <div className="contact-fields">
          <div className="cf">
            <span className="cf-label">ایمیل</span>
            <span className="cf-value ltr">support@divband.com</span>
          </div>
          <div className="cf">
            <span className="cf-label">تلفن</span>
            <span className="cf-value ltr">۰۹۱۷۴۱۶۱۹۵۷</span>
          </div>
          <div className="cf">
            <span className="cf-label">ساعات کاری</span>
            <span className="cf-value">شنبه تا چهارشنبه — ۹ تا ۱۸</span>
          </div>
        </div>
      </div>

      <form
        className="contact-form"
        onSubmit={(e) => {
          e.preventDefault();
          alert("پیام شما ثبت شد. در اولین فرصت پاسخ می‌دهیم.");
        }}
      >
        <label>
          نام و نام خانوادگی
          <input type="text" placeholder="مثلاً علی محمدی" />
        </label>
        <label>
          سازمان
          <input type="text" placeholder="نام شرکت یا کسب‌وکار" />
        </label>
        <label>
          ایمیل
          <input type="email" placeholder="you@company.com" dir="ltr" />
        </label>
        <label>
          شرح پروژه
          <textarea rows={4} placeholder="در یک پاراگراف توضیح دهید…" />
        </label>
        <button type="submit">ارسال پیام ←</button>
      </form>
    </section>
  );
}
