export default function Footer() {
  return (
    <footer className="footerA">
      <div className="brand">
        <span className="brand-mark">◇</span>
        <span className="brand-word">
          DIVBAND<span className="brand-sub">/studio</span>
        </span>
      </div>
      <div>© ۱۴۰۳ دیوبند استودیو — همه‌ی حقوق محفوظ است.</div>
      <div className="ltr">support@divband.com · 0917-416-1957</div>
    </footer>
  );
}
