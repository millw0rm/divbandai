import HeroCanvas from "./HeroCanvas";

export default function Hero() {
  return (
    <section className="heroA">
      <div className="hero-canvas">
        <HeroCanvas />
      </div>
      <div className="hero-grid-overlay" />
      <div className="hero-inner">
        <div className="hero-meta">
          <span className="meta-dot" />
          <span>استودیو راهکارهای هوش مصنوعی</span>
          <span className="meta-sep" />
          <span>تأسیس ۱۴۰۲</span>
        </div>

        <h1 className="hero-title">
          <span>هوشِ مصنوعی،</span>
          <span>در مقیاسِ</span>
          <span className="accent">صنعتِ شما.</span>
        </h1>

        <p className="hero-sub">
          از چت‌بات و گرافِ دانش تا یادگیریِ ماشینی و اینترنتِ اشیا — دیوبند
          سامانه‌های هوشمند را برای کسب‌وکارهای جدی طراحی و مستقر می‌کند.
        </p>

        <div className="hero-cta-row">
          <a className="btn-primary" href="#contact">شروع پروژه</a>
          <a className="btn-ghost" href="#services">مشاهده‌ی خدمات ↓</a>
        </div>

        <div className="hero-foot">
          <div><b>SOC2</b><span>پایش امنیتی</span></div>
          <div><b>on-prem</b><span>استقرار داخلی</span></div>
          <div><b>فارسی + EN</b><span>دومدلی</span></div>
          <div><b>۲۴/۷</b><span>پشتیبانی</span></div>
        </div>
      </div>
    </section>
  );
}
