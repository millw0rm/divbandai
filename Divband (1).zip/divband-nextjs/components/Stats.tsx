import { STATS } from "@/lib/data";

export default function Stats() {
  return (
    <section className="statsA">
      {STATS.map((s) => (
        <div key={s.label} className="stat">
          <div className="stat-n">{s.n}</div>
          <div className="stat-l">{s.label}</div>
        </div>
      ))}
    </section>
  );
}
