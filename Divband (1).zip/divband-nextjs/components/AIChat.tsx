"use client";

import { useEffect, useRef, useState } from "react";
import { SUGGESTED_PROMPTS } from "@/lib/data";

type Msg = { role: "user" | "assistant"; text: string };

export default function AIChat() {
  const [msgs, setMsgs] = useState<Msg[]>([
    {
      role: "assistant",
      text: "سلام! من دستیارِ هوشمندِ دیوبند هستم. درباره‌ی چه راهکاری می‌خواهید بدانید؟",
    },
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const bodyRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (bodyRef.current) bodyRef.current.scrollTop = bodyRef.current.scrollHeight;
  }, [msgs, busy]);

  async function ask(text: string) {
    const t = text.trim();
    if (!t || busy) return;
    setInput("");
    const next: Msg[] = [...msgs, { role: "user", text: t }];
    setMsgs(next);
    setBusy(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: next.slice(-6).map((m) => ({ role: m.role, content: m.text })),
        }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setMsgs((m) => [...m, { role: "assistant", text: data.reply ?? "" }]);
    } catch {
      setMsgs((m) => [
        ...m,
        { role: "assistant", text: "متأسفم، در پاسخ‌دهی خطایی رخ داد. لطفاً دوباره تلاش کنید." },
      ]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="aichat">
      <div className="aichat-head">
        <span className="aichat-dot" />
        <span className="aichat-title">divband.assistant</span>
        <span className="aichat-status">{busy ? "در حال تفکر…" : "آنلاین"}</span>
      </div>

      <div className="aichat-body" ref={bodyRef}>
        {msgs.map((m, i) => (
          <div key={i} className={`aichat-msg ${m.role}`}>
            <div className="bubble">{m.text}</div>
          </div>
        ))}
        {busy && (
          <div className="aichat-msg assistant">
            <div className="bubble typing">
              <span />
              <span />
              <span />
            </div>
          </div>
        )}
      </div>

      <div className="aichat-suggest">
        {SUGGESTED_PROMPTS.map((s) => (
          <button key={s} onClick={() => ask(s)} disabled={busy}>
            {s}
          </button>
        ))}
      </div>

      <form
        className="aichat-input"
        onSubmit={(e) => {
          e.preventDefault();
          ask(input);
        }}
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="پیامتان را بنویسید…"
          disabled={busy}
        />
        <button type="submit" disabled={busy || !input.trim()}>
          ارسال ↵
        </button>
      </form>
    </div>
  );
}
