"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams, useRouter, usePathname } from "next/navigation";
import { signOut, useSession } from "next-auth/react";

type Conv = {
  id: string; title: string;
  provider: string; model: string;
  updatedAt: string;
};

export default function Sidebar() {
  const { data: session } = useSession();
  const router = useRouter();
  const pathname = usePathname();
  const params = useParams() as { id?: string };

  const [convs, setConvs] = useState<Conv[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const r = await fetch("/api/conversations");
    if (r.ok) {
      const d = await r.json();
      setConvs(d.conversations);
    }
    setLoading(false);
  }
  useEffect(() => { load(); }, [pathname]);

  async function remove(id: string) {
    if (!confirm("این گفت‌وگو حذف شود؟")) return;
    await fetch(`/api/conversations/${id}`, { method: "DELETE" });
    setConvs((c) => c.filter((x) => x.id !== id));
    if (params.id === id) router.push("/chat");
  }

  return (
    <aside className="sidebar">
      <div className="sidebar-head">
        <Link href="/chat" className="sidebar-brand" style={{ textDecoration: "none", color: "inherit" }}>
          <span className="mark">◇</span>
          <div>
            <div className="word">DIVBAND<span className="sub">/chat</span></div>
          </div>
        </Link>
      </div>

      <button className="new-conv-btn" onClick={() => router.push("/chat")}>
        + گفت‌وگوی جدید
      </button>

      <div className="conv-list">
        {loading && <div className="conv-item" style={{ opacity: 0.5 }}>در حال بارگذاری…</div>}
        {!loading && convs.length === 0 && (
          <div className="conv-item" style={{ opacity: 0.6 }}>هنوز گفت‌وگویی نیست.</div>
        )}
        {convs.map((c) => (
          <Link
            key={c.id}
            href={`/chat/${c.id}`}
            className={`conv-item ${params.id === c.id ? "active" : ""}`}
          >
            <span className="title">{c.title}</span>
            <span className="meta">{c.provider} · {c.model}</span>
            <button
              className="del"
              onClick={(e) => { e.preventDefault(); e.stopPropagation(); remove(c.id); }}
              title="حذف"
              aria-label="حذف"
            >×</button>
          </Link>
        ))}
      </div>

      <div className="sidebar-foot">
        <div className="user-chip">
          <div className="name">{session?.user?.name || "کاربر"}</div>
          <div className="email">{session?.user?.email}</div>
        </div>
        <button
          className="icon-btn"
          onClick={() => signOut({ callbackUrl: "/login" })}
          title="خروج"
          aria-label="خروج"
        >→</button>
      </div>
    </aside>
  );
}
