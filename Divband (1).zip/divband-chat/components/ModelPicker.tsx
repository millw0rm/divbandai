"use client";

import type { Provider } from "@/lib/providers";

type Props = {
  providers: Provider[];
  provider: string;
  model: string;
  onChange: (p: string, m: string) => void;
};

export default function ModelPicker({ providers, provider, model, onChange }: Props) {
  const current = providers.find((p) => p.id === provider) ?? providers[0];
  return (
    <div className="model-picker" title="انتخاب مدل">
      <select
        value={provider}
        onChange={(e) => {
          const next = providers.find((p) => p.id === e.target.value)!;
          onChange(next.id, next.models[0].id);
        }}
      >
        {providers.map((p) => (
          <option key={p.id} value={p.id}>{p.label}</option>
        ))}
      </select>
      <span>·</span>
      <select value={model} onChange={(e) => onChange(provider, e.target.value)}>
        {current.models.map((m) => (
          <option key={m.id} value={m.id}>{m.label}</option>
        ))}
      </select>
    </div>
  );
}
