"use client";

import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeHighlight from "rehype-highlight";

export type Attachment = { name: string; type?: string; size?: number; excerpt?: string };
export type Msg = {
  id?: string;
  role: "user" | "assistant" | "system";
  content: string;
  provider?: string;
  model?: string;
  attachments?: Attachment[];
};

export default function Message({ m, streaming }: { m: Msg; streaming?: boolean }) {
  const isUser = m.role === "user";
  return (
    <div className={`msg ${m.role}`}>
      <div className="avatar">{isUser ? "شما" : "AI"}</div>
      <div>
        <div className="meta-line">
          {isUser ? <span>پیامِ شما</span> : <span>{m.model || m.provider || "دستیار"}</span>}
        </div>
        {m.attachments && m.attachments.length > 0 && (
          <div className="attach-chips">
            {m.attachments.map((a, i) => (
              <span key={i} className="attach-chip">📎 {a.name}</span>
            ))}
          </div>
        )}
        <div className="body">
          {isUser ? (
            <p style={{ whiteSpace: "pre-wrap" }}>{m.content}</p>
          ) : streaming && !m.content ? (
            <div className="dot-typing"><span /><span /><span /></div>
          ) : (
            <ReactMarkdown
              remarkPlugins={[remarkGfm]}
              rehypePlugins={[rehypeHighlight]}
              components={{
                a: ({ href, children }) => <a href={href} target="_blank" rel="noreferrer">{children}</a>,
              }}
            >
              {m.content}
            </ReactMarkdown>
          )}
        </div>
      </div>
    </div>
  );
}
