"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import type { Provider } from "@/lib/providers";
import Message, { type Attachment, type Msg } from "./Message";
import ModelPicker from "./ModelPicker";

type InitialConv = {
  id: string;
  title: string;
  provider: string;
  model: string;
  system: string;
  messages: Msg[];
};

type Props = {
  providers: Provider[];
  conversation?: InitialConv;
};

const STARTERS = [
  "یک خلاصه‌ی فارسی از مهم‌ترین اخبار هوش مصنوعی این هفته بنویس",
  "یک ایمیل حرفه‌ای برای پیگیری پیشنهادِ همکاری بنویس",
  "این کد پایتون را بهینه کن و توضیح بده چه تغییری دادی",
  "یک طرح پروژه‌ی سه‌مرحله‌ای برای راه‌اندازی یک چت‌بات سازمانی بده",
];

export default function ChatView({ providers, conversation }: Props) {
  const router = useRouter();
  const [convId, setConvId] = useState<string | undefined>(conversation?.id);
  const [title, setTitle] = useState(conversation?.title ?? "گفت‌وگوی جدید");
  const [provider, setProvider] = useState(conversation?.provider ?? providers[0]?.id ?? "anthropic");
  const [model, setModel] = useState(conversation?.model ?? providers[0]?.models[0]?.id ?? "claude-3-5-sonnet-latest");
  const [system, setSystem] = useState(conversation?.system ?? "");
  const [messages, setMessages] = useState<Msg[]>(conversation?.messages ?? []);
  const [streaming, setStreaming] = useState(false);
  const [input, setInput] = useState("");
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [uploading, setUploading] = useState(false);
  const listRef = useRef<HTMLDivElement>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);

  // Auto-scroll to bottom on new messages/streaming
  useEffect(() => {
    if (listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight;
  }, [messages, streaming]);

  // Auto-resize textarea
  useEffect(() => {
    const ta = taRef.current; if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = Math.min(280, ta.scrollHeight) + "px";
  }, [input]);

  async function send(text?: string) {
    const content = (text ?? input).trim();
    if (!content || streaming) return;
    setInput("");
    setAttachments([]);

    const userMsg: Msg = { role: "user", content, attachments };
    const aiMsg: Msg = { role: "assistant", content: "", provider, model };
    const newMsgs = [...messages, userMsg, aiMsg];
    setMessages(newMsgs);
    setStreaming(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          conversationId: convId,
          provider, model,
          system: system || undefined,
          attachments: attachments.length ? attachments : undefined,
          messages: [...messages, userMsg].map((m) => ({ role: m.role, content: m.content })),
        }),
      });
      if (!res.ok || !res.body) {
        const t = await res.text().catch(() => "");
        throw new Error(t || `HTTP ${res.status}`);
      }

      const newConvId = res.headers.get("x-conversation-id");
      if (newConvId && !convId) {
        setConvId(newConvId);
        window.history.replaceState(null, "", `/chat/${newConvId}`);
      }

      // Parse the AI SDK data stream — only the lines starting with `0:` are text deltas.
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = "";
      let acc = "";

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split("\n");
        buf = lines.pop() ?? "";
        for (const line of lines) {
          if (!line) continue;
          const colon = line.indexOf(":");
          if (colon < 0) continue;
          const tag = line.slice(0, colon);
          const rest = line.slice(colon + 1);
          if (tag === "0") {
            try {
              const piece = JSON.parse(rest);
              if (typeof piece === "string") {
                acc += piece;
                setMessages((cur) => {
                  const next = cur.slice();
                  next[next.length - 1] = { ...next[next.length - 1], content: acc };
                  return next;
                });
              }
            } catch { /* ignore */ }
          }
        }
      }
    } catch (e: unknown) {
      const message = e instanceof Error ? e.message : "خطای ناشناخته";
      setMessages((cur) => {
        const next = cur.slice();
        next[next.length - 1] = {
          ...next[next.length - 1],
          content: `**خطا:** ${message}`,
        };
        return next;
      });
    } finally {
      setStreaming(false);
      router.refresh();
    }
  }

  async function onUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setUploading(true);
    try {
      const fd = new FormData(); fd.append("file", file);
      const r = await fetch("/api/upload", { method: "POST", body: fd });
      if (!r.ok) {
        const t = await r.json().catch(() => ({}));
        alert(t.error ?? "خطای آپلود");
        return;
      }
      const d = await r.json();
      setAttachments((a) => [...a, d]);
    } finally { setUploading(false); }
  }

  async function saveTitle(t: string) {
    setTitle(t);
    if (!convId) return;
    await fetch(`/api/conversations/${convId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title: t }),
    });
    router.refresh();
  }

  function exportMd() {
    const lines: string[] = [];
    lines.push(`# ${title}`, "");
    for (const m of messages) {
      lines.push(`## ${m.role === "user" ? "کاربر" : "دستیار"}`);
      if (m.model) lines.push(`_${m.model}_`);
      lines.push("");
      lines.push(m.content);
      lines.push("");
    }
    downloadBlob(lines.join("\n"), `${title || "chat"}.md`, "text/markdown");
  }

  function exportJson() {
    const data = { title, provider, model, system, messages };
    downloadBlob(JSON.stringify(data, null, 2), `${title || "chat"}.json`, "application/json");
  }

  return (
    <>
      <div className="main-head">
        <div className="head-title">
          {convId ? (
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              onBlur={(e) => saveTitle(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") (e.target as HTMLInputElement).blur(); }}
            />
          ) : (
            <span>گفت‌وگوی جدید</span>
          )}
        </div>
        <ModelPicker
          providers={providers}
          provider={provider}
          model={model}
          onChange={(p, m) => { setProvider(p); setModel(m); }}
        />
        <div className="head-actions">
          <button className="icon-btn" title="خروجی Markdown" onClick={exportMd}>MD</button>
          <button className="icon-btn" title="خروجی JSON" onClick={exportJson}>JSON</button>
        </div>
      </div>

      <div className="msg-list" ref={listRef}>
        {messages.length === 0 ? (
          <div className="empty-state">
            <div className="empty-title">با چه چیزی می‌توانم کمک کنم؟</div>
            <div className="empty-sub">
              یکی از پیشنهادهای زیر را انتخاب کنید، یا سؤالِ خودتان را تایپ کنید.
              می‌توانید فایلِ PDF یا متنی هم پیوست کنید.
            </div>
            <div className="empty-grid">
              {STARTERS.map((s) => (
                <button key={s} className="empty-card" onClick={() => send(s)}>{s}</button>
              ))}
            </div>
          </div>
        ) : (
          messages.map((m, i) => (
            <Message
              key={m.id ?? i}
              m={m}
              streaming={streaming && i === messages.length - 1 && m.role === "assistant"}
            />
          ))
        )}
      </div>

      <div className="composer-wrap">
        {attachments.length > 0 && (
          <div className="attach-chips" style={{ maxWidth: 880, margin: "0 auto 8px" }}>
            {attachments.map((a, i) => (
              <span key={i} className="attach-chip">
                📎 {a.name}
                <span className="x" onClick={() => setAttachments((cur) => cur.filter((_, j) => j !== i))}>×</span>
              </span>
            ))}
          </div>
        )}
        <div className="composer">
          <textarea
            ref={taRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault(); send();
              }
            }}
            placeholder="پیامتان را بنویسید… (Shift+Enter برای خط جدید)"
            rows={1}
          />
          <div className="composer-row">
            <label className="composer-btn" title="پیوست فایل (PDF/متن)">
              {uploading ? "در حال آپلود…" : "📎 پیوست"}
              <input type="file" onChange={onUpload} accept=".pdf,.txt,.md,.json,.csv,.yaml,.yml,.js,.ts,.tsx,.jsx,.py,.rs,.go,.java,.c,.cpp,.sh,text/*,application/pdf" />
            </label>
            <details className="composer-btn" style={{ position: "relative" }}>
              <summary style={{ listStyle: "none", cursor: "pointer" }}>⚙ سیستم</summary>
              <div style={{
                position: "absolute", bottom: "calc(100% + 6px)", right: 0,
                background: "var(--bg-2)", border: "1px solid var(--border)",
                borderRadius: 8, padding: 12, width: 360, zIndex: 5,
              }}>
                <div style={{ fontSize: 12, color: "var(--text-dim)", marginBottom: 6 }}>System prompt (اختیاری)</div>
                <textarea
                  value={system}
                  onChange={(e) => setSystem(e.target.value)}
                  rows={5}
                  style={{
                    width: "100%", background: "var(--bg)", border: "1px solid var(--border)",
                    borderRadius: 6, padding: 8, font: "inherit", color: "var(--text)", resize: "vertical",
                  }}
                  placeholder="مثلاً: شما یک مشاور حقوقی هستی؛ پاسخ‌ها مختصر و رسمی باشد."
                />
              </div>
            </details>
            <div className="grow" />
            <button className="send-btn" onClick={() => send()} disabled={streaming || !input.trim()}>
              {streaming ? "در حال پاسخ…" : "ارسال ↵"}
            </button>
          </div>
        </div>
        <div className="composer-foot">
          مدل‌ها ممکن است اشتباه کنند. اطلاعات حساس را با احتیاط ارسال کنید.
        </div>
      </div>
    </>
  );
}

function downloadBlob(content: string, filename: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
