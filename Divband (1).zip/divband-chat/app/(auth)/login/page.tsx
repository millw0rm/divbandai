"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";

export default function LoginPage() {
  const router = useRouter();
  const params = useSearchParams();
  const from = params.get("from") || "/chat";
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setErr(null);
    const r = await signIn("credentials", { email, password, redirect: false });
    setBusy(false);
    if (r?.ok) router.push(from);
    else setErr("ایمیل یا گذرواژه نادرست است.");
  }

  return (
    <div className="auth-card">
      <div className="auth-brand">
        <span className="mark">◇</span>
        <span className="word">DIVBAND<span className="sub">/chat</span></span>
      </div>
      <h1 className="auth-title">ورود به حساب</h1>
      <p className="auth-sub">برای ادامه‌ی گفت‌وگو با مدل‌ها وارد شوید.</p>

      <form className="auth-form" onSubmit={onSubmit}>
        <label>ایمیل
          <input type="email" required dir="ltr" value={email} onChange={(e) => setEmail(e.target.value)} />
        </label>
        <label>گذرواژه
          <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
        </label>
        <button type="submit" disabled={busy}>{busy ? "در حال ورود…" : "ورود"}</button>
        {err && <div className="auth-error">{err}</div>}
      </form>

      <div className="auth-foot">
        حساب ندارید؟ <Link href="/register">ثبت‌نام کنید</Link>
      </div>
    </div>
  );
}
