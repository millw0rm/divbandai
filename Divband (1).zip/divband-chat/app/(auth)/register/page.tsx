"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function RegisterPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setErr(null);
    const r = await fetch("/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password }),
    });
    if (!r.ok) {
      setBusy(false);
      const data = await r.json().catch(() => ({}));
      setErr(data.error ?? "ثبت‌نام انجام نشد.");
      return;
    }
    const s = await signIn("credentials", { email, password, redirect: false });
    setBusy(false);
    if (s?.ok) router.push("/chat");
    else setErr("ثبت‌نام انجام شد ولی ورود خودکار با خطا مواجه شد. لطفاً وارد شوید.");
  }

  return (
    <div className="auth-card">
      <div className="auth-brand">
        <span className="mark">◇</span>
        <span className="word">DIVBAND<span className="sub">/chat</span></span>
      </div>
      <h1 className="auth-title">ایجاد حساب</h1>
      <p className="auth-sub">یک حساب بسازید تا گفت‌وگوها روی همه‌ی دستگاه‌ها همگام شود.</p>

      <form className="auth-form" onSubmit={onSubmit}>
        <label>نام
          <input type="text" required value={name} onChange={(e) => setName(e.target.value)} />
        </label>
        <label>ایمیل
          <input type="email" required dir="ltr" value={email} onChange={(e) => setEmail(e.target.value)} />
        </label>
        <label>گذرواژه (حداقل ۸ کاراکتر)
          <input type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} />
        </label>
        <button type="submit" disabled={busy}>{busy ? "در حال ایجاد…" : "ایجاد حساب"}</button>
        {err && <div className="auth-error">{err}</div>}
      </form>

      <div className="auth-foot">
        حساب دارید؟ <Link href="/login">وارد شوید</Link>
      </div>
    </div>
  );
}
