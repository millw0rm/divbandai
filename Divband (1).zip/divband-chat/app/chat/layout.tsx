import { ReactNode } from "react";
import Sidebar from "@/components/Sidebar";

export default function ChatLayout({ children }: { children: ReactNode }) {
  return (
    <div className="shell">
      <Sidebar />
      <section className="main">{children}</section>
    </div>
  );
}
