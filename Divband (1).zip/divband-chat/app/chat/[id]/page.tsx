import ChatView from "@/components/ChatView";
import { prisma } from "@/lib/db";
import { requireSession } from "@/lib/session";
import { activeProviders, PROVIDERS } from "@/lib/providers";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function ConvPage({ params }: { params: { id: string } }) {
  let session;
  try { session = await requireSession(); } catch { return null; }
  const conv = await prisma.conversation.findFirst({
    where: { id: params.id, userId: session.user.id },
    include: { messages: { orderBy: { createdAt: "asc" } } },
  });
  if (!conv) notFound();
  const providers = activeProviders();
  return (
    <ChatView
      providers={providers.length ? providers : PROVIDERS}
      conversation={{
        id: conv.id,
        title: conv.title,
        provider: conv.provider,
        model: conv.model,
        system: conv.system ?? "",
        messages: conv.messages.map((m) => ({
          id: m.id,
          role: m.role as "user" | "assistant" | "system",
          content: m.content,
          provider: m.provider ?? undefined,
          model: m.model ?? undefined,
        })),
      }}
    />
  );
}
