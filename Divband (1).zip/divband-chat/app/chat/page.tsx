import ChatView from "@/components/ChatView";
import { PROVIDERS, activeProviders } from "@/lib/providers";

export default function NewChatPage() {
  const providers = activeProviders();
  return <ChatView providers={providers.length ? providers : PROVIDERS} />;
}
