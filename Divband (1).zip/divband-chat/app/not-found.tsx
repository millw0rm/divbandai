import Link from "next/link";

export default function NotFound() {
  return (
    <div style={{
      display: "grid", placeItems: "center", height: "100dvh", textAlign: "center",
      fontFamily: "var(--sans)", color: "var(--text)",
    }}>
      <div>
        <div style={{ fontFamily: "var(--mono)", color: "var(--text-soft)", marginBottom: 8 }}>404</div>
        <h1 style={{ margin: "0 0 12px" }}>پیدا نشد</h1>
        <Link href="/chat" style={{ color: "var(--accent)" }}>بازگشت به گفت‌وگو ←</Link>
      </div>
    </div>
  );
}
