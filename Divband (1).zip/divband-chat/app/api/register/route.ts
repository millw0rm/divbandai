import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { emailAllowed } from "@/lib/auth";

const Body = z.object({
  email: z.string().email(),
  password: z.string().min(8).max(200),
  name: z.string().min(1).max(80).optional(),
});

export async function POST(req: NextRequest) {
  let payload;
  try {
    payload = Body.parse(await req.json());
  } catch {
    return NextResponse.json({ error: "ورودیِ نامعتبر" }, { status: 400 });
  }
  const email = payload.email.toLowerCase();
  if (!emailAllowed(email)) {
    return NextResponse.json({ error: "ثبت‌نام برای این ایمیل مجاز نیست." }, { status: 403 });
  }
  const exists = await prisma.user.findUnique({ where: { email } });
  if (exists) return NextResponse.json({ error: "این ایمیل قبلاً ثبت شده." }, { status: 409 });

  const passwordHash = await bcrypt.hash(payload.password, 10);
  const user = await prisma.user.create({
    data: { email, name: payload.name, passwordHash },
    select: { id: true, email: true, name: true },
  });
  return NextResponse.json({ user });
}
