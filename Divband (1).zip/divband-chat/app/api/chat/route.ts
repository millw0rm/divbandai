// Streaming chat endpoint. Accepts: { conversationId, provider, model, messages, system, attachments }
// Persists the user message + assistant message (after stream completes).

import { NextRequest } from "next/server";
import { z } from "zod";
import { streamText } from "ai";
import { getModel } from "@/lib/ai";
import { getProvider } from "@/lib/providers";
import { prisma } from "@/lib/db";
import { requireSession } from "@/lib/session";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

const Body = z.object({
  conversationId: z.string().optional(),
  provider: z.string(),
  model: z.string(),
  system: z.string().optional(),
  attachments: z
    .array(z.object({ name: z.string(), excerpt: z.string(), type: z.string().optional() }))
    .optional(),
  messages: z.array(
    z.object({
      role: z.enum(["user", "assistant", "system"]),
      content: z.string(),
    })
  ).min(1),
});

export async function POST(req: NextRequest) {
  let session;
  try { session = await requireSession(); } catch { return new Response("UNAUTHENTICATED", { status: 401 }); }

  let body;
  try { body = Body.parse(await req.json()); } catch (e) { return new Response("BAD_REQUEST", { status: 400 }); }

  const providerDef = getProvider(body.provider);
  if (!providerDef) return new Response("UNKNOWN_PROVIDER", { status: 400 });
  if (!providerDef.models.find((m) => m.id === body.model)) return new Response("UNKNOWN_MODEL", { status: 400 });

  // Build the actual messages: prepend attachment context to the last user message.
  const messages = body.messages.map((m) => ({ ...m }));
  if (body.attachments?.length) {
    const lastUserIdx = [...messages].reverse().findIndex((m) => m.role === "user");
    if (lastUserIdx !== -1) {
      const idx = messages.length - 1 - lastUserIdx;
      const ctx = body.attachments
        .map((a) => `--- فایل: ${a.name} ---\n${a.excerpt}\n--- پایان فایل ---`)
        .join("\n\n");
      messages[idx].content = `${ctx}\n\n${messages[idx].content}`;
    }
  }

  // Ensure / create a conversation row.
  let conversationId = body.conversationId;
  if (!conversationId) {
    const firstUser = messages.find((m) => m.role === "user")?.content ?? "گفت‌وگو";
    const title = firstUser.slice(0, 80);
    const conv = await prisma.conversation.create({
      data: {
        userId: session.user.id,
        title,
        provider: body.provider,
        model: body.model,
        system: body.system,
      },
      select: { id: true },
    });
    conversationId = conv.id;
  } else {
    // make sure it belongs to user
    const owned = await prisma.conversation.findFirst({
      where: { id: conversationId, userId: session.user.id },
      select: { id: true },
    });
    if (!owned) return new Response("FORBIDDEN", { status: 403 });
    // update provider/model on subsequent turns
    await prisma.conversation.update({
      where: { id: conversationId },
      data: { provider: body.provider, model: body.model, system: body.system ?? undefined },
    });
  }

  // Persist the new user message.
  const lastUserMsg = [...messages].reverse().find((m) => m.role === "user");
  if (lastUserMsg) {
    await prisma.message.create({
      data: {
        conversationId,
        role: "user",
        content: lastUserMsg.content,
        attachments: body.attachments ?? undefined,
      },
    });
  }

  const llm = getModel(body.provider as never, body.model);
  const result = await streamText({
    model: llm,
    system: body.system,
    messages: messages as { role: "user" | "assistant" | "system"; content: string }[],
    onFinish: async ({ text, usage }) => {
      try {
        await prisma.message.create({
          data: {
            conversationId: conversationId!,
            role: "assistant",
            content: text,
            provider: body.provider,
            model: body.model,
            tokensIn: usage?.promptTokens ?? null,
            tokensOut: usage?.completionTokens ?? null,
          },
        });
        await prisma.conversation.update({
          where: { id: conversationId! },
          data: { updatedAt: new Date() },
        });
      } catch {}
    },
  });

  // Stream the response and include conversationId in a header so the client can pick it up
  // on the very first turn.
  const res = result.toDataStreamResponse();
  res.headers.set("x-conversation-id", conversationId!);
  return res;
}
