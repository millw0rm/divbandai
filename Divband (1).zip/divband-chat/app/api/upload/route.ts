// Accept a single file (multipart), return an excerpt to attach to the next message.
// Supports: PDF (extracted), plain text, markdown, code files.

import { NextRequest, NextResponse } from "next/server";
import { extractPdfText } from "@/lib/pdf";
import { requireSession } from "@/lib/session";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 30;

const MAX_FILE = 12 * 1024 * 1024;   // 12 MB
const MAX_TEXT = 30000;              // chars

export async function POST(req: NextRequest) {
  try { await requireSession(); } catch { return NextResponse.json({ error: "UNAUTHENTICATED" }, { status: 401 }); }

  const form = await req.formData();
  const file = form.get("file");
  if (!(file instanceof Blob)) return NextResponse.json({ error: "no file" }, { status: 400 });
  if (file.size > MAX_FILE) return NextResponse.json({ error: "فایل بیش از ۱۲ مگابایت است" }, { status: 413 });

  const name = (file as File).name || "file";
  const type = file.type || "";
  const buf = Buffer.from(await file.arrayBuffer());

  let excerpt = "";
  if (type === "application/pdf" || name.toLowerCase().endsWith(".pdf")) {
    excerpt = await extractPdfText(buf, MAX_TEXT);
  } else if (type.startsWith("text/") || /\.(md|txt|json|csv|ya?ml|js|ts|tsx|jsx|py|rs|go|java|c|cpp|sh)$/i.test(name)) {
    excerpt = buf.toString("utf8");
    if (excerpt.length > MAX_TEXT) excerpt = excerpt.slice(0, MAX_TEXT) + "\n\n…[متن کوتاه شد]…";
  } else {
    return NextResponse.json(
      { error: "فعلاً فقط PDF و فایل‌های متنی پشتیبانی می‌شوند" },
      { status: 415 }
    );
  }

  return NextResponse.json({
    name,
    type,
    size: file.size,
    excerpt,
  });
}
