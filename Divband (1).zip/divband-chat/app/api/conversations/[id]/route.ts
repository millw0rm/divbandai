import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireSession } from "@/lib/session";

export const runtime = "nodejs";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const s = await requireSession();
    const conv = await prisma.conversation.findFirst({
      where: { id: params.id, userId: s.user.id },
      include: { messages: { orderBy: { createdAt: "asc" } } },
    });
    if (!conv) return NextResponse.json({ error: "NOT_FOUND" }, { status: 404 });
    return NextResponse.json({ conversation: conv });
  } catch {
    return NextResponse.json({ error: "UNAUTHENTICATED" }, { status: 401 });
  }
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const s = await requireSession();
    const body = await req.json();
    const updated = await prisma.conversation.updateMany({
      where: { id: params.id, userId: s.user.id },
      data: {
        title: body.title ?? undefined,
        system: body.system ?? undefined,
      },
    });
    if (updated.count === 0) return NextResponse.json({ error: "NOT_FOUND" }, { status: 404 });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "UNAUTHENTICATED" }, { status: 401 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const s = await requireSession();
    const result = await prisma.conversation.deleteMany({
      where: { id: params.id, userId: s.user.id },
    });
    if (result.count === 0) return NextResponse.json({ error: "NOT_FOUND" }, { status: 404 });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "UNAUTHENTICATED" }, { status: 401 });
  }
}
