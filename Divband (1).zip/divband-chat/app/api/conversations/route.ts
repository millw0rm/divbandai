import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireSession } from "@/lib/session";

export const runtime = "nodejs";

export async function GET() {
  try {
    const s = await requireSession();
    const list = await prisma.conversation.findMany({
      where: { userId: s.user.id },
      orderBy: { updatedAt: "desc" },
      take: 100,
      select: { id: true, title: true, provider: true, model: true, updatedAt: true },
    });
    return NextResponse.json({ conversations: list });
  } catch {
    return NextResponse.json({ error: "UNAUTHENTICATED" }, { status: 401 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const s = await requireSession();
    const body = await req.json().catch(() => ({}));
    const conv = await prisma.conversation.create({
      data: {
        userId: s.user.id,
        title: body.title ?? "گفت‌وگوی جدید",
        provider: body.provider ?? "anthropic",
        model: body.model ?? "claude-3-5-sonnet-latest",
        system: body.system ?? null,
      },
    });
    return NextResponse.json({ conversation: conv });
  } catch {
    return NextResponse.json({ error: "UNAUTHENTICATED" }, { status: 401 });
  }
}
