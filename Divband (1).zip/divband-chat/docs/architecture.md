# Architecture — Divband Chat

## نمای کلی

```
                      ┌─────────────────────────────────────────────┐
                      │           chat.divband.com (VPS)            │
                      │                                             │
   ┌────────┐  HTTPS  │  ┌─────────────┐      ┌────────────────┐   │
   │ کاربر  │ ───────▶│  │   Nginx /   │ ───▶ │  Next.js app   │   │
   └────────┘         │  │   Caddy     │      │   :3001        │   │
                      │  └─────────────┘      │                │   │
                      │                       │  - SSR pages   │   │
                      │                       │  - API routes  │   │
                      │                       │  - middleware  │   │
                      │                       │  - NextAuth    │   │
                      │                       └────┬───────────┘   │
                      │                            │               │
                      │                            ▼               │
                      │                       ┌────────────┐       │
                      │                       │ Postgres 16│       │
                      │                       │  :5432     │       │
                      │                       └────────────┘       │
                      └─────────────────┬───────────────────────────┘
                                        │
                                        ▼  (outbound HTTPS, server-side)
                       ┌──────────────────────────────────────┐
                       │  AI providers:                       │
                       │    OpenAI, Anthropic, Google,        │
                       │    Mistral, DeepSeek, xAI            │
                       │  + Ollama (local network)            │
                       └──────────────────────────────────────┘
```

## لایه‌ها

### ۱. Client (browser)

- Next.js App Router با React Server Components.
- Streaming UI با `ReadableStream` و parser سفارشیِ AI SDK data stream.
- State محلی per-chat (no global store؛ از `useState` + URL استفاده می‌شود).
- Sessions از طریق NextAuth client (`useSession`).

### ۲. Edge / Middleware

- `middleware.ts` همه‌ی صفحات و APIها به‌جز مسیرهای public (`/login`, `/register`, `/api/auth/*`, `/api/register`) را گیت می‌کند.
- توکن JWT با `getToken` از کوکی استخراج می‌شود.

### ۳. App Server (Next.js node runtime)

- API routes تحتِ `/api/*`.
- `/api/chat` همان جایی است که streaming اتفاق می‌افتد:
  1. درخواست را اعتبارسنجی می‌کند (zod).
  2. provider/model را resolve می‌کند.
  3. attachment excerptها را به آخرین پیامِ کاربر prepend می‌کند.
  4. `streamText()` را با LanguageModel فراخوانی می‌کند.
  5. `onFinish` callback پیامِ assistant را در DB ذخیره می‌کند.
- Response با header `x-conversation-id` برمی‌گردد تا client بداند روی ID جدید روت کند.

### ۴. Persistence

- Postgres از طریق Prisma. تنها این موارد ذخیره می‌شود:
  - Account / Session / User (NextAuth)
  - Conversation
  - Message (با attachments به‌صورت JSON)
- هیچ توکنِ API در DB ذخیره نمی‌شود.
- migrations از طریق `prisma migrate` مدیریت می‌شوند.

### ۵. AI Provider Integration

- یک factory در `lib/ai.ts` با switch روی providerId یک `LanguageModel` (از Vercel AI SDK) برمی‌گرداند.
- هر provider با مدول رسمیِ خودش از AI SDK ساخته می‌شود:
  - `@ai-sdk/openai` (هم برای OpenAI و هم برای DeepSeek با `baseURL` متفاوت)
  - `@ai-sdk/anthropic`
  - `@ai-sdk/google`
  - `@ai-sdk/mistral`
  - `@ai-sdk/xai`
  - `ollama-ai-provider`
- لیستِ مدل‌های قابلِ انتخاب صرفاً در `lib/providers.ts` تعریف می‌شود.

## جریانِ یک پیام

```
[user types] ─▶ [POST /api/chat]
                     │
                     ├─▶ requireSession()
                     │
                     ├─▶ zod validate body
                     │
                     ├─▶ resolve provider+model
                     │
                     ├─▶ if no conversationId:
                     │       create row, return id in header
                     │
                     ├─▶ persist user message
                     │
                     ├─▶ streamText({ model, system, messages })
                     │       │
                     │       └─▶ stream chunks ──▶ client
                     │
                     └─▶ onFinish: persist assistant message + token usage
```

## ساختار فایل‌ها

```
divband-chat/
├── app/
│   ├── (auth)/login + register + layout
│   ├── api/auth/[...nextauth]/route.ts
│   ├── api/chat/route.ts             ← هسته‌ی streaming
│   ├── api/conversations/{,[id]}/route.ts
│   ├── api/register/route.ts
│   ├── api/upload/route.ts           ← PDF text extract
│   ├── chat/page.tsx + [id]/page.tsx + layout
│   ├── globals.css                   ← تمامِ استایل‌ها
│   ├── layout.tsx                    ← RTL shell + fonts
│   ├── not-found.tsx
│   ├── page.tsx                      ← redirect
│   └── providers.tsx                 ← SessionProvider client wrap
├── components/
│   ├── ChatView.tsx                  ← composer + stream loop
│   ├── Message.tsx                   ← markdown render
│   ├── ModelPicker.tsx
│   └── Sidebar.tsx
├── lib/
│   ├── ai.ts                         ← provider factory
│   ├── auth.ts                       ← NextAuth options + allowlist
│   ├── db.ts                         ← Prisma singleton
│   ├── pdf.ts                        ← pdf-parse wrapper
│   ├── providers.ts                  ← model registry
│   └── session.ts                    ← requireSession helper
├── prisma/schema.prisma
├── middleware.ts                     ← auth gate
├── Dockerfile + docker-compose.yml
├── docs/
│   ├── PRD.md
│   ├── design-system.md
│   ├── design-tokens.json
│   ├── style-guide.html
│   ├── architecture.md (این فایل)
│   ├── api.md
│   ├── security.md
│   ├── deployment.md
│   └── roadmap.md
└── README.md
```

## تصمیم‌های فنی و توجیهات

### چرا Vercel AI SDK؟

- یک interface واحد برای همه‌ی providerها (`streamText`).
- Stream parser در client بدون نیاز به کتابخانه‌ی جداگانه.
- پشتیبانیِ آینده از tools, structured output, vision بدون تغییرِ معماری.

### چرا NextAuth (نه Auth.js v5)؟

- Auth.js v5 هنوز در beta است؛ v4 stableتر است و adapterها قطعی هستند.
- migration به v5 در آینده ساده — فقط `next-auth` به `@auth/core` تغییر می‌کند.

### چرا Postgres نه SQLite؟

- آماده برای production و horizontal scale.
- پشتیبانیِ بومیِ JSON برای `Message.attachments`.
- روی VPS-های ایرانی هم با Docker راحت بالا می‌آید.

### چرا `output: "standalone"` در Next config؟

- Dockerfile کوچک‌تر (فقط فایل‌های لازم).
- Cold start سریع‌تر.

### چرا PDF text-extract نه vectorize/RAG؟

- v1 ساده می‌خواهیم بمانیم.
- vectorize برای متن‌های < ۳۰k کاراکتر مزیت چندانی ندارد.
- RAG با pgvector روی roadmap است.

## مقیاس‌پذیری

| سناریو                              | راهکار                                                  |
|---------------------------------------|--------------------------------------------------------|
| > ۱۰۰۰ کاربر فعال همزمان              | scale horizontal با چند replica + Postgres مشترک      |
| > ۱۰ میلیون پیام                      | partition `Message` بر اساس `createdAt`              |
| latency بالای provider                | retry با exponential backoff؛ fallback به provider دیگر |
| محدودیت rate در provider              | queue با Redis (BullMQ) + worker جدا                  |
| فایل‌های بزرگ                          | object storage (S3/MinIO) + pre-signed URL          |

## مانیتورینگ (پیشنهادی برای v2)

- Prometheus metrics endpoint در `/api/metrics`.
- توکن مصرفی per-user, per-model در Grafana.
- error tracking با Sentry.
- لاگ‌های ساخت‌یافته با pino.
