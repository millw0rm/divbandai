# Deployment Guide — Divband Chat

این راهنما برای deploy روی یک VPS ساده (DigitalOcean، Hetzner، Arvan Cloud، یا server اختصاصی) با Docker است.

## پیش‌نیازها

- یک سرور Linux (Ubuntu 22.04+ توصیه می‌شود) با حداقل ۲ vCPU و ۲GB RAM.
- یک دامنه/زیردامنه که DNS A record-اش به IP سرور اشاره می‌کند (مثلاً `chat.divband.com`).
- Docker و Docker Compose v2.
- یک reverse proxy (Caddy یا Nginx).
- کلیدهای AI providerها (حداقل یکی).

## گام ۱ — نصب Docker

```bash
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
newgrp docker
```

## گام ۲ — clone و env

```bash
git clone <your-repo>.git
cd divband-chat
cp .env.example .env
nano .env
```

مقادیر مهم:

```env
NEXTAUTH_URL=https://chat.divband.com
NEXTAUTH_SECRET=$(openssl rand -base64 32)   # یک‌بار اجرا کنید و paste کنید
DATABASE_URL=postgresql://divband:divband@db:5432/divband_chat
# کلیدهایی که می‌خواهید فعال شوند:
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...
# اختیاری: محدود کردنِ ثبت‌نام
ALLOWED_EMAILS=ali@divband.com,sara@divband.com
```

برای استفاده‌ی production جدی، گذرواژه‌ی Postgres را در `docker-compose.yml` و `DATABASE_URL` تغییر دهید.

## گام ۳ — بالا آوردنِ سرویس

```bash
docker compose up -d --build
```

این کار:
- یک container Postgres با volume پایدار راه می‌اندازد.
- اپ Next.js را build و prisma migrate deploy را اجرا می‌کند.
- روی پورت ۳۰۰۱ پاسخ می‌دهد.

بررسی:

```bash
docker compose ps
docker compose logs -f app
curl -I http://localhost:3001    # باید 307 redirect به /login بدهد
```

## گام ۴ — Reverse proxy با Caddy

نصب:

```bash
sudo apt install -y debian-keyring debian-archive-keyring apt-transport-https
curl -fsSL 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | sudo gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -fsSL 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | sudo tee /etc/apt/sources.list.d/caddy-stable.list
sudo apt update
sudo apt install caddy
```

ویرایش `/etc/caddy/Caddyfile`:

```
chat.divband.com {
    encode gzip

    header {
        Strict-Transport-Security "max-age=63072000; includeSubDomains; preload"
        X-Content-Type-Options "nosniff"
        X-Frame-Options "DENY"
        Referrer-Policy "strict-origin-when-cross-origin"
    }

    reverse_proxy localhost:3001
}
```

سپس:

```bash
sudo systemctl reload caddy
```

Caddy خودکار از Let's Encrypt گواهی می‌گیرد. به <https://chat.divband.com> سر بزنید.

## گام ۵ — اولین کاربر

به `https://chat.divband.com/register` بروید. اگر `ALLOWED_EMAILS` تنظیم شده، با یکی از آن ایمیل‌ها ثبت‌نام کنید. اولین گفت‌وگو را شروع کنید.

## گام ۶ — Backup خودکار

اضافه کنید به crontab سرور:

```cron
0 3 * * * cd /path/to/divband-chat && docker compose exec -T db pg_dump -U divband divband_chat | gzip > /var/backups/divband-chat-$(date +\%F).sql.gz
0 4 * * * find /var/backups/ -name 'divband-chat-*.sql.gz' -mtime +14 -delete
```

برای restore:

```bash
gunzip -c backup.sql.gz | docker compose exec -T db psql -U divband divband_chat
```

## گام ۷ — Update

```bash
git pull
docker compose up -d --build
```

migrationها به‌صورت خودکار اجرا می‌شوند (`prisma migrate deploy` در command-ـ container).

## استقرار با Nginx (به‌جای Caddy)

اگر Nginx ترجیح می‌دهید:

```nginx
server {
    listen 80;
    server_name chat.divband.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name chat.divband.com;

    ssl_certificate     /etc/letsencrypt/live/chat.divband.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/chat.divband.com/privkey.pem;

    add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload" always;
    add_header X-Content-Type-Options nosniff;
    add_header X-Frame-Options DENY;

    location / {
        proxy_pass http://127.0.0.1:3001;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # Streaming-friendly settings:
        proxy_buffering off;
        proxy_cache off;
        proxy_read_timeout 300s;
    }
}
```

گواهی با certbot:

```bash
sudo certbot --nginx -d chat.divband.com
```

## استقرار با Ollama محلی

اگر می‌خواهید مدل‌های open-source را روی همان سرور اجرا کنید:

۱. نصب Ollama:
```bash
curl -fsSL https://ollama.com/install.sh | sh
ollama pull llama3.2
ollama pull qwen2.5
```

۲. در `.env`:
```env
OLLAMA_BASE_URL=http://host.docker.internal:11434
```

(در docker-compose حال حاضر این تنظیم به‌صورت پیش‌فرض است — کانتینر می‌تواند به Ollama روی host دسترسی داشته باشد.)

## استقرار روی Kubernetes (پیشنهادی برای scale)

- یک Helm chart بسازید با Deployment برای app + StatefulSet برای Postgres.
- Secrets برای کلیدهای AI و DATABASE_URL.
- Ingress با cert-manager.
- HPA با CPU threshold.

این در v2 documentation اضافه خواهد شد.

## عیب‌یابی

| مسئله                                          | راه‌حل                                                  |
|-----------------------------------------------|---------------------------------------------------------|
| `prisma migrate deploy` fail                  | مطمئن شوید DATABASE_URL درست است و DB در حال اجراست  |
| streaming کار نمی‌کند                          | در Nginx `proxy_buffering off;` تنظیم کنید           |
| `NEXTAUTH_SECRET is not set` در لاگ           | `.env` را بازبینی کنید و container را restart کنید   |
| `Cannot find module '@prisma/client'`        | `docker compose up --build` با cache پاک کنید        |
| 502 از Caddy                                   | container app پایین است — `docker compose logs app` |
