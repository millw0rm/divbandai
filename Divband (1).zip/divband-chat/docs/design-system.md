# Design System — Divband Studio

> نسخه ۱.۰ · مشترک بین وب‌سایت اصلی (divband.com) و chat.divband.com

## ۱. فلسفه

**روشن، حرفه‌ای، فارسی-اول.** الهام از Linear/Vercel/Stripe در ساختار، با شخصیتِ Divband: تایپوگرافی نرم، یک accent تک‌رنگ سرمه‌ای، استفاده‌ی هوشمندانه از monospace برای متادیتا.

## ۲. توکن‌های پایه (Design Tokens)

این مقادیر منبعِ راستی هستند. نسخه‌ی JSON قابل importِ Figma در `design-tokens.json`.

### ۲.۱ رنگ

```css
/* Backgrounds */
--bg:        #fafaf7   /* off-white، پیش‌فرض */
--bg-2:      #ffffff   /* سفیدِ تمیز، کارت‌ها و فرم‌ها */
--bg-3:      #f3f3ee   /* خاکستری گرم، code chips، hover states */
--bg-side:   #f6f5f0   /* sidebar */

/* Borders */
--border:    rgba(15, 23, 42, 0.10)   /* استاندارد */
--border-2:  rgba(15, 23, 42, 0.06)   /* خفیف */

/* Text */
--text:      #0a0f1f   /* اصلی، تقریباً مشکی */
--text-dim:  #4b5468   /* ثانویه */
--text-soft: #8b92a3   /* متادیتا، placeholder */

/* Accent */
--accent:    #1e3a8a   /* سرمه‌ای عمیق، CTA و لینک */
--accent-2:  #2851d6   /* روشن‌تر، hover */
--accent-3:  rgba(30,58,138,0.08)   /* halo, hover bg */

/* Status */
--success:   #16a34a
--danger:    #b8203c
--warning:   #d97706
```

**قاعده‌ی استفاده:**
- پس‌زمینه‌ی اصلی صفحه: `--bg`
- کارت/فرم/ورودی: `--bg-2`
- chip/code inline/hover: `--bg-3`
- متن بدنه: `--text`
- متن توضیحی: `--text-dim`
- متادیتا/timestamp/sub-label: `--text-soft`
- CTA پر: `background: --text; color: --bg-2`
- CTA accent (لینک تأکیدی): `--accent`

### ۲.۲ تایپوگرافی

```css
--sans: "Vazirmatn", ui-sans-serif, system-ui, sans-serif;
--mono: "JetBrains Mono", ui-monospace, Menlo, monospace;
```

| Token   | Size  | Line  | Weight | استفاده                              |
|---------|-------|-------|--------|----------------------------------------|
| display | 96–132 | 0.96–1.02 | 500–600 | عنوانِ صفحه‌ی اصلی (`hero-title`) |
| h1      | 56–64 | 1.1    | 500–600 | عنوانِ بخش                            |
| h2      | 44    | 1.15   | 500     | section heading                        |
| h3      | 26    | 1.2    | 600     | کارت / آیتم                            |
| body    | 15    | 1.7    | 400     | متن اصلی                              |
| body-lg | 19    | 1.7    | 400     | لِدِ پاراگراف                           |
| small   | 13    | 1.6    | 400     | متادیتا                                |
| mono-12 | 12    | 1.5    | 400     | شماره/کد/متادیتا                        |
| mono-11 | 11    | 1.5    | 400     | label فرم، badge                       |

**قاعده‌ی Letter-spacing:** display و h1 با `letter-spacing: -0.02em` تا `-0.035em`؛ بقیه‌ی متن بدون تنظیم.

**ویژگی‌های فارسی:** `font-feature-settings: "ss01" on, "ss02" on;` برای فعال‌سازی stylistic sets Vazirmatn.

### ۲.۳ فاصله (Spacing)

```
4   8   12   16   24   32   48   64   96   140
```

ضربه‌ی ۴ یا ۸. در سطحِ صفحه: ۹۶ یا ۱۴۰ برای vertical rhythmِ section. در سطحِ کارت: ۳۲–۴۰.

### ۲.۴ گردی (Radius)

```
4   6   8   12   18   999
```

| Radius | استفاده                          |
|--------|-----------------------------------|
| 4      | ورودی فرم، دکمه‌های مونوی فنی       |
| 6      | دکمه‌های آیکنی، model picker        |
| 8      | کارت، composer                    |
| 12     | کارت بزرگ، modal                  |
| 18     | chat shell نرم                    |
| 999    | pill (eyebrow, CTA دایره‌ای)        |

### ۲.۵ سایه

```css
/* الایه اول — فقط برای ایجاد عمق */
0 1px 2px rgba(15,23,42,0.04)

/* لایه دوم — برای کارت‌های شناور */
0 1px 2px rgba(15,23,42,0.04),
0 8px 24px rgba(15,23,42,0.04)

/* لایه سوم — برای modal */
0 1px 2px rgba(15,23,42,0.04),
0 12px 32px rgba(15,23,42,0.06)
```

سایه‌ها هرگز خیلی نرم نباشند؛ همیشه dual-layer.

### ۲.۶ Border

تمامِ borderها از `--border` یا `--border-2`. هرگز رنگ تخت یا highlight به border نده. سایه روی border افزوده می‌شود، نه جایگزین.

## ۳. کامپوننت‌های پایه

### ۳.۱ Button

```
.btn-primary  — تخت، رنگِ متن، CTA اصلی، گرد ۴
.btn-ghost    — خط دور، رنگِ متن، CTA ثانویه
.btn-link     — بدون پس‌زمینه، underline دش‌دار
.nav-cta      — مونو، خط دور، compact
.icon-btn     — ۳۰×۳۰ مربع، آیکن وسط
.send-btn     — تخت، 8px پایین/۱۴px پهلو
.composer-btn — مونو، خط دور، رنگ dim
```

**حالات:** `hover` همیشه افزایشِ کنتراست (روشن‌تر یا تیره‌تر)، نه تغییرِ shape. `disabled` با `opacity: 0.4` + `cursor: not-allowed`.

### ۳.۲ Input/Textarea

- پس‌زمینه `--bg-2` (یا `--bg` در کانتکست `--bg-2`).
- border `--border`. focus `--text`.
- transition فقط border-color (۱۵۰ms).
- placeholder رنگ `--text-soft`.

### ۳.۳ Card / Container

- کارت‌های info: `padding: 36px; border-radius: 12px; sun-shadow lvl2`.
- لیست‌ها: کارت‌های `padding: 14px 16px; border-radius: 8px`.

### ۳.۴ Message bubble

- `padding: 12px 16px; border-radius: 12px`.
- user: `bg: --text; color: --bg-2`.
- assistant: `bg: --bg-3; color: --text; border: --border-2`.

### ۳.۵ Chip / Badge

- mono 11px، padding `4px 10px`، radius 4، border `--border`.

## ۴. لایوت‌ها

### ۴.۱ Site (divband.com)

- 1440 grid، gutter ۶۴.
- bodyِ ۱۱۰۰max برای متن.
- بخش‌ها با `border-bottom: 1px var(--border)` جدا می‌شوند.

### ۴.۲ App (chat.divband.com)

- shell: 280 sidebar + main flex.
- header sticky با backdrop-blur.
- ستونِ پیام‌ها max-width ۸۸۰، centered.
- composer در 880 max، centered.

## ۵. آیکنوگرافی

- Brand mark: `◇` مربعِ rotate شده.
- Send arrow: `←` (RTL).
- Down arrow: `↓`.
- Lookup arrow: `←` در کارت‌های قابلِ کلیک.
- ✕ برای close/delete.
- 📎 برای attachment.
- ⚙ برای settings.

هرگز emoji رنگی استفاده نکن. اگر آیکن نیاز است که شخصیت‌دار باشد، از Heroicons یا Phosphor (تنها outline، vector، ۱.۵px stroke) استفاده کن.

## ۶. حرکت (Motion)

- Default transition: `150ms` ease.
- Long: `250ms` فقط برای transformهای فضایی (padding، margin).
- Hover روی دکمه: `transform: translateY(-1px)` با `200ms`.
- شبکه‌ی نقطه‌ای هیرو: ۳۰fps capped؛ pause در blur با `IntersectionObserver`.

## ۷. RTL Rules

- `<html dir="rtl" lang="fa">`.
- بلاک‌های کد، ایمیل، URL، آدرس MAC، عدد ساده در LTR با `.ltr { direction: ltr; unicode-bidi: bidi-override; display: inline-block }`.
- `margin-right`/`margin-left` به جای `padding-left/right` در کانتکست RTL با احتیاط — ترجیحاً `padding-inline-start` و معادل‌ها در آینده.
- آیکن‌های جهت‌دار را در RTL flip نکن (← باقی می‌ماند).

## ۸. تم‌بندی آینده

پایه برای dark mode آماده است — فقط مقادیرِ `--bg*`, `--text*`, `--border*` در media query `prefers-color-scheme: dark` overwrite می‌شوند. در v1 dark mode حذف شده تا کانفیوژن کاهش یابد.

## ۹. فایل‌ها

- `design-tokens.json` — قابل importِ Figma Tokens Studio.
- `style-guide.html` — صفحه‌ی بصری برای reference توسعه‌دهنده.
- `app/globals.css` (در هر دو پروژه) — پیاده‌سازی واقعی.

## ۱۰. در Figma

از آنجا که Figma فایل‌های `.fig` خارجی هستند، این مخزن یک "design-system-as-code" است.

برای ایجاد Figma library:
۱. در Figma، plugin "Tokens Studio" را نصب کن.
۲. JSON موجود در `design-tokens.json` را import کن.
۳. هر یک از کامپوننت‌های section ۳ را به‌صورتِ Figma component با همان توکن‌ها بساز.
۴. صفحات mock طبق `style-guide.html` بچین.
