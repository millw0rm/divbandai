# API Reference — Divband Chat

تمامِ APIها از کوکی session (NextAuth) برای احراز هویت استفاده می‌کنند، مگر مواردی که با (public) مشخص شده‌اند.

## احراز هویت

### `POST /api/register` (public)

ثبت‌نام کاربر جدید.

**Body:**
```json
{
  "email":    "user@example.com",
  "password": "حداقل ۸ کاراکتر",
  "name":     "اختیاری"
}
```

**Response 200:**
```json
{ "user": { "id": "cl…", "email": "user@example.com", "name": "…" } }
```

**Errors:**
- `400` ورودیِ نامعتبر (Zod schema).
- `403` ایمیل خارج از `ALLOWED_EMAILS` (اگر تنظیم شده باشد).
- `409` ایمیل از قبل ثبت شده.

---

### `POST /api/auth/callback/credentials` (public)

این مسیر را خود NextAuth handle می‌کند. در کلاینت با `signIn("credentials", { email, password })` فراخوانی می‌شود.

---

### `GET /api/auth/session` (public)

اطلاعات session فعلی. توسط `useSession()` در client استفاده می‌شود.

---

### `POST /api/auth/signout`

خروج. در کلاینت با `signOut({ callbackUrl })`.

---

## گفت‌وگوها

### `GET /api/conversations`

لیستِ گفت‌وگوهای کاربرِ فعلی (تا ۱۰۰ عدد، مرتب بر اساس `updatedAt` نزولی).

**Response:**
```json
{
  "conversations": [
    {
      "id": "cl…",
      "title": "تحلیل قرارداد",
      "provider": "anthropic",
      "model": "claude-3-5-sonnet-latest",
      "updatedAt": "2026-05-28T10:11:12.000Z"
    }
  ]
}
```

---

### `POST /api/conversations`

ایجادِ گفت‌وگوی خالی (معمولاً نیازی نیست — `/api/chat` خودش conversation می‌سازد).

**Body:**
```json
{
  "title":    "اختیاری",
  "provider": "anthropic",
  "model":    "claude-3-5-sonnet-latest",
  "system":   "اختیاری"
}
```

---

### `GET /api/conversations/[id]`

دریافتِ یک گفت‌وگو با پیام‌هایش (مرتب صعودی بر اساس createdAt).

**Response:**
```json
{
  "conversation": {
    "id": "…",
    "title": "…",
    "provider": "…",
    "model": "…",
    "system": "…",
    "createdAt": "…",
    "updatedAt": "…",
    "messages": [
      {
        "id": "…",
        "role": "user" | "assistant" | "system",
        "content": "…",
        "provider": "…" | null,
        "model": "…" | null,
        "tokensIn": 123 | null,
        "tokensOut": 456 | null,
        "attachments": [{ "name": "…", "type": "…", "size": 0, "excerpt": "…" }] | null,
        "createdAt": "…"
      }
    ]
  }
}
```

---

### `PATCH /api/conversations/[id]`

ویرایشِ عنوان یا system prompt.

**Body:**
```json
{ "title": "…", "system": "…" }
```

---

### `DELETE /api/conversations/[id]`

حذفِ گفت‌وگو و تمامِ پیام‌هایش (cascade در DB).

---

## چت

### `POST /api/chat`

نقطه‌ی اصلیِ streaming.

**Body:**
```json
{
  "conversationId": "اختیاری — اگر نباشد، گفت‌وگوی جدید ساخته می‌شود",
  "provider": "anthropic" | "openai" | "google" | "mistral" | "deepseek" | "xai" | "ollama",
  "model": "claude-3-5-sonnet-latest",
  "system": "اختیاری",
  "attachments": [
    { "name": "doc.pdf", "type": "application/pdf", "excerpt": "متن استخراج‌شده…" }
  ],
  "messages": [
    { "role": "user",      "content": "سلام" },
    { "role": "assistant", "content": "درود!" },
    { "role": "user",      "content": "..." }
  ]
}
```

**Response Headers:**
- `Content-Type: text/event-stream` (در عمل: AI SDK data stream)
- `x-conversation-id: <id>` — اگر گفت‌وگو جدید بود، ID اینجاست.

**Stream format:**

هر خطِ stream با یک tag و colon شروع می‌شود. مهم‌ترین:

| Tag | معنا                                     |
|-----|--------------------------------------------|
| `0` | text delta (به‌صورت JSON-encoded string)   |
| `d` | اطلاعاتِ finish (data) — معمولاً نیازی به parse نیست. |

مثال:
```
0:"سلام"
0:" ! من"
0:" چطور"
0:" می‌توانم کمک کنم؟"
d:{"finishReason":"stop","usage":{"promptTokens":12,"completionTokens":5}}
```

**Errors:**
- `400` BAD_REQUEST — body نامعتبر یا provider/model ناشناخته.
- `401` UNAUTHENTICATED.
- `403` FORBIDDEN — گفت‌وگو متعلق به کاربر دیگری است.

---

## آپلود فایل

### `POST /api/upload`

آپلودِ PDF یا فایلِ متنی برای استخراج متن.

**Body:** `multipart/form-data` با فیلدِ `file`.

**Constraints:**
- حداکثر اندازه: ۱۲ مگابایت.
- نوع: `application/pdf`، `text/*`، یا extension متنیِ کد (.js, .ts, .py, …).

**Response 200:**
```json
{
  "name":    "document.pdf",
  "type":    "application/pdf",
  "size":    1234567,
  "excerpt": "متنِ استخراج‌شده، تا ۳۰هزار کاراکتر"
}
```

این پاسخ همان object است که در آرایه‌ی `attachments` به `/api/chat` فرستاده می‌شود.

**Errors:**
- `401` UNAUTHENTICATED.
- `413` فایلِ بیش از حد.
- `415` نوعِ پشتیبانی‌نشده.

---

## نمونه‌ی استفاده — JavaScript

```ts
// شروع یک گفت‌وگو
const res = await fetch("/api/chat", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    provider: "anthropic",
    model: "claude-3-5-sonnet-latest",
    messages: [{ role: "user", content: "سلام دیوبند" }],
  }),
});

const id = res.headers.get("x-conversation-id");
const reader = res.body!.getReader();
const dec = new TextDecoder();
let acc = "";
while (true) {
  const { value, done } = await reader.read();
  if (done) break;
  for (const line of dec.decode(value).split("\n")) {
    if (line.startsWith("0:")) acc += JSON.parse(line.slice(2));
  }
  console.log(acc);   // increasing string as stream arrives
}
```
