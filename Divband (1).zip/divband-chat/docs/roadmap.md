# Roadmap — Divband Chat

## v1.0 ✅ (انتشار اولیه)

- [x] Auth (email/password)
- [x] گفت‌وگو با ۷ provider + streaming
- [x] ذخیره‌سازی در Postgres
- [x] Markdown + code highlighting
- [x] PDF + text upload با استخراج متن
- [x] System prompt per-conversation
- [x] Export (Markdown / JSON)
- [x] فارسی + RTL
- [x] Docker + Compose
- [x] مستندات کامل

## v1.1 — Quality of Life (هدف: ۲ هفته بعد از v1)

- [ ] **جست‌وجو در تاریخچه** — سرچ در عناوین و محتوای پیام‌ها (Postgres full-text).
- [ ] **Pin گفت‌وگو** — pin کردن گفت‌وگوهای مهم در بالای sidebar.
- [ ] **Archive** — آرشیو کردن گفت‌وگوهای قدیمی.
- [ ] **Regenerate** — دکمه‌ی regenerate برای آخرین پاسخ.
- [ ] **Edit user message** — ویرایش پیام و branching از همان نقطه.
- [ ] **Copy code button** — دکمه‌ی کپی در کنار هر code block.
- [ ] **Token counter** — نمایش توکن مصرفی per-message.
- [ ] **Empty state بهتر** — کارت‌های شروع context-aware (بر اساس provider انتخابی).

## v1.2 — Compare Mode (هدف: ۱ ماه بعد از v1)

- [ ] **Side-by-side compare** — یک سؤال، ۲–۳ مدلِ مختلف کنار هم.
- [ ] **Pin best response** — انتخاب بهترین پاسخ، ادامه‌ی گفت‌وگو با آن.
- [ ] **Diff view** — مقایسه‌ی متنی پاسخ‌ها.

## v2.0 — Vision & Multimodal

- [ ] **Image upload** — پشتیبانی از vision-enabled models (GPT-4o، Claude، Gemini، Grok Vision).
- [ ] **Image rendering در composer** — preview قبل از ارسال.
- [ ] **Image generation** — DALL·E, Imagen, Stable Diffusion.
- [ ] **Voice input** — Whisper برای dictation.
- [ ] **Text-to-Speech** — خواندنِ پاسخ‌ها.

## v2.1 — Tools & Agents

استفاده از Vercel AI SDK Tools API:

- [ ] **Web search** — Tavily یا Brave API.
- [ ] **Code interpreter** — اجرای Python در sandbox (E2B).
- [ ] **Calculator** — برای محاسباتِ دقیق.
- [ ] **Memory** — یادآوری اطلاعاتِ کاربر بین گفت‌وگوها.

## v2.2 — RAG & Knowledge

- [ ] **pgvector** — embedding برای PDFها و فایل‌ها.
- [ ] **Documents space** — فضای ذخیره‌ی فایل (پروژه‌ها).
- [ ] **Inline citation** — لینکِ بازگشت به متنِ منبع.
- [ ] **Notion / Google Drive sync** — import داده‌های خارجی.

## v3.0 — Team Features

- [ ] **Workspaces** — هر شرکت = یک workspace.
- [ ] **OAuth** — Google, Microsoft, GitHub.
- [ ] **Role-based access** — admin / member / viewer.
- [ ] **Shared conversations** — share با لینک read-only.
- [ ] **Custom personas** — پروفایل‌های قابلِ اشتراک برای system prompt.
- [ ] **Usage dashboard** — مصرفِ توکن per-user, per-model.
- [ ] **Budget alerts** — هشدارِ سقفِ هزینه.
- [ ] **API access** — کاربر می‌تواند از endpoint مستقیم استفاده کند با token.

## v3.1 — Marketplace

- [ ] **Custom GPTs / Personas** — اشتراک‌گذاری پروفایل‌های اختصاصی.
- [ ] **Prompt library** — مخزن پرامپت‌های آماده.
- [ ] **Workflows** — chain کردنِ چند مدل + tool.

## آینده‌ی دور

- [ ] **Mobile apps** — React Native (یا PWA کامل).
- [ ] **Offline mode** — کش با service worker.
- [ ] **Local model UI** — رابط بهتر برای مدیریتِ Ollama models.
- [ ] **Fine-tuning UI** — رابطی برای training های اختصاصی.
- [ ] **Voice agents** — full real-time conversation (Realtime API).

## معیارهای موفقیت

| مرحله     | معیار                                                |
|----------|--------------------------------------------------------|
| v1       | ۵۰ کاربرِ فعالِ هفتگی در divband                       |
| v1.2     | میانگین ۱۰ پیام در روز per-active-user                |
| v2       | پشتیبانی از vision در ۸۰٪ گفت‌وگوها                    |
| v2.2     | ۵۰٪ از گفت‌وگوها با RAG (پیوست فایل/سند)            |
| v3       | تیم‌های ۵+ نفره از ۳+ شرکت                            |
