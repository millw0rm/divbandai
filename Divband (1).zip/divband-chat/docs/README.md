# Divband Chat — مستندات کامل

این پوشه تمامِ مستنداتِ تولیدیِ پلتفرم را در خود دارد.

## فهرست

| فایل                                              | محتوا                                                              |
|---------------------------------------------------|---------------------------------------------------------------------|
| [`PRD.md`](./PRD.md)                              | الزاماتِ تولیدی، اهداف، تعریف Done، KPI                            |
| [`architecture.md`](./architecture.md)            | معماری سیستم، جریان داده، تصمیم‌های فنی                            |
| [`api.md`](./api.md)                              | مرجعِ کاملِ APIها — همه‌ی endpointها با مثال                       |
| [`design-system.md`](./design-system.md)          | سند مرجع توکن‌ها، تایپوگرافی، کامپوننت‌ها، قواعد                  |
| [`design-tokens.json`](./design-tokens.json)      | توکن‌ها به فرمت قابل import در Figma Tokens Studio                |
| [`style-guide.html`](./style-guide.html)          | راهنمای بصریِ زنده — مستقیم در مرورگر باز کنید                    |
| [`security.md`](./security.md)                    | مدلِ تهدید و کنترل‌های امنیتی                                       |
| [`deployment.md`](./deployment.md)                | راهنمای استقرار روی VPS (Caddy / Nginx، Ollama، backup)            |
| [`roadmap.md`](./roadmap.md)                      | نقشه‌ی راه v1 → v3                                                  |

## مخاطب‌ها

- **مدیر محصول / ذی‌نفع تجاری** → `PRD.md` + `roadmap.md`
- **توسعه‌دهنده‌ی frontend** → `design-system.md` + `style-guide.html`
- **توسعه‌دهنده‌ی backend** → `architecture.md` + `api.md`
- **DevOps / SRE** → `deployment.md` + `security.md`
- **طراح UI** → `design-system.md` + `design-tokens.json` + `style-guide.html`

## درباره‌ی Figma

این مخزن از رویکرد **design-system-as-code** پیروی می‌کند — یعنی منبعِ راستی توکن‌ها CSS است، نه Figma. برای ایجاد library در Figma:

۱. در Figma، plugin **Tokens Studio for Figma** را نصب کنید.
۲. در پنلِ plugin، روی Import → JSON کلیک کنید.
۳. فایل `design-tokens.json` را انتخاب کنید.
۴. توکن‌ها به‌صورتِ Figma styles ایجاد می‌شوند.
۵. کامپوننت‌ها را با مراجعه به `style-guide.html` (که زنده توکن‌ها را رندر می‌کند) و `design-system.md` بسازید.

### رابطه‌ی Figma ↔ Code

- اگر توکن در `design-tokens.json` تغییر کرد → باید در `app/globals.css` هم تغییر کند (و برعکس).
- در آینده می‌توان از Tokens Studio + GitHub sync برای خودکارسازی استفاده کرد.

## نسخه‌گذاری

نسخه‌ی فعلی: **۱.۰**. هر breaking change در توکن‌ها یا API نیازمندِ بالا بردن major version است.
