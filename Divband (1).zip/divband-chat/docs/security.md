# Security — Divband Chat

## مدلِ تهدید

| تهدید                                                | اثر                              | کاهش                                                  |
|-------------------------------------------------------|----------------------------------|--------------------------------------------------------|
| نشتِ کلیدِ AI                                          | هزینه‌ی بالا، استفاده‌ی غیرمجاز | کلیدها فقط در `.env` سرور؛ هرگز به client نمی‌رود     |
| سرقتِ session                                         | جعل هویت کاربر                  | JWT با secret قوی (32B)، httpOnly cookie، Secure flag |
| تزریق پرامپت از طریق فایل آپلودی                      | model فریب می‌خورد                 | محتوای فایل در یک fenced block جدا قرار می‌گیرد       |
| brute force گذرواژه                                    | دسترسی غیرمجاز                  | bcrypt cost 10؛ توصیه به افزودنِ rate limit در nginx |
| XSS از طریق Markdown                                   | تزریقِ JS                        | `react-markdown` به‌صورت پیش‌فرض raw HTML را خنثی می‌کند |
| اسکن portها                                          | شناسایی سرویس                  | فقط 443 (HTTPS) از بیرون باز؛ 3001 و 5432 firewall‌شده |
| CSRF روی APIها                                       | اقدام در نام کاربر               | NextAuth از CSRF token استفاده می‌کند                |
| SQL injection                                         | افشای داده                       | Prisma به‌طور پیش‌فرض parameterized query می‌سازد   |
| نشتِ پیام‌های یک کاربر به دیگری                       | افشای محرمانه                    | هر query با `userId: session.user.id` فیلتر می‌شود |

## کنترل‌های اصلی

### ۱. گذرواژه‌ها

- bcrypt با cost ۱۰ — تنظیم در `lib/auth.ts`.
- هرگز در پاسخِ API برگردانده نمی‌شود.
- حداقل ۸ کاراکتر در ثبت‌نام (Zod).
- ⚠ پیشنهادی برای v2: محدودیتِ نرخ تلاش ورود (مثلاً ۵ بار در ۱۵ دقیقه).

### ۲. Session

- JWT با `NEXTAUTH_SECRET` (حداقل ۳۲B از `openssl rand -base64 32`).
- کوکی: `HttpOnly`, `Secure`, `SameSite=lax`.
- expiration پیش‌فرضِ NextAuth (۳۰ روز).

### ۳. کلیدهای AI

- فقط در `.env` سرور.
- در docker-compose به‌عنوان environment variable به container تزریق می‌شود.
- توصیه: استفاده از Docker secrets یا Vault برای production جدی.

### ۴. CORS

- API routes پیش‌فرض same-origin هستند. اگر بخواهید subdomain دیگری بزند، باید explicit allow کنید (در v1 نیست).

### ۵. Headers امنیتی

پیشنهاد برای Nginx/Caddy جلوی app:

```
Strict-Transport-Security: max-age=63072000; includeSubDomains; preload
Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; connect-src 'self'; script-src 'self'
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: geolocation=(), microphone=(), camera=()
```

### ۶. Database

- credentialها در `.env` (به‌خصوص در production تغییر دهید — `divband:divband` صرفاً برای dev).
- در docker-compose پورت 5432 به host expose شده — برای production این خط را حذف کنید تا فقط درون شبکه قابل دسترسی باشد.
- backup منظم با `pg_dump`.

### ۷. لاگ

- پیام‌های کاربران در DB ذخیره می‌شوند ولی هرگز در لاگ سرور echo نمی‌شوند.
- خطاهای provider به stderr می‌روند — مراقب باشید کلیدهای API در error message پروایدر leak نشوند.

### ۸. محافظت در برابر prompt injection

پیام‌های attachment با مرزِ روشن ascii fence اضافه می‌شوند:

```
--- فایل: {name} ---
{excerpt}
--- پایان فایل ---
```

این کاملاً بی‌نقص نیست (مدل می‌تواند فریب بخورد) ولی روالِ استاندارد است. برای v2 می‌توان از structured tagهای XML-like استفاده کرد.

## چک‌لیستِ استقرار

- [ ] `NEXTAUTH_SECRET` با `openssl rand -base64 32` تولید شده.
- [ ] Postgres password از پیش‌فرض تغییر کرده.
- [ ] firewall فقط ۴۴۳ را باز کرده؛ ۳۰۰۱ و ۵۴۳۲ مسدودند.
- [ ] HTTPS با Let's Encrypt (Caddy خودکار).
- [ ] HSTS، CSP، X-Frame-Options در reverse proxy.
- [ ] `ALLOWED_EMAILS` تنظیم شده اگر سرویس داخلی است.
- [ ] backup خودکار از volume Postgres (cron + pg_dump).
- [ ] log rotation برای container logها.
- [ ] container با کاربر غیرروت اجرا می‌شود (در Dockerfile انجام شده).

## مسائلِ شناخته‌شده / TODO

- نبودِ rate limiting داخلی — برای production جدی، یک Redis + middleware اضافه کنید.
- نبودِ audit log برای ادمین — در v2.
- نبودِ MFA — در v2.
