// Server-only PDF text extraction. Truncates to a reasonable size.
import pdf from "pdf-parse";

export async function extractPdfText(buf: Buffer, maxChars = 20000): Promise<string> {
  try {
    const data = await pdf(buf);
    const text = (data.text ?? "").replace(/\u0000/g, "").trim();
    if (text.length > maxChars) {
      return text.slice(0, maxChars) + "\n\n…[متن کوتاه شد]…";
    }
    return text;
  } catch (e) {
    return "[خطا در استخراج متنِ PDF]";
  }
}
