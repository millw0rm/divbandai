// Factory that returns a Vercel AI SDK LanguageModel for a given provider+model.
// Supports streaming via streamText(), works with all listed providers.

import { createAnthropic } from "@ai-sdk/anthropic";
import { createOpenAI } from "@ai-sdk/openai";
import { createGoogleGenerativeAI } from "@ai-sdk/google";
import { createMistral } from "@ai-sdk/mistral";
import { createXai } from "@ai-sdk/xai";
import { createOllama } from "ollama-ai-provider";
import type { ProviderId } from "./providers";
import type { LanguageModel } from "ai";

export function getModel(provider: ProviderId, model: string): LanguageModel {
  switch (provider) {
    case "anthropic": {
      const client = createAnthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
      return client(model);
    }
    case "openai": {
      const client = createOpenAI({ apiKey: process.env.OPENAI_API_KEY });
      return client(model);
    }
    case "google": {
      const client = createGoogleGenerativeAI({ apiKey: process.env.GOOGLE_GENERATIVE_AI_API_KEY });
      return client(model);
    }
    case "mistral": {
      const client = createMistral({ apiKey: process.env.MISTRAL_API_KEY });
      return client(model);
    }
    case "xai": {
      const client = createXai({ apiKey: process.env.XAI_API_KEY });
      return client(model);
    }
    case "deepseek": {
      // DeepSeek exposes an OpenAI-compatible endpoint.
      const client = createOpenAI({
        apiKey: process.env.DEEPSEEK_API_KEY,
        baseURL: "https://api.deepseek.com/v1",
      });
      return client(model);
    }
    case "ollama": {
      const client = createOllama({
        baseURL: (process.env.OLLAMA_BASE_URL ?? "http://localhost:11434") + "/api",
      });
      return client(model);
    }
    default: {
      const _exhaustive: never = provider;
      throw new Error(`Unknown provider: ${_exhaustive}`);
    }
  }
}
