import type { NextAuthOptions } from "next-auth";
import { getServerSession } from "next-auth";
import { authOptions } from "./auth";

export async function requireSession() {
  const session = await getServerSession(authOptions as NextAuthOptions);
  if (!session?.user) throw new Error("UNAUTHENTICATED");
  return session as typeof session & { user: { id: string; email: string; name?: string | null } };
}
