// Central registry of providers + their models. Adding a new model = one line.
// Each provider gets a thin factory in `lib/ai.ts` so we can pick at runtime.

export type ProviderId =
  | "openai"
  | "anthropic"
  | "google"
  | "mistral"
  | "deepseek"
  | "xai"
  | "ollama";

export type ModelMeta = {
  id: string;            // canonical model id sent to the provider
  label: string;         // farsi-friendly display name
  vision?: boolean;      // accepts images
  reasoning?: boolean;   // long-thinking / o1-style
  context?: string;      // human-readable context window note
};

export type Provider = {
  id: ProviderId;
  label: string;         // farsi label for UI
  env: string;           // env var that must be set
  models: ModelMeta[];
};

export const PROVIDERS: Provider[] = [
  {
    id: "anthropic",
    label: "Anthropic — Claude",
    env: "ANTHROPIC_API_KEY",
    models: [
      { id: "claude-3-5-sonnet-latest", label: "Claude 3.5 Sonnet",  vision: true,  context: "200k" },
      { id: "claude-3-5-haiku-latest",  label: "Claude 3.5 Haiku",                 context: "200k" },
      { id: "claude-3-opus-latest",     label: "Claude 3 Opus",      vision: true, context: "200k" },
    ],
  },
  {
    id: "openai",
    label: "OpenAI — GPT",
    env: "OPENAI_API_KEY",
    models: [
      { id: "gpt-4o",        label: "GPT-4o",       vision: true,  context: "128k" },
      { id: "gpt-4o-mini",   label: "GPT-4o mini",  vision: true,  context: "128k" },
      { id: "o1",            label: "o1 (reasoning)", reasoning: true, context: "128k" },
      { id: "o1-mini",       label: "o1-mini",      reasoning: true, context: "128k" },
    ],
  },
  {
    id: "google",
    label: "Google — Gemini",
    env: "GOOGLE_GENERATIVE_AI_API_KEY",
    models: [
      { id: "gemini-1.5-pro-latest",   label: "Gemini 1.5 Pro",   vision: true, context: "2M" },
      { id: "gemini-1.5-flash-latest", label: "Gemini 1.5 Flash", vision: true, context: "1M" },
    ],
  },
  {
    id: "deepseek",
    label: "DeepSeek",
    env: "DEEPSEEK_API_KEY",
    models: [
      { id: "deepseek-chat",      label: "DeepSeek V3",                context: "64k" },
      { id: "deepseek-reasoner",  label: "DeepSeek R1 (reasoning)", reasoning: true, context: "64k" },
    ],
  },
  {
    id: "mistral",
    label: "Mistral",
    env: "MISTRAL_API_KEY",
    models: [
      { id: "mistral-large-latest", label: "Mistral Large", context: "128k" },
      { id: "codestral-latest",     label: "Codestral",     context: "32k"  },
    ],
  },
  {
    id: "xai",
    label: "xAI — Grok",
    env: "XAI_API_KEY",
    models: [
      { id: "grok-2-latest",        label: "Grok 2",                       context: "128k" },
      { id: "grok-2-vision-latest", label: "Grok 2 Vision", vision: true,  context: "128k" },
    ],
  },
  {
    id: "ollama",
    label: "Ollama — Local",
    env: "OLLAMA_BASE_URL",
    models: [
      { id: "llama3.2",  label: "Llama 3.2 (local)" },
      { id: "qwen2.5",   label: "Qwen 2.5 (local)" },
      { id: "mistral",   label: "Mistral 7B (local)" },
      { id: "phi3",      label: "Phi-3 (local)" },
    ],
  },
];

export function getProvider(id: string): Provider | undefined {
  return PROVIDERS.find((p) => p.id === id);
}

export function isProviderConfigured(p: Provider): boolean {
  if (p.id === "ollama") return true; // optional base url, can default
  return !!process.env[p.env];
}

export function activeProviders(): Provider[] {
  return PROVIDERS.filter(isProviderConfigured);
}
