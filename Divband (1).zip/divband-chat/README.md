# Divband Chat — chat.divband.com

پلتفرمِ گفت‌وگو با مدل‌های زبانیِ متعدد. یک رابطِ یکسان برای GPT، Claude، Gemini، DeepSeek، Mistral، Grok و Ollama (محلی).

## امکانات v1

- ورود/ثبت‌نام با ایمیل + گذرواژه (NextAuth credentials)
- ذخیره‌سازی گفت‌وگوها در Postgres (Prisma)
- پاسخِ زنده (streaming) از همه‌ی مدل‌ها
- رندر Markdown + کد با هایلایت
- پیوست فایل (PDF و فایل‌های متنی) — متن استخراج و به سیستم پرامپت اضافه می‌شود
- System prompt اختصاصی برای هر گفت‌وگو
- خروجی Markdown و JSON
- رابطِ فارسی (RTL) با تمِ روشنِ همراهِ سایتِ اصلی

## استک

| لایه       | فناوری                                                     |
|-----------|------------------------------------------------------------|
| فریم‌ورک   | Next.js 14 (App Router) + TypeScript                       |
| AI        | Vercel AI SDK (`ai`) با providerهای OpenAI/Anthropic/Google/Mistral/xAI، DeepSeek (OpenAI‑compat)، Ollama |
| پایگاه    | Postgres 16 + Prisma                                       |
| احراز هویت | NextAuth v4 + Credentials + Prisma adapter                 |
| استایل    | CSS خام (تم سایت divband.com)                              |
| اجرا      | Docker + docker-compose                                    |

## شروع سریع

### الف) لوکال (Node + Postgres محلی)

```bash
cd divband-chat
cp .env.example .env
# .env را ویرایش کنید (NEXTAUTH_SECRET و کلید(های) AI)
docker run -d --name pg -p 5432:5432 \
  -e POSTGRES_USER=divband -e POSTGRES_PASSWORD=divband -e POSTGRES_DB=divband_chat \
  postgres:16-alpine
npm install
npm run db:push    # یا: npm run db:migrate
npm run dev        # http://localhost:3001
```

### ب) Docker Compose (توصیه‌شده برای VPS)

```bash
cd divband-chat
cp .env.example .env
# .env را ویرایش کنید
docker compose up -d --build
# سرویس روی پورتِ 3001 بالا می‌آید
```

برای دامنه‌ی `chat.divband.com` یک reverse proxy (Nginx/Caddy) جلوِ کانتینر بگذارید.
نمونه Caddyfile:

```
chat.divband.com {
  reverse_proxy localhost:3001
}
```

### تولیدِ NEXTAUTH_SECRET

```bash
openssl rand -base64 32
```

## کلیدهای AI

در `.env` کلیدهایی که می‌خواهید فعال شوند را تنظیم کنید — UI خودش فقط providerهایی که کلید دارند را نشان می‌دهد.

| Provider    | Env Var                          |
|------------|----------------------------------|
| OpenAI     | `OPENAI_API_KEY`                 |
| Anthropic  | `ANTHROPIC_API_KEY`              |
| Google     | `GOOGLE_GENERATIVE_AI_API_KEY`   |
| Mistral    | `MISTRAL_API_KEY`                |
| DeepSeek   | `DEEPSEEK_API_KEY`               |
| xAI (Grok) | `XAI_API_KEY`                    |
| Ollama     | `OLLAMA_BASE_URL` (اختیاری)      |

### Ollama محلی

اگر Ollama روی همان ماشین در حال اجراست:

- اجرای لوکال: `OLLAMA_BASE_URL=http://localhost:11434`
- داخل docker-compose: `OLLAMA_BASE_URL=http://host.docker.internal:11434`

## افزودنِ مدلِ جدید

فقط یک ردیف به `lib/providers.ts` اضافه کنید. مثلاً مدلِ جدیدِ OpenAI:

```ts
{ id: "gpt-4.1", label: "GPT-4.1", vision: true, context: "256k" }
```

برای providerِ جدید (مثلاً Together، Groq)، یک case در `lib/ai.ts` اضافه کنید — معمولاً همان `createOpenAI` با `baseURL` دیگر کافی است.

## نقشه‌ی راه

نسخه‌ی کامل در [`docs/roadmap.md`](./docs/roadmap.md).

- [ ] نمای **مقایسه** (یک سؤال، چند مدل کنار هم)
- [ ] ورودی تصویر برای vision models
- [ ] سامانه‌ی پروژه/پوشه برای گفت‌وگوها
- [ ] جست‌وجو در تاریخچه‌ی گفت‌وگوها
- [ ] ابزارها (web search, code interpreter) با Vercel AI SDK tools API
- [ ] OAuth (Google) به جز Credentials

## مستندات

تمامِ مستنداتِ تولیدی در پوشه‌ی [`docs/`](./docs):

| فایل                                              | محتوا                                                              |
|---------------------------------------------------|---------------------------------------------------------------------|
| [`docs/PRD.md`](./docs/PRD.md)                    | الزاماتِ تولیدی، اهداف، تعریف Done                                  |
| [`docs/architecture.md`](./docs/architecture.md)  | معماری سیستم، جریان داده، تصمیم‌های فنی                            |
| [`docs/api.md`](./docs/api.md)                    | مرجعِ کامل API                                                       |
| [`docs/design-system.md`](./docs/design-system.md) | توکن‌ها، تایپوگرافی، کامپوننت‌ها                                  |
| [`docs/design-tokens.json`](./docs/design-tokens.json) | توکن‌ها برای Figma Tokens Studio                              |
| [`docs/style-guide.html`](./docs/style-guide.html) | راهنمای بصریِ زنده                                                |
| [`docs/security.md`](./docs/security.md)          | مدل تهدید و کنترل‌ها                                                |
| [`docs/deployment.md`](./docs/deployment.md)      | راهنمای استقرار با Caddy/Nginx                                    |
| [`docs/roadmap.md`](./docs/roadmap.md)            | نقشه‌ی راه v1 → v3                                                  |

## ساختارِ پروژه

```
app/
  (auth)/login/page.tsx
  (auth)/register/page.tsx
  api/auth/[...nextauth]/route.ts
  api/chat/route.ts           ← streaming endpoint
  api/conversations/route.ts  ← list, create
  api/conversations/[id]/route.ts
  api/register/route.ts
  api/upload/route.ts         ← PDF + text extraction
  chat/page.tsx               ← new conversation
  chat/[id]/page.tsx          ← existing conversation
  chat/layout.tsx             ← sidebar + main
  globals.css
  layout.tsx
  page.tsx                    ← redirect
components/
  ChatView.tsx                ← composer + stream loop
  Message.tsx                 ← markdown + code highlight
  ModelPicker.tsx
  Sidebar.tsx
lib/
  ai.ts                       ← provider → LanguageModel factory
  auth.ts                     ← NextAuth options
  db.ts                       ← Prisma singleton
  pdf.ts                      ← PDF text extract
  providers.ts                ← model registry
  session.ts
prisma/schema.prisma
Dockerfile, docker-compose.yml
middleware.ts
```
