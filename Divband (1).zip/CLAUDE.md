# CLAUDE.md — Divband (project source of truth)

> Auto-loaded into every conversation in this project. Keep it short. It is a **map**, not the territory — details live in the linked docs.

## What this project is

**Divband** is building an **agent-first instant-hosting / deployment platform** — think "deploy and host sites & apps, drivable by both humans (dashboard) and AI agents (MCP + REST + OpenAPI)." The fastest credible MVP is **instant static hosting** (upload files → publish a version → serve at a URL/domain), with a broader **full project-hosting** path (GitLab + Kubernetes + DNS + TLS) behind it.

There are **two distinct codebases** under the Divband brand — do not confuse them:

| Product | What it is | Where it lives in this project |
|---|---|---|
| **Divband Platform** | The instant-hosting / deployment platform (this is the MVP we are driving). | Source code lives outside this design project (`/workspace/divband`, not yet uploaded). Design + product docs are here. |
| **Divband Chat** | A separate multi-LLM chat app (`chat.divband.com`). | `uploads/Divband/` (code) + `prototype/` (hi-fi prototype) + `index.html` (marketing site). |

## Where the truth lives (read these before planning)

- **`docs-product/PRODUCT.md`** — vision, target users, MVP definition, scope boundaries, release phases, acceptance criteria. *Start here.*
- **`docs-product/STATUS.md`** — current build state, prioritized gap backlog (from the QA review), risks, assumptions, decisions, and the ordered **"next to build"** list. *Update this every working session.*
- **`docs-product/product-hub.html`** — a live visual dashboard of the roadmap + status (renders the two docs above).
- **`platform/`** — the multi-page dashboard **design prototype** for the Platform (HTML/React).

## Design system (shared across both products)

Navy accent `#1e3a8a`, off-white `#fafaf7`, **Vazirmatn** (sans) + **JetBrains Mono**, RTL Persian-first. Full tokens in `uploads/Divband/docs/design-tokens.json` and `uploads/Divband/docs/design-system.md`. Reuse these — don't invent new colors/type.

## How to work here

1. **Read PRODUCT.md + STATUS.md first.** They are the anti-"starting from scratch" mechanism.
2. When something changes (a gap closed, a decision made, scope cut), **edit STATUS.md** so the next session inherits it.
3. This is a **design environment**: deliverables are HTML/Markdown artifacts, not a running backend. Infra/backend code is referenced and designed-for here, but executed elsewhere.

## Current phase

**Phase 0 → Phase 1.** Skeleton exists (routes, models, in-memory stores, infra templates). Nothing runs end-to-end yet. The immediate goal is a **runnable agent-first instant-static-hosting MVP**. See STATUS.md for the exact next steps.
