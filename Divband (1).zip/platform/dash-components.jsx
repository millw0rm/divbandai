/* ══════════════════════════════════════════════════════════════
   Divband Platform — shared dashboard components
   Exports: useToast, Toaster, Badge, StatusBadge, Rail, Topbar,
            Kpi, Card, CodeBlock, Fav, EmptyState
   ══════════════════════════════════════════════════════════════ */
const { useState, useRef, useEffect, useCallback, createContext, useContext } = React;

/* ── toasts ──────────────────────────────────────────────────── */
const ToastCtx = createContext(() => {});
const useToast = () => useContext(ToastCtx);
function Toaster({ children }) {
  const [items, setItems] = useState([]);
  const push = useCallback((msg, mono) => {
    const id = Math.random();
    setItems((t) => [...t, { id, msg, mono }]);
    setTimeout(() => setItems((t) => t.filter((x) => x.id !== id)), 2400);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="toast-host">
        {items.map((t) => <div key={t.id} className="toast"><span>{t.msg}</span>{t.mono && <span className="mono">{t.mono}</span>}</div>)}
      </div>
    </ToastCtx.Provider>
  );
}

/* ── badges ──────────────────────────────────────────────────── */
function Badge({ cls, children }) {
  return <span className={"badge" + (cls ? " " + cls : "")}>{cls && cls !== "agent" ? <span className="dot"></span> : null}{children}</span>;
}
function StatusBadge({ status }) {
  const s = window.STATUS_BADGE[status] || { cls: "", label: status };
  return <Badge cls={s.cls}>{s.label}</Badge>;
}
function Fav({ color, initial }) {
  return <span className="fav" style={{ background: (color || "#0a0f1f") + "14", color: color || "#0a0f1f", borderColor: (color || "#0a0f1f") + "33" }}>{initial}</span>;
}

/* ── KPI / Card ──────────────────────────────────────────────── */
function Kpi({ label, value, delta, icon }) {
  return (
    <div className="card kpi">
      <div className="lbl">{icon && <span>{icon}</span>}{label}</div>
      <div className="val">{value}</div>
      {delta && <div className="delta">{delta}</div>}
    </div>
  );
}

/* ── code block w/ copy + light token highlight ──────────────── */
function hi(code) {
  let h = code.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  h = h.replace(/(#.*$)/gm, '<span class="tc">$1</span>');
  h = h.replace(/(&quot;[^&]*?&quot;|"[^"]*"|'[^']*')/g, '<span class="ts">$1</span>');
  h = h.replace(/\b(curl|npx|POST|GET|Bearer|divband|login|deploy)\b/g, '<span class="tk">$1</span>');
  h = h.replace(/\b(v\d+)\b/g, '<span class="tn">$1</span>');
  return h;
}
function CodeBlock({ code, lang }) {
  const toast = useToast();
  return (
    <div className="code">
      <button className="cp" onClick={() => { navigator.clipboard?.writeText(code).catch(()=>{}); toast("کپی شد"); }}>کپی</button>
      <pre style={{ margin: 0, fontFamily: "inherit" }} dangerouslySetInnerHTML={{ __html: hi(code) }} />
    </div>
  );
}

function EmptyState({ icon, title, sub, action }) {
  return (
    <div className="empty">
      <div className="e1">{icon || "◇"}</div>
      <div style={{ fontSize: 16, fontWeight: 600, color: "var(--text)" }}>{title}</div>
      {sub && <div style={{ marginTop: 6 }}>{sub}</div>}
      {action && <div style={{ marginTop: 16 }}>{action}</div>}
    </div>
  );
}

/* ── Nav rail ────────────────────────────────────────────────── */
const NAV = [
  { group: "میزبانی" },
  { id: "overview", ico: "▦", label: "نمای کلی" },
  { id: "projects", ico: "▣", label: "پروژه‌ها", count: () => window.PROJECTS.length },
  { id: "deployments", ico: "⇡", label: "استقرارها", count: () => window.DEPLOYMENTS.filter(d=>d.status==="building"||d.status==="queued").length || null },
  { id: "publish", ico: "⬆", label: "انتشارِ فوری" },
  { id: "domains", ico: "◈", label: "دامنه‌ها", count: () => window.DOMAINS.filter(d=>!d.verified).length || null },
  { group: "عامل‌ها" },
  { id: "ai", ico: "❖", label: "تغییراتِ هوش مصنوعی", agent: true },
  { id: "api", ico: "⧉", label: "API و عامل‌ها", agent: true },
  { group: "حساب" },
  { id: "settings", ico: "⚙", label: "تنظیمات" },
  { id: "product", ico: "◳", label: "سندِ محصول" },
];

function Rail({ page, go, user }) {
  return (
    <aside className="rail">
      <div className="rail-head">
        <div className="brand" onClick={() => go("overview")}>
          <span className="mark">◇</span>
          <div><div className="word">DIVBAND<span className="sub">/platform</span></div></div>
        </div>
        <span className="env-pill">MVP</span>
      </div>
      <nav className="rail-nav">
        {NAV.map((n, i) => n.group ? (
          <div key={i} className="nav-group">{n.group}</div>
        ) : (
          <a key={n.id} className={"nav-item" + (page === n.id ? " active" : "")} onClick={() => go(n.id)}>
            <span className="ico">{n.ico}</span>
            <span className="lbl">{n.label}</span>
            {n.agent && <span className="agent-dot" title="قابل‌استفاده توسط عامل"></span>}
            {n.count && n.count() ? <span className="count">{n.count()}</span> : null}
          </a>
        ))}
      </nav>
      <div className="rail-foot">
        <div className="agent-card">
          <div className="hd"><span className="live"></span>عاملِ متصل</div>
          <div className="ln">claude-agent · MCP</div>
          <div className="ln">۲ عملیات در ۱ ساعتِ اخیر</div>
        </div>
        <div className="user-row">
          <span className="avatar-sm">ن‌م</span>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="nm">{user.name}</div>
            <div className="em">{user.email}</div>
          </div>
          <span className="icon-btn" style={{ width: 28, height: 28 }} title="خروج" onClick={() => go("auth")}>→</span>
        </div>
      </div>
    </aside>
  );
}

/* ── Topbar ──────────────────────────────────────────────────── */
function Topbar({ crumbs, actions }) {
  return (
    <div className="topbar">
      <div className="crumbs">
        {crumbs.map((c, i) => (
          <React.Fragment key={i}>
            {i > 0 && <span className="sep">/</span>}
            <span className={i === crumbs.length - 1 ? "h" : "dim"}>{c}</span>
          </React.Fragment>
        ))}
      </div>
      <div className="grow"></div>
      <div className="topsearch">
        <span className="muted">⌕</span>
        <input placeholder="جست‌وجوی پروژه، دامنه، استقرار…" />
        <span className="k">⌘K</span>
      </div>
      {actions}
    </div>
  );
}

Object.assign(window, { useToast, Toaster, Badge, StatusBadge, Fav, Kpi, CodeBlock, EmptyState, Rail, Topbar, NAV });
