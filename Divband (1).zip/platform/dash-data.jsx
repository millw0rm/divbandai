/* ══════════════════════════════════════════════════════════════
   Divband Platform — dashboard mock data
   ══════════════════════════════════════════════════════════════ */

const PROJECTS = [
  { id: "p1", name: "negar-portfolio", type: "static", color: "#12a150", initial: "N",
    url: "negar-portfolio.divband.app", domain: "negar.dev", status: "live", framework: "Vite",
    lastDeploy: "۸ دقیقه پیش", versions: 14, agent: false },
  { id: "p2", name: "shop-landing", type: "static", color: "#0b140f", initial: "S",
    url: "shop-landing.divband.app", domain: null, status: "live", framework: "Astro",
    lastDeploy: "۲ ساعت پیش", versions: 31, agent: true },
  { id: "p3", name: "docs-site", type: "static", color: "#0c7a3c", initial: "D",
    url: "docs-site.divband.app", domain: "docs.divband.com", status: "building", framework: "Next export",
    lastDeploy: "همین حالا", versions: 7, agent: true },
  { id: "p4", name: "api-gateway", type: "project", color: "#18c065", initial: "A",
    url: "api-gateway.divband.app", domain: null, status: "queued", framework: "Node · GitLab",
    lastDeploy: "۱ روز پیش", versions: 3, agent: false },
  { id: "p5", name: "marketing-2026", type: "static", color: "#4c554f", initial: "M",
    url: "marketing-2026.divband.app", domain: "go.divband.com", status: "failed", framework: "Static",
    lastDeploy: "۳ روز پیش", versions: 22, agent: false },
];

const STATUS_BADGE = {
  live:     { cls: "ok",   label: "آنلاین" },
  building: { cls: "run",  label: "در حال ساخت" },
  queued:   { cls: "warn", label: "در صف" },
  failed:   { cls: "err",  label: "ناموفق" },
  ready:    { cls: "ok",   label: "آماده" },
};

const DEPLOYMENTS = [
  { id: "dpl_9f2a", project: "docs-site", status: "building", trigger: "agent", who: "claude-agent", branch: "main", commit: "a1b2c3d", msg: "افزودن صفحه‌ی شروع سریع", dur: "—", when: "همین حالا" },
  { id: "dpl_8e1b", project: "negar-portfolio", status: "live", trigger: "upload", who: "negar@divband.com", branch: "—", commit: "—", msg: "انتشار فوریِ خروجی build", dur: "11s", when: "۸ دقیقه پیش" },
  { id: "dpl_7c44", project: "shop-landing", status: "live", trigger: "agent", who: "mcp-token", branch: "main", commit: "f0a9921", msg: "به‌روزرسانی بنرِ فروش", dur: "19s", when: "۲ ساعت پیش" },
  { id: "dpl_6b30", project: "shop-landing", status: "live", trigger: "api", who: "ci-token", branch: "main", commit: "9921aa0", msg: "ساختِ خودکارِ شبانه", dur: "22s", when: "دیروز" },
  { id: "dpl_5a18", project: "marketing-2026", status: "failed", trigger: "upload", who: "negar@divband.com", branch: "—", commit: "—", msg: "اسکنر: فایلِ مشکوک رد شد", dur: "4s", when: "۳ روز پیش" },
  { id: "dpl_4f07", project: "api-gateway", status: "queued", trigger: "agent", who: "claude-agent", branch: "feat/auth", commit: "33cd001", msg: "منتظرِ runner", dur: "—", when: "۱ روز پیش" },
];

const VERSIONS = [
  { v: "v14", status: "live", size: "2.4 MB", files: 38, checksum: "sha256:8f3a…d2", when: "۸ دقیقه پیش", by: "آپلود", scan: "pass" },
  { v: "v13", status: "ready", size: "2.4 MB", files: 37, checksum: "sha256:1c90…7a", when: "دیروز", by: "آپلود", scan: "pass" },
  { v: "v12", status: "ready", size: "2.3 MB", files: 36, checksum: "sha256:b40e…11", when: "۲ روز پیش", by: "agent", scan: "pass" },
  { v: "v11", status: "ready", size: "2.3 MB", files: 36, checksum: "sha256:77af…9c", when: "۴ روز پیش", by: "آپلود", scan: "pass" },
];

const DOMAINS = [
  { host: "negar.dev", project: "negar-portfolio", verified: true, cert: "active", certExp: "۸۹ روز", added: "۲ هفته پیش" },
  { host: "docs.divband.com", project: "docs-site", verified: true, cert: "active", certExp: "۹۰ روز", added: "۱ هفته پیش" },
  { host: "go.divband.com", project: "marketing-2026", verified: false, cert: "pending", certExp: "—", added: "۱ روز پیش" },
];

const DNS_RECORDS = [
  { type: "A", name: "@", value: "76.76.21.21", ttl: "3600" },
  { type: "CNAME", name: "www", value: "cname.divband.app", ttl: "3600" },
  { type: "TXT", name: "_divband", value: "divband-verify=8f3a2c9d1b", ttl: "3600" },
];

const AI_CHANGES = [
  { id: "chg_31", project: "docs-site", title: "افزودن بخشِ «شروع سریع» به مستندات", agent: "claude-agent",
    status: "review", mr: "!42", ci: "passing", files: 3, add: 64, del: 8, when: "۱۲ دقیقه پیش" },
  { id: "chg_30", project: "shop-landing", title: "بهینه‌سازیِ تصاویرِ صفحه‌ی محصول", agent: "claude-agent",
    status: "merged", mr: "!41", ci: "passing", files: 6, add: 21, del: 140, when: "۳ ساعت پیش" },
  { id: "chg_29", project: "api-gateway", title: "افزودنِ rate-limit به مسیرِ ورود", agent: "claude-agent",
    status: "ci", mr: "!40", ci: "running", files: 2, add: 38, del: 4, when: "دیروز" },
  { id: "chg_28", project: "negar-portfolio", title: "اصلاحِ کنتراستِ متن در حالتِ تیره", agent: "claude-agent",
    status: "draft", mr: "—", ci: "—", files: 1, add: 5, del: 5, when: "۲ روز پیش" },
];

const AI_STATUS = {
  draft:  { cls: "warn", label: "پیش‌نویس" },
  ci:     { cls: "run",  label: "CI در حال اجرا" },
  review: { cls: "run",  label: "در انتظارِ بازبینی" },
  merged: { cls: "ok",   label: "ادغام‌شده" },
};

const DIFF_SAMPLE = [
  { t: "dh", s: "docs/quickstart.md  +64 −8" },
  { t: "ctx", s: " # شروع سریع" },
  { t: "add", s: "+ نصب: `npm i -g divband`" },
  { t: "add", s: "+ ورود:  `divband login`" },
  { t: "add", s: "+ انتشار: `divband deploy ./dist`" },
  { t: "ctx", s: " " },
  { t: "del", s: "- TODO: نوشتنِ راهنمای نصب" },
  { t: "add", s: "+ در کمتر از ۶۰ ثانیه یک URL زنده بگیرید." },
];

const TOKENS = [
  { name: "ci-deploy", prefix: "dvb_live_8f3a", scope: "publish:write", created: "۲ هفته پیش", lastUsed: "۲ ساعت پیش" },
  { name: "mcp-agent", prefix: "dvb_live_1c90", scope: "publish:write, projects:read", created: "۱ هفته پیش", lastUsed: "همین حالا" },
  { name: "readonly-status", prefix: "dvb_live_b40e", scope: "projects:read", created: "۳ روز پیش", lastUsed: "دیروز" },
];

const ENV_VARS = [
  { key: "API_BASE_URL", val: "https://api.divband.app", secret: false, scope: "همه‌ی محیط‌ها" },
  { key: "ANALYTICS_ID", val: "G-XXXXXXX", secret: false, scope: "production" },
  { key: "STORAGE_SIGNING_KEY", val: "••••••••••••••••", secret: true, scope: "production" },
  { key: "SCANNER_TOKEN", val: "••••••••••••••••", secret: true, scope: "همه‌ی محیط‌ها" },
];

const AGENT_FEED = [
  { ag: true,  tx: "<b>claude-agent</b> یک نسخه‌ی جدید برای <b>shop-landing</b> منتشر کرد", mt: "از طریق MCP · ۲ ساعت پیش" },
  { ag: true,  tx: "<b>claude-agent</b> یک merge request برای <b>docs-site</b> باز کرد", mt: "تغییرِ هوش مصنوعی · ۱۲ دقیقه پیش" },
  { ag: false, tx: "<b>negar</b> دامنه‌ی <b>negar.dev</b> را تأیید کرد", mt: "داشبورد · ۱ روز پیش" },
  { ag: true,  tx: "<b>ci-token</b> ساختِ شبانه‌ی <b>shop-landing</b> را اجرا کرد", mt: "از طریق REST · دیروز" },
];

// llms.txt / snippets
const SNIPPET_CURL = `curl -X POST https://api.divband.app/v1/publish \\
  -H "Authorization: Bearer dvb_live_…" \\
  -F "project=negar-portfolio" \\
  -F "dir=@./dist"
# → { "url": "https://negar-portfolio.divband.app", "version": "v15" }`;

const SNIPPET_MCP = `{
  "mcpServers": {
    "divband": {
      "command": "npx",
      "args": ["-y", "@divband/mcp-server"],
      "env": { "DIVBAND_TOKEN": "dvb_live_…" }
    }
  }
}`;

// roadmap (mirrors STATUS.md) for product-hub
const PHASES = [
  { id: "P0", name: "اسکلت", state: "done", desc: "مسیرها، مدل‌ها، ذخیره‌ی موقت در حافظه، قالب‌های infra، MCP/OpenAPI." },
  { id: "P1", name: "MVP اجراشدنیِ میزبانیِ فوری", state: "active", desc: "سرورِ HTTP، DB و migration، آپلودِ presigned، gateِ اسکن، حلقه‌ی publish→serve، auth ایمن، استک محلی." },
  { id: "P2", name: "دامنه‌ی اختصاصی و TLS", state: "todo", desc: "تأییدِ DNS، صدورِ گواهی، مسیریابیِ دامنه در لایه‌ی serving." },
  { id: "P3", name: "حلقه‌ی تغییرِ عامل", state: "todo", desc: "فراخوانیِ واقعیِ مدل، خواندنِ مخزن، diff واقعی، branch و MR، CI/پیش‌نمایش." },
  { id: "P4", name: "میزبانیِ کاملِ پروژه", state: "todo", desc: "آداپتورهای واقعیِ GitLab + Kubernetes + Terraform؛ runnerها؛ namespace و route." },
];

const GAPS = [
  { id: "G2", t: "بک‌اند به‌عنوانِ سرویس اجرا نمی‌شود", phase: "P1", pri: "blocker", eff: "L" },
  { id: "G4", t: "حلقه‌ی انتشارِ فوری ناقص است", phase: "P1", pri: "blocker", eff: "L" },
  { id: "G6", t: "auth و secret امن نیست", phase: "P1", pri: "high", eff: "M" },
  { id: "G5", t: "فرانت‌اند قابلِ استقرار نیست", phase: "P1", pri: "high", eff: "M" },
  { id: "G8", t: "استک محلیِ تک‌فرمانی وجود ندارد", phase: "P1", pri: "high", eff: "M" },
  { id: "G1", t: "سندِ محصولِ مرجع (حل شد)", phase: "—", pri: "high", eff: "S", done: true },
  { id: "G3", t: "آداپتورهای infra placeholder هستند", phase: "P2/P4", pri: "med", eff: "XL" },
  { id: "G7", t: "گردش‌کارِ هوش مصنوعی شبیه‌سازی‌شده است", phase: "P3", pri: "med", eff: "XL" },
];

const PRI_BADGE = { blocker: { cls: "err", label: "مسدودکننده" }, high: { cls: "warn", label: "بالا" }, med: { cls: "run", label: "متوسط" } };

Object.assign(window, {
  PROJECTS, STATUS_BADGE, DEPLOYMENTS, VERSIONS, DOMAINS, DNS_RECORDS,
  AI_CHANGES, AI_STATUS, DIFF_SAMPLE, TOKENS, ENV_VARS, AGENT_FEED,
  SNIPPET_CURL, SNIPPET_MCP, PHASES, GAPS, PRI_BADGE,
});
