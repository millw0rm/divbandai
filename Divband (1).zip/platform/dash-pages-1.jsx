/* ══════════════════════════════════════════════════════════════
   Divband Platform — pages (1/2)
   PageOverview · PageProjects · PageProjectDetail · PageDeployments · PagePublish
   ══════════════════════════════════════════════════════════════ */
const { useState: pUseState, useRef: pUseRef, useEffect: pUseEffect } = React;

/* ── Overview ────────────────────────────────────────────────── */
function PageOverview({ go }) {
  const toast = useToast();
  const live = window.PROJECTS.filter((p) => p.status === "live").length;
  const building = window.DEPLOYMENTS.filter((d) => d.status === "building" || d.status === "queued").length;
  return (
    <div className="page">
      <div className="page-head">
        <div>
          <div className="pt">نمای کلی</div>
          <div className="ps">میزبانیِ فوریِ سایت‌ها و اپ‌ها — قابلِ هدایت هم با داشبورد و هم توسطِ عامل‌های هوش مصنوعی از طریقِ MCP و REST.</div>
        </div>
        <div className="grow"></div>
        <button className="btn btn-ghost" onClick={() => go("api")}>⧉ اتصالِ عامل</button>
        <button className="btn btn-grad" onClick={() => go("publish")}>⬆ انتشارِ فوری</button>
      </div>

      <div className="grid cards-4">
        <Kpi label="پروژه‌های آنلاین" value={live} delta={<>از مجموعِ {window.PROJECTS.length} پروژه</>} icon="▣" />
        <Kpi label="استقرارهای فعال" value={building} delta={<><b>۲</b> توسطِ عامل</>} icon="⇡" />
        <Kpi label="دامنه‌های متصل" value={window.DOMAINS.length} delta={<>۱ در انتظارِ تأیید</>} icon="◈" />
        <Kpi label="عملیاتِ عامل (۲۴ساعت)" value="38" delta={<><b>۱۰۰٪</b> پوششِ API</>} icon="❖" />
      </div>

      <div className="grid cards-2" style={{ marginTop: 14, gridTemplateColumns: "1.4fr 1fr" }}>
        <div className="card pad-lg">
          <div className="card-hd"><span className="ct">استقرارهای اخیر</span><div className="grow"></div><span className="more" onClick={() => go("deployments")}>همه ←</span></div>
          <div className="list">
            {window.DEPLOYMENTS.slice(0, 4).map((d) => (
              <div className="row" key={d.id} onClick={() => go("deployments")}>
                <span className="fav" style={{ fontSize: 11 }}>{d.trigger === "agent" ? "❖" : d.trigger === "api" ? "⧉" : "⬆"}</span>
                <div className="grow col">
                  <span className="nm">{d.project} <span className="muted mono" style={{ fontWeight: 400, fontSize: 11 }}>{d.commit !== "—" ? d.commit : ""}</span></span>
                  <span className="meta">{d.msg} · {d.who}</span>
                </div>
                <StatusBadge status={d.status} />
                <span className="meta" style={{ marginTop: 0, width: 70, textAlign: "left" }}>{d.when}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="card pad-lg">
          <div className="card-hd"><span className="ct">فعالیتِ عامل‌ها و کاربران</span></div>
          <div className="agent-feed">
            {window.AGENT_FEED.map((f, i) => (
              <div className={"feed-item" + (f.ag ? " ag" : "")} key={i}>
                <span className="feed-ico">{f.ag ? "❖" : "◌"}</span>
                <div>
                  <div className="feed-tx" dangerouslySetInnerHTML={{ __html: f.tx }} />
                  <div className="feed-mt">{f.mt}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="card-dark pad-lg" style={{ marginTop: 14, display: "flex", alignItems: "center", gap: 18, padding: 22 }}>
        <div style={{ flex: 1, position: "relative" }}>
          <div style={{ fontSize: 16, fontWeight: 600, marginBottom: 4 }}>هر کاری در داشبورد، یک معادلِ API دارد</div>
          <div className="muted" style={{ fontSize: 13, lineHeight: 1.6 }}>عامل‌ها می‌توانند پروژه بسازند، منتشر کنند و دامنه وصل کنند — بدونِ هیچ مرحله‌ی انسانی. مستنداتِ OpenAPI و MCP آماده است.</div>
        </div>
        <button className="btn btn-ghost btn-sm" style={{ background: "rgba(255,255,255,.06)", borderColor: "rgba(255,255,255,.2)", color: "#fff", position: "relative" }} onClick={() => { navigator.clipboard?.writeText("npx -y @divband/mcp-server"); toast("دستورِ MCP کپی شد", "npx @divband/mcp-server"); }}>کپیِ دستورِ MCP</button>
        <button className="btn btn-grad btn-sm" style={{ position: "relative" }} onClick={() => go("api")}>مشاهده‌ی API ←</button>
      </div>
    </div>
  );
}

/* ── Projects list ───────────────────────────────────────────── */
function PageProjects({ go, openProject }) {
  return (
    <div className="page">
      <div className="page-head">
        <div><div className="pt">پروژه‌ها</div><div className="ps">هر پروژه یک سایت یا اپ است که نسخه‌هایش به‌صورتِ تغییرناپذیر نگه‌داری و سرو می‌شوند.</div></div>
        <div className="grow"></div>
        <button className="btn btn-primary">＋ پروژه‌ی جدید</button>
      </div>
      <div className="list">
        {window.PROJECTS.map((p) => (
          <div className="row" key={p.id} onClick={() => openProject(p.id)}>
            <Fav color={p.color} initial={p.initial} />
            <div className="grow col">
              <span className="nm">{p.name} {p.agent && <Badge cls="agent">❖ عامل</Badge>}</span>
              <span className="meta">{p.domain || p.url} · {p.framework} · {p.versions} نسخه</span>
            </div>
            <StatusBadge status={p.status} />
            <span className="meta" style={{ width: 90, textAlign: "left", marginTop: 0 }}>{p.lastDeploy}</span>
            <span className="chev">‹</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ── Project detail ──────────────────────────────────────────── */
function PageProjectDetail({ projectId, go }) {
  const toast = useToast();
  const p = window.PROJECTS.find((x) => x.id === projectId) || window.PROJECTS[0];
  const deps = window.DEPLOYMENTS.filter((d) => d.project === p.name);
  return (
    <div className="page">
      <div className="page-head">
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <Fav color={p.color} initial={p.initial} />
          <div>
            <div className="pt">{p.name} {p.agent && <Badge cls="agent">❖ عامل</Badge>}</div>
            <div className="ps" style={{ marginTop: 6, display: "flex", gap: 10, alignItems: "center" }}>
              <a className="url mono" style={{ color: "var(--accent)" }} href="#">{p.url}</a>
              <StatusBadge status={p.status} />
            </div>
          </div>
        </div>
        <div className="grow"></div>
        <button className="btn btn-ghost" onClick={() => toast("در تبِ جدید باز شد", p.url)}>↗ بازدید</button>
        <button className="btn btn-primary" onClick={() => go("publish")}>⬆ انتشارِ نسخه‌ی جدید</button>
      </div>

      <div className="grid cards-4">
        <Kpi label="نسخه‌ها" value={p.versions} icon="◷" />
        <Kpi label="آخرین استقرار" value={p.lastDeploy} icon="⇡" />
        <Kpi label="فریم‌ورک" value={p.framework} icon="▤" />
        <Kpi label="دامنه" value={p.domain || "—"} icon="◈" />
      </div>

      <div className="grid cards-2" style={{ marginTop: 14, gridTemplateColumns: "1.4fr 1fr", alignItems: "start" }}>
        <div className="card pad-lg">
          <div className="card-hd"><span className="ct">استقرارهای این پروژه</span><div className="grow"></div><span className="more" onClick={() => go("deployments")}>همه ←</span></div>
          <div className="list">
            {(deps.length ? deps : window.DEPLOYMENTS.slice(0,2)).map((d) => (
              <div className="row" key={d.id}>
                <div className="grow col">
                  <span className="nm mono" style={{ fontSize: 12 }}>{d.id}</span>
                  <span className="meta">{d.msg} · {d.who}</span>
                </div>
                <StatusBadge status={d.status} />
                <span className="meta" style={{ marginTop: 0, width: 70, textAlign: "left" }}>{d.when}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="card pad-lg">
          <div className="card-hd"><span className="ct">انتشار از طریقِ عامل</span></div>
          <div className="muted" style={{ fontSize: 13, lineHeight: 1.6, marginBottom: 12 }}>این پروژه را مستقیم از یک عامل یا CI منتشر کنید:</div>
          <CodeBlock code={"divband deploy ./dist \\\n  --project " + p.name} />
        </div>
      </div>
    </div>
  );
}

/* ── Deployments ─────────────────────────────────────────────── */
function PageDeployments({ go }) {
  const trig = { agent: "❖ عامل", api: "⧉ API", upload: "⬆ آپلود" };
  return (
    <div className="page">
      <div className="page-head">
        <div><div className="pt">استقرارها</div><div className="ps">هر انتشار یک نسخه‌ی تغییرناپذیر می‌سازد. منبعِ تریگر — انسان، API یا عامل — مشخص است.</div></div>
      </div>
      <table className="tbl">
        <thead><tr>
          <th>استقرار</th><th>پروژه</th><th>منبع</th><th>commit</th><th>مدت</th><th>وضعیت</th><th>زمان</th>
        </tr></thead>
        <tbody>
          {window.DEPLOYMENTS.map((d) => (
            <tr key={d.id}>
              <td><span className="mono">{d.id}</span><div className="muted" style={{ fontSize: 11, marginTop: 2 }}>{d.msg}</div></td>
              <td>{d.project}</td>
              <td><span className="tag">{trig[d.trigger]}</span><div className="muted mono" style={{ fontSize: 10, marginTop: 3 }}>{d.who}</div></td>
              <td className="mono">{d.commit}</td>
              <td className="mono">{d.dur}</td>
              <td><StatusBadge status={d.status} /></td>
              <td className="muted">{d.when}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ── Instant Publish ─────────────────────────────────────────── */
function PagePublish({ go }) {
  const toast = useToast();
  const [phase, setPhase] = pUseState("idle"); // idle | uploading | scanning | done
  const [pct, setPct] = pUseState(0);
  const [hot, setHot] = pUseState(false);
  const [versions, setVersions] = pUseState(window.VERSIONS);
  const timer = pUseRef(null);

  function start() {
    if (phase === "uploading" || phase === "scanning") return;
    setPhase("uploading"); setPct(0);
    clearInterval(timer.current);
    timer.current = setInterval(() => {
      setPct((x) => {
        const n = x + Math.random() * 16 + 6;
        if (n >= 100) {
          clearInterval(timer.current);
          setPhase("scanning");
          setTimeout(() => {
            setPhase("done");
            setVersions((v) => [{ v: "v" + (parseInt(v[0].v.slice(1)) + 1), status: "live", size: "2.5 MB", files: 39, checksum: "sha256:" + Math.random().toString(16).slice(2,6) + "…" + Math.random().toString(16).slice(2,4), when: "همین حالا", by: "آپلود", scan: "pass" }, ...v.map(x=>({...x, status: x.status==="live"?"ready":x.status}))]);
            toast("منتشر شد — URL زنده آماده است", "negar-portfolio.divband.app");
          }, 1100);
          return 100;
        }
        return n;
      });
    }, 240);
  }
  pUseEffect(() => () => clearInterval(timer.current), []);

  return (
    <div className="page">
      <div className="page-head">
        <div><div className="pt">انتشارِ فوری</div><div className="ps">یک پوشه‌ی خروجی را رها کنید تا در چند ثانیه روی یک URL زنده سرو شود. هر آپلود یک نسخه‌ی تغییرناپذیر و قابلِ بازگشت می‌سازد.</div></div>
      </div>

      <div className="grid cards-2" style={{ gridTemplateColumns: "1.3fr 1fr", alignItems: "start" }}>
        <div>
          {phase === "idle" && (
            <div className={"dropzone" + (hot ? " hot" : "")}
              onClick={start}
              onDragOver={(e) => { e.preventDefault(); setHot(true); }}
              onDragLeave={() => setHot(false)}
              onDrop={(e) => { e.preventDefault(); setHot(false); start(); }}>
              <div className="big">⬆</div>
              <div className="t1">پوشه‌ی <span className="mono">dist/</span> را اینجا رها کنید</div>
              <div className="t2">یا کلیک کنید تا یک آپلودِ نمونه شبیه‌سازی شود</div>
              <div className="or">— یا —</div>
              <button className="btn btn-ghost btn-sm" onClick={(e) => { e.stopPropagation(); go("api"); }}>انتشار از طریقِ CLI / API</button>
            </div>
          )}
          {(phase === "uploading" || phase === "scanning") && (
            <div className="card pad-lg">
              <div className="steps">
                <div className={"step done"}><span className="num">✓</span><div><div className="st">آغازِ نشستِ انتشار</div><div className="sd">آدرس‌های آپلودِ presigned صادر شد.</div></div></div>
                <div className={"step " + (phase === "uploading" ? "active" : "done")}><span className="num">{phase === "uploading" ? "↑" : "✓"}</span>
                  <div><div className="st">آپلودِ فایل‌ها</div><div className="sd">۳۹ فایل · اعتبارسنجیِ checksum</div>
                    <div className="progress" style={{ marginTop: 10 }}><i style={{ width: pct + "%" }}></i></div>
                  </div></div>
                <div className={"step " + (phase === "scanning" ? "active" : "")}><span className="num">{phase === "scanning" ? "◌" : "3"}</span><div><div className="st">gateِ اسکنِ امنیتی</div><div className="sd">بررسیِ بدافزار و نشتِ راز پیش از سرو.</div></div></div>
                <div className="step"><span className="num">4</span><div><div className="st">ثبتِ نسخه و سرو</div><div className="sd">نسخه‌ی تغییرناپذیر ساخته و روی دامنه سرو می‌شود.</div></div></div>
              </div>
            </div>
          )}
          {phase === "done" && (
            <div className="card pad-lg" style={{ textAlign: "center" }}>
              <div style={{ fontSize: 30, color: "var(--success)" }}>✓</div>
              <div style={{ fontSize: 17, fontWeight: 600, marginTop: 6 }}>نسخه‌ی {versions[0].v} منتشر شد</div>
              <div className="muted" style={{ fontSize: 13, marginTop: 6 }}>در ۱۱ ثانیه روی URL زنده سرو شد.</div>
              <div className="row" style={{ borderRadius: 10, marginTop: 16, cursor: "default", justifyContent: "center", gap: 10 }}>
                <span className="url">https://negar-portfolio.divband.app</span>
                <button className="btn btn-ghost btn-sm" onClick={() => { navigator.clipboard?.writeText("https://negar-portfolio.divband.app"); toast("لینک کپی شد"); }}>کپی</button>
              </div>
              <div style={{ display: "flex", gap: 8, justifyContent: "center", marginTop: 14 }}>
                <button className="btn btn-ghost btn-sm" onClick={() => { setPhase("idle"); setPct(0); }}>انتشارِ دوباره</button>
                <button className="btn btn-primary btn-sm" onClick={() => go("domains")}>اتصالِ دامنه ←</button>
              </div>
            </div>
          )}
        </div>

        <div className="card pad-lg">
          <div className="card-hd"><span className="ct">نسخه‌ها</span><div className="grow"></div><span className="muted mono" style={{ fontSize: 11 }}>قابلِ بازگشت</span></div>
          <div className="list">
            {versions.map((v) => (
              <div className="row" key={v.v} style={{ cursor: "default" }}>
                <div className="grow col">
                  <span className="nm">{v.v} {v.status === "live" && <Badge cls="ok">زنده</Badge>}</span>
                  <span className="meta">{v.files} فایل · {v.size} · {v.by}</span>
                </div>
                <span className="badge ok" title="اسکن موفق"><span className="dot"></span>اسکن</span>
                {v.status !== "live" && <button className="btn btn-ghost btn-sm" onClick={() => toast("بازگشت به " + v.v, "rollback")}>بازگشت</button>}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { PageOverview, PageProjects, PageProjectDetail, PageDeployments, PagePublish });
