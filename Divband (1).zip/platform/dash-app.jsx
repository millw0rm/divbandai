/* ══════════════════════════════════════════════════════════════
   Divband Platform — dashboard app root + router
   ══════════════════════════════════════════════════════════════ */
const { useState: rUseState } = React;

const USER = { name: "نگار مرادی", email: "negar@divband.com" };

const CRUMBS = {
  overview: ["نمای کلی"],
  projects: ["پروژه‌ها"],
  deployments: ["استقرارها"],
  publish: ["انتشارِ فوری"],
  domains: ["دامنه‌ها"],
  ai: ["تغییراتِ هوش مصنوعی"],
  api: ["API و عامل‌ها"],
  settings: ["تنظیمات"],
  product: ["سندِ محصول"],
};

function App() {
  const [page, setPage] = rUseState("overview");
  const [projectId, setProjectId] = rUseState(null);

  function go(p) { setProjectId(null); setPage(p); }
  function openProject(id) { setProjectId(id); setPage("projectDetail"); }

  if (page === "auth") return <Toaster><PageAuth go={go} /></Toaster>;

  let body, crumbs;
  if (page === "projectDetail") {
    const p = window.PROJECTS.find((x) => x.id === projectId);
    crumbs = ["پروژه‌ها", p ? p.name : "پروژه"];
    body = <PageProjectDetail projectId={projectId} go={go} />;
  } else {
    crumbs = CRUMBS[page] || ["نمای کلی"];
    const map = {
      overview: <PageOverview go={go} />,
      projects: <PageProjects go={go} openProject={openProject} />,
      deployments: <PageDeployments go={go} />,
      publish: <PagePublish go={go} />,
      domains: <PageDomains go={go} />,
      ai: <PageAI go={go} />,
      api: <PageApi go={go} />,
      settings: <PageSettings go={go} />,
      product: <PageProduct go={go} />,
    };
    body = map[page] || map.overview;
  }

  const navPage = page === "projectDetail" ? "projects" : page;

  const actions = (
    <>
      <button className="icon-btn" title="مستندات" onClick={() => setPage("product")}>?</button>
      <button className="btn btn-primary btn-sm" onClick={() => go("publish")}>⬆ انتشار</button>
    </>
  );

  return (
    <Toaster>
      <div className="app">
        <main className="main">
          <Topbar crumbs={crumbs} actions={actions} />
          <div className="content">{body}</div>
        </main>
        <Rail page={navPage} go={go} user={USER} />
      </div>
    </Toaster>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
