/* ══════════════════════════════════════════════════════════════
   Divband Platform — pages (2/2)
   PageDomains · PageAI · PageApi · PageSettings · PageAuth · PageProduct
   ══════════════════════════════════════════════════════════════ */
const { useState: qUseState } = React;

/* ── Domains + DNS + certs ───────────────────────────────────── */
function PageDomains({ go }) {
  const toast = useToast();
  const [sel, setSel] = qUseState(window.DOMAINS.find((d) => !d.verified)?.host || window.DOMAINS[0].host);
  const d = window.DOMAINS.find((x) => x.host === sel);
  return (
    <div className="page">
      <div className="page-head">
        <div><div className="pt">دامنه‌ها</div><div className="ps">دامنه‌ی اختصاصی وصل کنید؛ پس از تأییدِ DNS، گواهیِ TLS به‌صورتِ خودکار صادر می‌شود.</div></div>
        <div className="grow"></div>
        <button className="btn btn-primary">＋ افزودنِ دامنه</button>
      </div>

      <div className="grid cards-2" style={{ gridTemplateColumns: "1fr 1.3fr", alignItems: "start" }}>
        <div className="list">
          {window.DOMAINS.map((x) => (
            <div className={"row" + (x.host === sel ? "" : "")} key={x.host} onClick={() => setSel(x.host)}
                 style={x.host === sel ? { background: "var(--accent-3)", borderColor: "rgba(30,58,138,.3)" } : null}>
              <span className="fav" style={{ fontSize: 13 }}>◈</span>
              <div className="grow col">
                <span className="nm mono" style={{ fontSize: 13 }}>{x.host}</span>
                <span className="meta">{x.project}</span>
              </div>
              {x.verified ? <Badge cls="ok">تأییدشده</Badge> : <Badge cls="warn">در انتظار</Badge>}
            </div>
          ))}
        </div>

        <div className="card pad-lg">
          <div className="card-hd"><span className="ct mono">{d.host}</span><div className="grow"></div>
            {d.verified ? <Badge cls="ok">گواهیِ فعال · {d.certExp}</Badge> : <Badge cls="warn">گواهی در انتظار</Badge>}
          </div>

          {!d.verified && (
            <>
              <div className="muted" style={{ fontSize: 13, marginBottom: 16, lineHeight: 1.6 }}>این رکوردها را در ارائه‌دهنده‌ی DNS خود اضافه کنید، سپس «تأیید» را بزنید.</div>
              <table className="tbl" style={{ marginBottom: 16 }}>
                <thead><tr><th>نوع</th><th>نام</th><th>مقدار</th><th>TTL</th></tr></thead>
                <tbody>
                  {window.DNS_RECORDS.map((r, i) => (
                    <tr key={i}>
                      <td><span className="tag">{r.type}</span></td>
                      <td className="mono">{r.name}</td>
                      <td className="mono" style={{ color: "var(--accent)" }}>{r.value}</td>
                      <td className="mono muted">{r.ttl}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </>
          )}

          <div className="steps">
            <div className="step done"><span className="num">✓</span><div><div className="st">دامنه اضافه شد</div><div className="sd">{d.added}</div></div></div>
            <div className={"step " + (d.verified ? "done" : "active")}><span className="num">{d.verified ? "✓" : "◌"}</span><div><div className="st">تأییدِ مالکیت (DNS)</div><div className="sd">{d.verified ? "رکوردِ TXT تأیید شد." : "در انتظارِ انتشارِ رکوردها…"}</div></div></div>
            <div className={"step " + (d.cert === "active" ? "done" : "")}><span className="num">{d.cert === "active" ? "✓" : "3"}</span><div><div className="st">صدورِ گواهیِ TLS</div><div className="sd">{d.cert === "active" ? "خودکار · تمدیدِ خودکار فعال" : "پس از تأیید آغاز می‌شود."}</div></div></div>
          </div>

          {!d.verified && <button className="btn btn-primary" style={{ marginTop: 16 }} onClick={() => toast("در حال بررسیِ رکوردهای DNS…", "dns-verify")}>تأییدِ رکوردها</button>}
        </div>
      </div>
    </div>
  );
}

/* ── AI changes ──────────────────────────────────────────────── */
function PageAI({ go }) {
  const toast = useToast();
  const [sel, setSel] = qUseState(window.AI_CHANGES[0].id);
  const c = window.AI_CHANGES.find((x) => x.id === sel);
  const st = window.AI_STATUS[c.status];
  return (
    <div className="page">
      <div className="page-head">
        <div><div className="pt">تغییراتِ هوش مصنوعی <Badge cls="agent">پیش‌نمایش</Badge></div>
          <div className="ps">عامل تغییری را پیشنهاد می‌دهد → diff واقعی → branch و merge request → CI → پیش‌نمایش. شما بازبینی و ادغام می‌کنید.</div></div>
      </div>

      <div className="grid cards-2" style={{ gridTemplateColumns: "1fr 1.5fr", alignItems: "start" }}>
        <div className="list">
          {window.AI_CHANGES.map((x) => {
            const xs = window.AI_STATUS[x.status];
            return (
              <div className="row" key={x.id} onClick={() => setSel(x.id)}
                   style={x.id === sel ? { background: "var(--accent-3)", borderColor: "rgba(30,58,138,.3)" } : null}>
                <span className="fav" style={{ fontSize: 12 }}>❖</span>
                <div className="grow col">
                  <span className="nm" style={{ fontSize: 13 }}>{x.title}</span>
                  <span className="meta">{x.project} · {x.mr} · {x.when}</span>
                </div>
                <Badge cls={xs.cls}>{xs.label}</Badge>
              </div>
            );
          })}
        </div>

        <div className="card pad-lg">
          <div className="card-hd">
            <span className="ct">{c.title}</span><div className="grow"></div><Badge cls={st.cls}>{st.label}</Badge>
          </div>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 14 }}>
            <span className="tag">پروژه: {c.project}</span>
            <span className="tag">عامل: {c.agent}</span>
            <span className="tag">{c.mr}</span>
            <span className={"badge " + (c.ci === "passing" ? "ok" : c.ci === "running" ? "run" : "")}>{c.ci !== "—" && <span className="dot"></span>}CI: {c.ci}</span>
            <span className="tag" style={{ color: "var(--success)" }}>+{c.add}</span>
            <span className="tag" style={{ color: "var(--danger)" }}>−{c.del}</span>
          </div>

          <div className="diff">
            {window.DIFF_SAMPLE.map((l, i) => (
              <div key={i} className={"dl " + (l.t === "dh" ? "" : l.t)} style={l.t === "dh" ? null : {}}>
                {l.t === "dh" ? <div className="dh">{l.s}</div> : l.s}
              </div>
            ))}
          </div>

          <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
            <button className="btn btn-ghost btn-sm" onClick={() => toast("پیش‌نمایشِ استقرار باز شد", c.mr)}>↗ پیش‌نمایش</button>
            <div className="grow"></div>
            <button className="btn btn-ghost btn-sm" onClick={() => toast("درخواست به عامل ارسال شد", "request changes")}>درخواستِ اصلاح</button>
            <button className="btn btn-primary btn-sm" onClick={() => toast("ادغام شد و مستقر می‌شود", c.mr)} disabled={c.status === "merged"}
                    style={c.status === "merged" ? { opacity: .4 } : null}>ادغام و استقرار</button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── API & agents ────────────────────────────────────────────── */
function PageApi({ go }) {
  const toast = useToast();
  return (
    <div className="page">
      <div className="page-head">
        <div><div className="pt">API و عامل‌ها</div><div className="ps">هر کاری در داشبورد یک معادلِ مستندِ API/MCP دارد. عامل‌ها با توکنِ scoped منتشر می‌کنند.</div></div>
        <div className="grow"></div>
        <button className="btn btn-primary" onClick={() => toast("توکنِ جدید ساخته شد", "dvb_live_…")}>＋ توکنِ API</button>
      </div>

      <div className="grid cards-2" style={{ gridTemplateColumns: "1fr 1fr", alignItems: "start" }}>
        <div className="card pad-lg">
          <div className="card-hd"><span className="ct">اتصالِ عامل (MCP)</span><Badge cls="agent">❖ عامل</Badge></div>
          <div className="muted" style={{ fontSize: 13, lineHeight: 1.6, marginBottom: 12 }}>این را به پیکربندیِ MCP عاملِ خود اضافه کنید:</div>
          <CodeBlock code={window.SNIPPET_MCP} />
          <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
            <a className="btn btn-ghost btn-sm" href="#" onClick={(e)=>{e.preventDefault(); toast("openapi.json باز شد");}}>OpenAPI</a>
            <a className="btn btn-ghost btn-sm" href="#" onClick={(e)=>{e.preventDefault(); toast("llms.txt باز شد");}}>llms.txt</a>
          </div>
        </div>
        <div className="card pad-lg">
          <div className="card-hd"><span className="ct">انتشار از طریقِ REST</span></div>
          <div className="muted" style={{ fontSize: 13, lineHeight: 1.6, marginBottom: 12 }}>همان عملیات، از CLI یا CI:</div>
          <CodeBlock code={window.SNIPPET_CURL} />
        </div>
      </div>

      <div className="section-label">توکن‌های API</div>
      <table className="tbl">
        <thead><tr><th>نام</th><th>پیشوند</th><th>دسترسی</th><th>ساخته‌شده</th><th>آخرین استفاده</th><th></th></tr></thead>
        <tbody>
          {window.TOKENS.map((t) => (
            <tr key={t.name}>
              <td style={{ fontWeight: 500 }}>{t.name}</td>
              <td className="mono">{t.prefix}…</td>
              <td><span className="tag">{t.scope}</span></td>
              <td className="muted">{t.created}</td>
              <td className="muted">{t.lastUsed}</td>
              <td style={{ textAlign: "left" }}><span className="muted" style={{ cursor: "pointer" }} onClick={() => toast("توکن باطل شد", t.prefix)}>باطل کردن</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ── Settings ────────────────────────────────────────────────── */
function PageSettings({ go }) {
  const toast = useToast();
  const [reveal, setReveal] = qUseState({});
  return (
    <div className="page">
      <div className="page-head">
        <div><div className="pt">تنظیمات</div><div className="ps">متغیرهای محیطی و رازها. رازها رمزنگاری‌شده ذخیره می‌شوند و هرگز به‌صورتِ متنِ ساده برگردانده نمی‌شوند.</div></div>
      </div>

      <div className="section-label">متغیرهای محیطی</div>
      <table className="tbl">
        <thead><tr><th>کلید</th><th>مقدار</th><th>دامنه</th><th></th></tr></thead>
        <tbody>
          {window.ENV_VARS.map((e) => (
            <tr key={e.key}>
              <td className="mono" style={{ fontWeight: 500 }}>{e.key}</td>
              <td className="mono">
                {e.secret && !reveal[e.key] ? "••••••••••••" : e.val}
                {e.secret && <span className="muted" style={{ cursor: "pointer", marginRight: 8, fontFamily: "var(--sans)", fontSize: 12 }}
                  onClick={() => setReveal((r) => ({ ...r, [e.key]: !r[e.key] }))}>{reveal[e.key] ? "پنهان" : "نمایش"}</span>}
              </td>
              <td>{e.secret ? <Badge cls="run">راز</Badge> : <span className="muted" style={{ fontSize: 12 }}>{e.scope}</span>}</td>
              <td style={{ textAlign: "left" }}><span className="muted" style={{ cursor: "pointer" }} onClick={() => toast("حذف شد", e.key)}>حذف</span></td>
            </tr>
          ))}
        </tbody>
      </table>
      <button className="btn btn-ghost btn-sm" style={{ marginTop: 12 }} onClick={() => toast("متغیرِ جدید")}>＋ افزودنِ متغیر</button>

      <div className="divider"></div>
      <div className="card pad-lg" style={{ borderColor: "rgba(184,32,60,.3)" }}>
        <div style={{ fontSize: 14, fontWeight: 600, color: "var(--danger)", marginBottom: 6 }}>منطقه‌ی خطر</div>
        <div className="muted" style={{ fontSize: 13, marginBottom: 14 }}>حذفِ پروژه همه‌ی نسخه‌ها و دامنه‌ها را برمی‌دارد. این عمل بازگشت‌پذیر نیست.</div>
        <button className="btn btn-ghost btn-sm" style={{ color: "var(--danger)", borderColor: "rgba(184,32,60,.3)" }} onClick={() => toast("برای حذف، تأیید لازم است")}>حذفِ پروژه</button>
      </div>
    </div>
  );
}

/* ── Product hub (in-dashboard summary) ──────────────────────── */
function PageProduct({ go }) {
  const toast = useToast();
  const stateBadge = { done: "ok", active: "run", todo: "warn" };
  const stateLabel = { done: "انجام‌شده", active: "در حال انجام", todo: "بعدی" };
  return (
    <div className="page">
      <div className="page-head">
        <div><div className="pt">سندِ محصول</div><div className="ps">منبعِ راستیِ محصول — چشم‌انداز، فازها و وضعیت. تا هر گفت‌وگو از صفر شروع نشود.</div></div>
        <div className="grow"></div>
        <a className="btn btn-ghost" href="../docs-product/product-hub.html" target="_blank">نمای کاملِ روادمپ ↗</a>
      </div>

      <div className="card pad-lg" style={{ marginBottom: 14 }}>
        <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 6 }}>MVP: میزبانیِ فوریِ استاتیک، با اولویتِ عامل</div>
        <div className="muted" style={{ fontSize: 13.5, lineHeight: 1.7 }}>آپلودِ خروجی → presigned → اعتبارسنجی + اسکن → نسخه‌ی تغییرناپذیر → سرو روی URL و دامنه‌ی اختصاصی — همه قابلِ انجام با داشبورد و با MCP/REST.</div>
        <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
          <span className="tag">PRODUCT.md</span><span className="tag">STATUS.md</span><span className="tag">CLAUDE.md</span>
        </div>
      </div>

      <div className="section-label">فازهای انتشار</div>
      <div className="list">
        {window.PHASES.map((p) => (
          <div className="row" key={p.id} style={{ cursor: "default", alignItems: "flex-start" }}>
            <span className="mono" style={{ fontWeight: 600, width: 30 }}>{p.id}</span>
            <div className="grow col">
              <span className="nm" style={{ fontSize: 14 }}>{p.name}</span>
              <span className="meta" style={{ whiteSpace: "normal", lineHeight: 1.6 }}>{p.desc}</span>
            </div>
            <Badge cls={stateBadge[p.state]}>{stateLabel[p.state]}</Badge>
          </div>
        ))}
      </div>

      <div className="section-label">شکاف‌ها تا MVP اجراشدنی</div>
      <table className="tbl">
        <thead><tr><th>#</th><th>شکاف</th><th>فاز</th><th>اولویت</th><th>تخمین</th></tr></thead>
        <tbody>
          {window.GAPS.map((g) => {
            const pb = window.PRI_BADGE[g.pri];
            return (
              <tr key={g.id} style={g.done ? { opacity: .5 } : null}>
                <td className="mono">{g.id}</td>
                <td>{g.t} {g.done && "✓"}</td>
                <td className="mono muted">{g.phase}</td>
                <td>{pb ? <Badge cls={pb.cls}>{pb.label}</Badge> : "—"}</td>
                <td className="mono muted">{g.eff}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

/* ── Auth (login) ────────────────────────────────────────────── */
function PageAuth({ go }) {
  const toast = useToast();
  return (
    <div style={{ minHeight: "100dvh", display: "grid", placeItems: "center",
      background: "radial-gradient(circle at 20% 30%, rgba(30,58,138,.05), transparent 40%), radial-gradient(circle at 80% 80%, rgba(30,58,138,.04), transparent 40%), var(--bg)", padding: 24 }}>
      <div className="card" style={{ width: 420, padding: "36px 32px", boxShadow: "var(--sh3)" }}>
        <div className="brand" style={{ marginBottom: 26 }}><span className="mark">◇</span><div className="word">DIVBAND<span className="sub">/platform</span></div></div>
        <div style={{ fontSize: 22, fontWeight: 600, marginBottom: 4 }}>ورود</div>
        <div className="muted" style={{ fontSize: 14, marginBottom: 26 }}>به داشبوردِ میزبانیِ Divband خوش آمدید.</div>
        <div className="field"><label>ایمیل</label><input defaultValue="negar@divband.com" /></div>
        <div className="field"><label>گذرواژه</label><input type="password" defaultValue="123456789" /></div>
        <button className="btn btn-primary" style={{ width: "100%", justifyContent: "center", marginTop: 6 }} onClick={() => go("overview")}>ورود</button>
        <div style={{ textAlign: "center", marginTop: 18, fontSize: 13 }} className="muted">حساب ندارید؟ <a href="#" style={{ color: "var(--text)" }} onClick={(e)=>{e.preventDefault(); toast("ثبت‌نام");}}>ثبت‌نام</a></div>
      </div>
    </div>
  );
}

Object.assign(window, { PageDomains, PageAI, PageApi, PageSettings, PageProduct, PageAuth });
