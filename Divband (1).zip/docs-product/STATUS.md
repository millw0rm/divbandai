# Divband Platform — STATUS

> **Update this every working session.** It is how future conversations avoid starting from scratch.
> Companion: [`PRODUCT.md`](./PRODUCT.md) · [`product-hub.html`](./product-hub.html)
> Source of current findings: static QA review (read-only) of `/workspace/divband`.

**Phase:** P0 → P1 · **Headline:** skeleton compiles; nothing serves real content end-to-end yet.

---

## 1. What exists today ✅

- **Docs & vision:** `README.md`, `docs/architecture.md`, `security.md`, `tenancy.md`, `deployments.md`, `domains.md`, `operations.md`, and `docs/agent-instant-hosting.md` (milestones + MVP acceptance criteria).
- **Backend skeleton:** `apps/backend/src/backend-service.ts` — framework-neutral handler exposing project / auth / domain / deployment / AI / publish routes. Models + **in-memory** store.
- **Frontend skeleton:** `apps/frontend/src/dashboard.ts` — framework-neutral dashboard renderer + API client (no app shell/bundler yet).
- **Infra templates:** `infra/k8s/base/*`, `infra/gitlab/terraform/*`, `infra/terraform/modules/*` (mostly placeholders, `REPLACE_WITH_*`).
- **Agent distribution:** `packages/mcp-server`, `packages/agent-skill`, `public/openapi.json`, `public/llms.txt`.

## 2. Gap backlog (prioritized for the instant-host MVP)

Ordered by what unblocks a runnable MVP first. P1 items are MVP-blocking.

| # | Gap | Phase | Priority | Effort | Notes |
|---|---|---|---|---|---|
| G2 | **Backend not runnable as a service** — no HTTP entrypoint, process config, DB, migrations, persistence, deploy config, secrets handling; no `start`/`build` scripts in `package.json`. | P1 | 🔴 P0-blocker | L | Everything else depends on this. |
| G4 | **Instant publish loop incomplete** — `PublishingService` makes fake upload URLs/metadata; no real presigned URLs, upload sessions, checksum validation, scan gate, populated `publishedSites/Versions/Files`, or link to `StaticServingService`. | P1 | 🔴 P0-blocker | L | This *is* the MVP value. |
| G6 | **Auth/secrets not production-safe** — in-memory users/sessions/tokens/secrets; SHA-style hashing instead of a real password KDF; env values stored on project model, masked only on read. | P1 | 🔴 High | M | Needed before real users. |
| G5 | **Frontend not deployable** — no app shell, bundler, dev server, prod build, routing, styling, or deploy target; no `package.json` scripts. | P1 | 🟠 High | M | Design prototype now lives in `platform/`. |
| G8 | **No one-command local stack** — only a root `typecheck`; no documented dev stack (backend+frontend+storage emulator+DB+mock infra). | P1 | 🟠 High | M | Proves MVP runnable pre-prod. |
| G1 | **No canonical product operating doc** — vision/scope/status/decisions/backlog scattered. | — | 🟠 High | S | **Addressed** by this docs set (PRODUCT/STATUS/CLAUDE). Keep current. |
| G3 | **Infra adapters are placeholders** — `gitlab.ts`, `kubernetes.ts`, `dns-verification.ts`, `certificate-status.ts` return synthetic results; Terraform modules + K8s manifests unrendered. | P2/P4 | 🟡 Medium | XL | DNS/cert needed for P2 custom domains; GitLab/K8s for P4. |
| G7 | **AI change workflow is simulated** — records fake patches/branches/MRs/CI; no model call, repo read, real diff, commit, or verify. | P3 | 🟡 Medium | XL | Define the boundary before implementing. |

Effort: S<½wk · M≈1wk · L≈1–2wk · XL>2wk (rough).

## 3. Next to build (ordered)

1. **G2** — Stand up the backend as a real HTTP service: entrypoint, Postgres + migrations + repository layer, config/secrets via env, `dev`/`build`/`start` scripts.
2. **G4** — Implement the real publish→serve loop: presigned uploads → upload session → checksum/byte validation → scan gate → persist version/files → serve via `StaticServingService` at a default subdomain.
3. **G6** — Harden auth: real password KDF (argon2/bcrypt), persisted sessions, scoped API tokens, encrypted-at-rest secrets.
4. **G8** — One-command local stack (`compose`/`make dev`) with storage emulator + DB + mock infra; document runbook.
5. **G5** — Wrap `dashboard.ts` in a real deployable frontend (shell + bundler + routing + the screens prototyped in `platform/`).
6. **G1** — Keep these docs current (ongoing).
7. *(P2)* **G3 partial** — DNS verification + certificate adapters for custom domains.
8. *(P3)* **G7** — Define + implement the AI change-request boundary.
9. *(P4)* **G3 full** — Real GitLab + Kubernetes + Terraform provisioning.

## 4. Decisions log

| Date | Decision | Rationale |
|---|---|---|
| (this session) | **MVP = agent-first instant static hosting**, not full project hosting. | Smallest uniquely-valuable slice; codebase already leans this way (MCP, OpenAPI, PublishingService). QA review concurs. |
| (this session) | **Establish PRODUCT/STATUS/CLAUDE as the source of truth**; CLAUDE.md auto-loads each session. | Stops every conversation restarting from scattered docs (gap G1). |
| (this session) | **Platform dashboard designed RTL Persian on the existing Divband design system.** | Brand consistency with Divband Chat + site. |

## 5. Risks

- **Infra realism (G3) is the long pole.** Custom domains (P2) and project hosting (P4) can't be faked for real users; budget XL.
- **Security debt (G6) compounds.** Shipping in-memory/SHA auth to real users is a non-starter; do it in P1.
- **Scope creep toward full project hosting** dilutes the wedge. Hold the line on the instant-host MVP.
- **No persistence (G2/G4)** means nothing is real until DB + storage land.

## 6. Assumptions

- Object storage with presigned PUT is available (S3-compatible).
- Postgres is the primary datastore.
- A default wildcard domain (e.g. `*.divband.app`) is obtainable for instant serve URLs.
- A scanner (malware/secret) can be invoked as a gate step.

## 7. Open questions

- Default serve domain — `*.divband.app`? Who owns the wildcard cert?
- Object storage provider (S3 / R2 / MinIO for local)?
- Scanner choice for the publish gate?
- AI change loop: GitLab-specific or generic Git host?
- Free-tier limits (sites, bandwidth, versions retained)?
- Single-owner projects for MVP, or minimal team sharing?

---

### Changelog
- *(this session)* Created docs set from QA review; defined MVP, phases, backlog, next-to-build. Built `platform/` dashboard prototype + `product-hub.html`.
