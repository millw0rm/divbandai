# Divband Platform — Product Document (PRD)

> **Status:** Living document · Phase 0→1 · Last updated by design/product session.
> **Companion:** [`STATUS.md`](./STATUS.md) (current state + backlog) · [`product-hub.html`](./product-hub.html) (visual).
> **Scope note:** This is the **Divband Platform** (instant hosting). The multi-LLM **Divband Chat** app is a separate product — see `CLAUDE.md`.

---

## 1. One-liner

**Divband is an agent-first hosting platform: ship a website or app in seconds, operable equally by a human dashboard and by AI agents over MCP / REST / OpenAPI.**

## 2. Why this exists

Today, AI agents can *write* code but can't reliably *ship* it — every hosting provider is built for humans clicking a UI. Divband makes "publish and serve" a first-class, machine-drivable primitive: an agent (or a person) can create a project, push static output or a repo, attach a domain, and get a live URL — without a human stepping through a console.

## 3. Target users

| User | Need | Primary surface |
|---|---|---|
| **AI coding agents** (the wedge) | Programmatic "publish this build and give me a live URL." | MCP server + REST + OpenAPI + `llms.txt` |
| **Solo devs / indie hackers** | Dead-simple instant deploys without infra setup. | Dashboard + CLI/API |
| **Small teams** | Shared projects, domains, env management, deploy history. | Dashboard |
| **Platform operators (us)** | Provision and run the underlying infra reliably. | Infra/ops tooling |

**Wedge first:** agent-first instant static hosting. It is the smallest thing that is uniquely valuable and the part of the codebase already pointed in this direction (MCP server, OpenAPI, `PublishingService`).

## 4. Product surfaces

1. **Instant static hosting (MVP).** Upload static output (a folder/zip/file set) → validate + scan → create an immutable **version** → serve at `*.divband.app` and/or custom domains. Versions are rollback-able.
2. **Full project hosting (later).** Connect a Git repo (GitLab) → build via runners → deploy to Kubernetes namespace → routes + TLS + DNS. Heavier; depends on real infra adapters.
3. **AI change requests (later).** An agent proposes a change → real diff → branch + merge request → CI → deploy preview. Currently simulated.

## 5. MVP definition (what "done" means)

**MVP = agent-first instant static hosting, runnable end-to-end for real users.**

A user or agent can, via dashboard **and** API/MCP:

- [ ] Register / authenticate (production-safe: real password hashing, persisted sessions, scoped API tokens).
- [ ] Create a **project**.
- [ ] Start a **publish session** → receive **real presigned upload URLs**.
- [ ] Upload files; bytes/checksums validated; a **scanner gate** runs.
- [ ] Finalize → an immutable **version** is recorded (`publishedSites` / `publishedVersions` / `publishedFiles` populated).
- [ ] The version is **served** by `StaticServingService` at a default subdomain.
- [ ] Attach a **custom domain** with DNS verification + automatic TLS.
- [ ] Roll back to a previous version.
- [ ] Do all of the above over **MCP + REST** with an API token, documented in OpenAPI.
- [ ] Run the whole stack locally with **one command** (backend + frontend + storage emulator + DB).

**Explicitly OUT of MVP:** GitLab/K8s project builds, real AI code-change execution, multi-region, teams/RBAC beyond a single owner, billing.

## 6. Release phases

| Phase | Theme | Outcome |
|---|---|---|
| **P0 — Skeleton** *(here)* | Routes, models, in-memory stores, infra templates, MCP/OpenAPI scaffolding. | Compiles & typechecks; nothing serves real content. |
| **P1 — Runnable instant-host MVP** | HTTP entrypoint, DB + migrations + persistence, real presigned uploads, scan gate, publish→serve loop, hardened auth, local one-command stack, deployable frontend. | A real user/agent publishes a site and gets a working live URL. |
| **P2 — Custom domains & TLS** | DNS verification adapter, certificate issuance/status, domain routing in serving layer. | Custom domains live with HTTPS. |
| **P3 — Agent change loop** | Real model calls, repo read, diff generation, GitLab branch + MR, CI/deploy preview. | Agents propose & ship reviewed changes. |
| **P4 — Full project hosting** | Real GitLab + Kubernetes + Terraform adapters; build runners; namespaces/routes. | Repo-based apps deploy on managed infra. |

## 7. Architecture (target, condensed)

```
Agent / Human
   │  (MCP · REST · OpenAPI)
   ▼
Backend API service ──► Auth (users, sessions, scoped tokens, secrets)
   │                     Projects · Domains · Deployments
   ├─► PublishingService ─► Object storage (presigned PUT) ─► scan gate
   │        └─► versions/files metadata (DB)
   ├─► StaticServingService ─► serves versions at *.divband.app / custom domains
   ├─► DNS + Certificate adapters  (P2)
   └─► GitLab + Kubernetes adapters (P4)
DB (Postgres) · Object storage · (later) K8s + runners
```

## 8. Key product principles

- **Agent-parity:** every dashboard action has an equivalent documented API/MCP action. No human-only paths.
- **Immutable versions, instant rollback.** Publishing never mutates a live version in place.
- **Safe by default:** scan gate on every publish; secrets never returned in plaintext; tokens are scoped.
- **One command to run locally.** If a contributor can't `dev` the stack, the MVP isn't real.

## 9. Success metrics (early)

- Time-from-create-to-live-URL < 60s (instant host).
- An agent can publish via MCP with zero human dashboard steps.
- 100% of dashboard actions covered by API + OpenAPI.

## 10. Open product questions

See **Open Questions** in [`STATUS.md`](./STATUS.md) — domain strategy (`*.divband.app`?), storage provider, scanner choice, whether AI-change-loop targets GitLab or generic Git, free-tier limits.
