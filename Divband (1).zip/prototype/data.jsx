/* ══════════════════════════════════════════════════════════════
   Divband Chat prototype — data + helpers
   Exposes to window: PROVIDERS, PROVIDER_COLORS, SEED_CONVERSATIONS,
   STARTERS, SYS_PRESETS, SIM_RESPONSES, mdToHtml, findModel
   ══════════════════════════════════════════════════════════════ */

// Mirror of lib/providers.ts
const PROVIDERS = [
  { id: "anthropic", label: "Anthropic — Claude", models: [
    { id: "claude-3-5-sonnet-latest", label: "Claude 3.5 Sonnet", vision: true, context: "200k" },
    { id: "claude-3-5-haiku-latest",  label: "Claude 3.5 Haiku",  context: "200k" },
    { id: "claude-3-opus-latest",     label: "Claude 3 Opus", vision: true, context: "200k" },
  ]},
  { id: "openai", label: "OpenAI — GPT", models: [
    { id: "gpt-4o",      label: "GPT-4o", vision: true, context: "128k" },
    { id: "gpt-4o-mini", label: "GPT-4o mini", vision: true, context: "128k" },
    { id: "o1",          label: "o1 (reasoning)", reasoning: true, context: "128k" },
    { id: "o1-mini",     label: "o1-mini", reasoning: true, context: "128k" },
  ]},
  { id: "google", label: "Google — Gemini", models: [
    { id: "gemini-1.5-pro-latest",   label: "Gemini 1.5 Pro", vision: true, context: "2M" },
    { id: "gemini-1.5-flash-latest", label: "Gemini 1.5 Flash", vision: true, context: "1M" },
  ]},
  { id: "deepseek", label: "DeepSeek", models: [
    { id: "deepseek-chat",     label: "DeepSeek V3", context: "64k" },
    { id: "deepseek-reasoner", label: "DeepSeek R1 (reasoning)", reasoning: true, context: "64k" },
  ]},
  { id: "mistral", label: "Mistral", models: [
    { id: "mistral-large-latest", label: "Mistral Large", context: "128k" },
    { id: "codestral-latest",     label: "Codestral", context: "32k" },
  ]},
  { id: "xai", label: "xAI — Grok", models: [
    { id: "grok-2-latest",        label: "Grok 2", context: "128k" },
    { id: "grok-2-vision-latest", label: "Grok 2 Vision", vision: true, context: "128k" },
  ]},
  { id: "ollama", label: "Ollama — Local", models: [
    { id: "llama3.2", label: "Llama 3.2 (local)" },
    { id: "qwen2.5",  label: "Qwen 2.5 (local)" },
    { id: "mistral",  label: "Mistral 7B (local)" },
    { id: "phi3",     label: "Phi-3 (local)" },
  ]},
];

// Tonal dots — share chroma/lightness, vary hue (per brand rule)
const PROVIDER_COLORS = {
  anthropic: "#c2693f",
  openai:    "#1f8a5b",
  google:    "#2851d6",
  deepseek:  "#6d4bd1",
  mistral:   "#d97706",
  xai:       "#0a0f1f",
  ollama:    "#4b5468",
};

function findModel(provId, modelId) {
  const p = PROVIDERS.find((x) => x.id === provId) || PROVIDERS[0];
  const m = p.models.find((x) => x.id === modelId) || p.models[0];
  return { p, m };
}

const STARTERS = [
  { tag: "نوشتن", text: "یک خلاصه‌ی فارسی از مهم‌ترین اخبار هوش مصنوعی این هفته بنویس" },
  { tag: "کسب‌وکار", text: "یک ایمیل حرفه‌ای برای پیگیری پیشنهادِ همکاری بنویس" },
  { tag: "کدنویسی", text: "این کد پایتون را بهینه کن و توضیح بده چه تغییری دادی" },
  { tag: "برنامه‌ریزی", text: "یک طرح پروژه‌ی سه‌مرحله‌ای برای راه‌اندازی یک چت‌بات سازمانی بده" },
];

const SYS_PRESETS = [
  { label: "مشاور حقوقی", text: "شما یک مشاور حقوقی هستی؛ پاسخ‌ها مختصر، رسمی و دقیق باشد." },
  { label: "مهندس ارشد", text: "تو یک مهندس نرم‌افزار ارشد هستی. کد تمیز با توضیح کوتاه بده." },
  { label: "ویراستار فارسی", text: "متن‌ها را با لحن روان و بدونِ غلط املایی بازنویسی کن." },
];

// ── Simulated assistant responses (markdown subset) ──────────────
const R_NEWS = `این‌ها مهم‌ترین رویدادهای این هفته در حوزه‌ی هوش مصنوعی هستند:

## مدل‌های جدید
- چند آزمایشگاه بزرگ نسخه‌های تازه‌ای با **پنجره‌ی متنِ بلندتر** و توانِ استدلالِ بهتر معرفی کردند.
- تمرکزِ اصلی روی کاهشِ هزینه‌ی هر توکن و سرعتِ پاسخ‌دهی بوده است.

## ابزارها و agentها
- یکپارچه‌سازیِ ابزارها (جست‌وجوی وب، اجرای کد) به‌سرعت در حالِ استانداردسازی است.
- چارچوب‌های \`agent\` سبک‌تر و قابل‌اتکاتر شده‌اند.

> جمع‌بندی: رقابت از «بزرگ‌ترین مدل» به سمتِ «مفیدترین تجربه» جابه‌جا شده است.`;

const R_EMAIL = `حتماً. این یک نسخه‌ی رسمی و مختصر است:

**موضوع:** پیگیریِ پیشنهادِ همکاری

سلام جناب آقای رضایی،

امیدوارم حالتان خوب باشد. پیرو گفت‌وگوی هفته‌ی گذشته، می‌خواستم وضعیتِ بررسیِ پیشنهادِ همکاری را جویا شوم.

اگر سؤال یا ابهامی باقی مانده، با کمالِ میل در خدمتم تا جلسه‌ای کوتاه ترتیب دهیم.

با احترام،
نام شما`;

const R_CODE = `بهینه‌سازی انجام شد. نسخه‌ی پیشنهادی:

\`\`\`python
def group_by_key(items, key):
    out = {}
    for it in items:
        out.setdefault(key(it), []).append(it)
    return out
\`\`\`

**چه چیزی تغییر کرد:**
- جایگزینیِ حلقه‌ی تو در تو با \`setdefault\` → از \`O(n²)\` به \`O(n)\`.
- حذفِ شرطِ اضافیِ بررسیِ وجودِ کلید.
- نام‌گذاریِ خواناتر برای نگه‌داری آسان‌تر.`;

const R_PLAN = `یک طرحِ سه‌مرحله‌ای برای راه‌اندازیِ چت‌باتِ سازمانی:

### مرحله ۱ — پایه (هفته‌ی ۱–۲)
- انتخابِ مدل و provider، تعریفِ system prompt پایه.
- اتصال به منابعِ دانشِ داخلی (سند، ویکی).

### مرحله ۲ — کیفیت (هفته‌ی ۳–۴)
- افزودنِ جست‌وجو در تاریخچه و حافظه‌ی مکالمه.
- ارزیابیِ پاسخ‌ها با مجموعه‌ی سؤالاتِ واقعی.

### مرحله ۳ — مقیاس (هفته‌ی ۵+)
- کنترلِ دسترسی نقش‌محور و داشبوردِ مصرف.
- پایش هزینه و هشدارِ سقفِ بودجه.`;

const R_GENERIC = `سؤالِ خوبی است. به‌طورِ خلاصه:

- نکته‌ی اول این است که باید مسئله را به بخش‌های کوچک‌تر تقسیم کنیم.
- سپس هر بخش را جداگانه حل و در پایان نتیجه را ترکیب می‌کنیم.

اگر بخواهی می‌توانم هر کدام از این موارد را با **مثالِ عملی** و کمی \`کدِ نمونه\` بازتر کنم. کافی است بگویی روی کدام بخش تمرکز کنم.`;

const R_VISION = `تصویر را بررسی کردم. آنچه می‌بینم:

- ترکیب‌بندی تمیز با تمرکزِ اصلی در مرکزِ کادر است.
- پالتِ رنگ گرم و کم‌اشباع به نظر می‌رسد که حسِ حرفه‌ای می‌دهد.
- اگر هدف استفاده در رابطِ کاربری است، **کنتراستِ متن روی این پس‌زمینه** را کمی بالا ببر.

بگو می‌خواهی توضیحِ دقیق‌تری از کدام بخش بدهم.`;

const SIM_RESPONSES = { R_NEWS, R_EMAIL, R_CODE, R_PLAN, R_GENERIC, R_VISION };

function pickResponse(prompt, hasImage) {
  if (hasImage) return R_VISION;
  const p = (prompt || "");
  if (/اخبار|خلاصه|news/i.test(p)) return R_NEWS;
  if (/ایمیل|email|نامه/i.test(p)) return R_EMAIL;
  if (/کد|code|پایتون|python|بهینه/i.test(p)) return R_CODE;
  if (/طرح|پروژه|برنامه|plan|مرحله/i.test(p)) return R_PLAN;
  return R_GENERIC;
}

// Slight per-model variation so compare mode feels real
function variantFor(base, modelId) {
  const prefixes = {
    "o1": "پس از کمی استدلالِ گام‌به‌گام:\n\n",
    "o1-mini": "خلاصه و سریع:\n\n",
    "deepseek-reasoner": "مرحله‌به‌مرحله فکر کردم؛ نتیجه:\n\n",
    "claude-3-5-haiku-latest": "کوتاه و مفید:\n\n",
    "gemini-1.5-flash-latest": "سریع پاسخ می‌دهم:\n\n",
  };
  return (prefixes[modelId] || "") + base;
}

// ── tiny markdown → HTML (paragraphs, headings, lists, bold, code) ──
function esc(s){ return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }

function inlineMd(s) {
  s = esc(s);
  s = s.replace(/`([^`]+)`/g, '<code>$1</code>');
  s = s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  s = s.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>');
  return s;
}

function highlightCode(code) {
  let h = esc(code);
  // comments
  h = h.replace(/(#.*$)/gm, '<span class="tok-c">$1</span>');
  // strings
  h = h.replace(/('[^']*'|"[^"]*")/g, '<span class="tok-s">$1</span>');
  // keywords
  h = h.replace(/\b(def|return|for|in|if|else|import|from|class|while|with|as|lambda|None|True|False|out)\b/g, '<span class="tok-k">$1</span>');
  // numbers
  h = h.replace(/\b(\d+)\b/g, '<span class="tok-n">$1</span>');
  return h;
}

function mdToHtml(md) {
  const out = [];
  const lines = md.split("\n");
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    // code fence
    if (/^```/.test(line)) {
      const buf = [];
      i++;
      while (i < lines.length && !/^```/.test(lines[i])) { buf.push(lines[i]); i++; }
      i++;
      out.push('<pre><button class="copy-code">کپی</button><code>' + highlightCode(buf.join("\n")) + '</code></pre>');
      continue;
    }
    // headings
    let m;
    if ((m = line.match(/^###\s+(.*)/))) { out.push('<h3>' + inlineMd(m[1]) + '</h3>'); i++; continue; }
    if ((m = line.match(/^##\s+(.*)/)))  { out.push('<h2>' + inlineMd(m[1]) + '</h2>'); i++; continue; }
    // blockquote
    if (/^>\s?/.test(line)) {
      const buf = [];
      while (i < lines.length && /^>\s?/.test(lines[i])) { buf.push(lines[i].replace(/^>\s?/, "")); i++; }
      out.push('<blockquote>' + inlineMd(buf.join(" ")) + '</blockquote>');
      continue;
    }
    // list
    if (/^[-*]\s+/.test(line)) {
      const buf = [];
      while (i < lines.length && /^[-*]\s+/.test(lines[i])) { buf.push(lines[i].replace(/^[-*]\s+/, "")); i++; }
      out.push('<ul>' + buf.map((b) => '<li>' + inlineMd(b) + '</li>').join("") + '</ul>');
      continue;
    }
    // blank
    if (/^\s*$/.test(line)) { i++; continue; }
    // paragraph (gather until blank)
    const buf = [line];
    i++;
    while (i < lines.length && !/^\s*$/.test(lines[i]) && !/^(```|#|>|[-*]\s)/.test(lines[i])) { buf.push(lines[i]); i++; }
    out.push('<p>' + inlineMd(buf.join(" ")) + '</p>');
  }
  return out.join("");
}

// ── Seed conversations ───────────────────────────────────────────
const SEED_CONVERSATIONS = [
  {
    id: "c1", title: "خلاصه‌ی اخبار هوش مصنوعی", provider: "anthropic", model: "claude-3-5-sonnet-latest",
    system: "", pinned: true, archived: false, updatedAt: "۲ ساعت پیش",
    messages: [
      { role: "user", content: "یک خلاصه‌ی فارسی از مهم‌ترین اخبار هوش مصنوعی این هفته بنویس" },
      { role: "assistant", content: R_NEWS, provider: "anthropic", model: "Claude 3.5 Sonnet", tokens: 412 },
    ],
  },
  {
    id: "c2", title: "بازنویسیِ تابعِ گروه‌بندی", provider: "openai", model: "gpt-4o",
    system: "تو یک مهندس نرم‌افزار ارشد هستی. کد تمیز با توضیح کوتاه بده.",
    pinned: true, archived: false, updatedAt: "دیروز",
    messages: [
      { role: "user", content: "این کد پایتون را بهینه کن و توضیح بده چه تغییری دادی" },
      { role: "assistant", content: R_CODE, provider: "openai", model: "GPT-4o", tokens: 286 },
    ],
  },
  {
    id: "c3", title: "ایمیلِ پیگیریِ همکاری", provider: "google", model: "gemini-1.5-pro-latest",
    system: "", pinned: false, archived: false, updatedAt: "دیروز",
    messages: [
      { role: "user", content: "یک ایمیل حرفه‌ای برای پیگیری پیشنهادِ همکاری بنویس" },
      { role: "assistant", content: R_EMAIL, provider: "google", model: "Gemini 1.5 Pro", tokens: 198 },
    ],
  },
  {
    id: "c4", title: "طرحِ چت‌باتِ سازمانی", provider: "deepseek", model: "deepseek-reasoner",
    system: "", pinned: false, archived: false, updatedAt: "۳ روز پیش",
    messages: [
      { role: "user", content: "یک طرح پروژه‌ی سه‌مرحله‌ای برای راه‌اندازی یک چت‌بات سازمانی بده" },
      { role: "assistant", content: variantFor(R_PLAN, "deepseek-reasoner"), provider: "deepseek", model: "DeepSeek R1", tokens: 524 },
    ],
  },
  {
    id: "c5", title: "بررسیِ پالتِ رنگِ برند", provider: "xai", model: "grok-2-vision-latest",
    system: "", pinned: false, archived: false, updatedAt: "۵ روز پیش",
    messages: [
      { role: "user", content: "به این تصویرِ موکاپ نگاه کن و درباره‌ی ترکیب رنگ نظر بده", image: true },
      { role: "assistant", content: R_VISION, provider: "xai", model: "Grok 2 Vision", tokens: 167 },
    ],
  },
  {
    id: "c6", title: "مقایسه‌ی لحنِ پاسخ مدل‌ها", provider: "mistral", model: "mistral-large-latest",
    system: "", pinned: false, archived: false, updatedAt: "۱ هفته پیش",
    messages: [
      { role: "user", content: "تفاوتِ لحنِ مدل‌های مختلف در پاسخ‌دهیِ فارسی چیست؟" },
      { role: "assistant", content: R_GENERIC, provider: "mistral", model: "Mistral Large", tokens: 231 },
    ],
  },
  {
    id: "a1", title: "یادداشتِ جلسه‌ی محصول (قدیمی)", provider: "openai", model: "gpt-4o-mini",
    system: "", pinned: false, archived: true, updatedAt: "۲ هفته پیش",
    messages: [
      { role: "user", content: "خلاصه‌ی این یادداشت‌ها را در سه بند بنویس" },
      { role: "assistant", content: R_GENERIC, provider: "openai", model: "GPT-4o mini", tokens: 142 },
    ],
  },
  {
    id: "a2", title: "تستِ Ollama محلی", provider: "ollama", model: "llama3.2",
    system: "", pinned: false, archived: true, updatedAt: "۳ هفته پیش",
    messages: [
      { role: "user", content: "سلام، تو محلی اجرا می‌شوی؟" },
      { role: "assistant", content: "بله، من به‌صورتِ محلی روی همین ماشین اجرا می‌شوم و هیچ داده‌ای به سرورِ بیرونی نمی‌رود.", provider: "ollama", model: "Llama 3.2", tokens: 38 },
    ],
  },
];

Object.assign(window, {
  PROVIDERS, PROVIDER_COLORS, SEED_CONVERSATIONS, STARTERS, SYS_PRESETS,
  SIM_RESPONSES, mdToHtml, findModel, pickResponse, variantFor,
});
