/* ══════════════════════════════════════════════════════════════
   Divband Chat prototype — app root
   ══════════════════════════════════════════════════════════════ */
const { useState: aUseState, useEffect: aUseEffect, useMemo: aUseMemo } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#1e3a8a",
  "density": "comfortable",
  "msgWidth": 880
}/*EDITMODE-END*/;

const USER = { name: "نگار مرادی", email: "negar@divband.com" };

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [convs, setConvs] = aUseState(() => window.SEED_CONVERSATIONS.map((c) => ({ ...c, messages: c.messages.slice() })));
  const [activeId, setActiveId] = aUseState("c1");
  const [view, setView] = aUseState("chat"); // chat | compare
  const [query, setQuery] = aUseState("");
  const [newKey, setNewKey] = aUseState(0); // forces fresh empty conv

  // apply tweaks → CSS vars
  aUseEffect(() => {
    const r = document.documentElement.style;
    r.setProperty("--accent", t.accent);
    const c = t.accent.replace("#", "");
    const rr = parseInt(c.slice(0,2),16), gg = parseInt(c.slice(2,4),16), bb = parseInt(c.slice(4,6),16);
    r.setProperty("--accent-3", `rgba(${rr},${gg},${bb},0.08)`);
    r.setProperty("--msg-width", t.msgWidth + "px");
    r.setProperty("--row-pad", t.density === "compact" ? "8px" : t.density === "comfy" ? "18px" : "12px");
  }, [t]);

  const active = aUseMemo(() => convs.find((c) => c.id === activeId), [convs, activeId]);

  function patch(id, p) {
    setConvs((cur) => cur.map((c) => {
      if (c.id !== id) return c;
      const next = { ...c };
      if (p.messages) next.messages = p.messages;
      if (p.provider) next.provider = p.provider;
      if (p.model) next.model = p.model;
      if (p.title !== undefined) next.title = p.title;
      if (p.system !== undefined) next.system = p.system;
      if (p.newTitle) next.title = p.newTitle;
      next.updatedAt = "همین حالا";
      return next;
    }));
  }

  function newConv() {
    const id = "n" + (newKey + 1);
    setNewKey((k) => k + 1);
    const fresh = { id, title: "گفت‌وگوی جدید", provider: "anthropic", model: "claude-3-5-sonnet-latest", system: "", pinned: false, archived: false, updatedAt: "همین حالا", messages: [] };
    setConvs((cur) => [fresh, ...cur]);
    setActiveId(id); setView("chat");
  }

  function selectConv(id) { setActiveId(id); setView("chat"); }
  function togglePin(id) { setConvs((cur) => cur.map((c) => c.id === id ? { ...c, pinned: !c.pinned } : c)); }
  function toggleArchive(id) { setConvs((cur) => cur.map((c) => c.id === id ? { ...c, archived: !c.archived } : c)); }
  function deleteConv(id) {
    setConvs((cur) => cur.filter((c) => c.id !== id));
    if (activeId === id) { const left = convs.filter((c) => c.id !== id && !c.archived); setActiveId(left[0] ? left[0].id : null); }
  }

  // compare → continue: create a new conversation seeded with the picked answer
  function continueFromCompare(slot, question) {
    const id = "cmp" + Date.now();
    const { m } = window.findModel(slot.provider, slot.model);
    const conv = {
      id, title: question.slice(0, 30) || "ادامه از مقایسه",
      provider: slot.provider, model: slot.model, system: "", pinned: false, archived: false, updatedAt: "همین حالا",
      messages: [
        { role: "user", content: question },
        { role: "assistant", content: slot.content, provider: slot.provider, model: m.label, tokens: slot.tokens },
      ],
    };
    setConvs((cur) => [conv, ...cur]);
    setActiveId(id); setView("chat");
  }

  return (
    <Toaster>
      <div className="shell">
        <Sidebar
          convs={convs} activeId={view === "compare" ? null : activeId}
          onSelect={selectConv} onNew={newConv} onCompare={() => setView("compare")}
          query={query} setQuery={setQuery}
          onPin={togglePin} onArchive={toggleArchive} onDelete={deleteConv}
          user={USER} />
        {view === "compare" ? (
          <CompareView onExit={() => setView("chat")} onContinue={continueFromCompare} />
        ) : active ? (
          <ChatView key={active.id} conv={active} onPatch={patch} />
        ) : (
          <main className="main">
            <div className="empty-state">
              <div className="empty-mark">◇</div>
              <div className="empty-title">گفت‌وگویی انتخاب نشده</div>
              <div className="empty-sub">از نوار کناری یک گفت‌وگو انتخاب کن یا یکی تازه بساز.</div>
            </div>
          </main>
        )}
      </div>

      <TweaksPanel title="Tweaks">
        <TweakSection label="ظاهر" />
        <TweakColor label="رنگِ تأکیدی" value={t.accent}
          options={["#1e3a8a", "#1f6d5b", "#9a3b6e", "#7a4bd1"]}
          onChange={(v) => setTweak("accent", v)} />
        <TweakRadio label="تراکم" value={t.density}
          options={["compact", "comfortable", "comfy"]}
          onChange={(v) => setTweak("density", v)} />
        <TweakSlider label="پهنای ستونِ پیام" value={t.msgWidth} min={680} max={1040} step={20} unit="px"
          onChange={(v) => setTweak("msgWidth", v)} />
      </TweaksPanel>
    </Toaster>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
