/* ══════════════════════════════════════════════════════════════
   Divband Chat prototype — core chat components
   Exports to window: Toaster, useToast, ModelPicker, MessageRow,
                      Sidebar, ChatView
   ══════════════════════════════════════════════════════════════ */
const { useState, useRef, useEffect, useCallback, createContext, useContext } = React;

/* ── Toasts ──────────────────────────────────────────────────── */
const ToastCtx = createContext(() => {});
const useToast = () => useContext(ToastCtx);
function Toaster({ children }) {
  const [toasts, setToasts] = useState([]);
  const push = useCallback((msg, mono) => {
    const id = Math.random();
    setToasts((t) => [...t, { id, msg, mono }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2200);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="toast-host">
        {toasts.map((t) => (
          <div key={t.id} className="toast"><span>{t.msg}</span>{t.mono && <span className="mono">{t.mono}</span>}</div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

/* ── Markdown body ───────────────────────────────────────────── */
function Body({ md }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    el.querySelectorAll("pre .copy-code").forEach((b) => {
      b.onclick = () => {
        const code = b.parentElement.querySelector("code");
        navigator.clipboard?.writeText(code ? code.innerText : "").catch(() => {});
        b.textContent = "کپی شد ✓";
        setTimeout(() => (b.textContent = "کپی"), 1200);
      };
    });
  });
  return <div className="body" ref={ref} dangerouslySetInnerHTML={{ __html: window.mdToHtml(md) }} />;
}

/* ── Model picker (custom dropdown) ──────────────────────────── */
function ModelPicker({ provider, model, onChange, compact }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const { p, m } = window.findModel(provider, model);
  useEffect(() => {
    const h = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  return (
    <div className="model-picker" ref={ref} onClick={() => setOpen((o) => !o)}>
      <span className="prov-dot" style={{ background: window.PROVIDER_COLORS[p.id] }}></span>
      <span>{m.label}</span>
      {m.vision && <span className="vbadge">vision</span>}
      <span className="caret">▾</span>
      {open && (
        <div className="mp-menu" onClick={(e) => e.stopPropagation()}>
          {window.PROVIDERS.map((pr) => (
            <div key={pr.id}>
              <div className="mp-prov">
                <span className="prov-dot" style={{ background: window.PROVIDER_COLORS[pr.id] }}></span>
                {pr.label}
              </div>
              {pr.models.map((mo) => (
                <div
                  key={mo.id}
                  className={"mp-model" + (pr.id === provider && mo.id === model ? " sel" : "")}
                  onClick={() => { onChange(pr.id, mo.id); setOpen(false); }}
                >
                  <span>{mo.label}</span>
                  {mo.vision && <span className="tag vis">vision</span>}
                  {mo.reasoning && <span className="tag rea">reasoning</span>}
                  {mo.context && <span className="ctx">{mo.context}</span>}
                </div>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ── Message row ─────────────────────────────────────────────── */
function MessageRow({ m, streaming, onRegenerate }) {
  const isUser = m.role === "user";
  const toast = useToast();
  return (
    <div className={"msg " + m.role}>
      <div className="avatar">{isUser ? "شما" : "AI"}</div>
      <div style={{ minWidth: 0 }}>
        <div className="meta-line">
          <span>{isUser ? "پیامِ شما" : (m.model || "دستیار")}</span>
          {!isUser && m.tokens && <span className="tok">{m.tokens} توکن</span>}
        </div>

        {m.image && (
          <div className="msg-img"><div className="ph">image · موکاپ.png</div></div>
        )}
        {m.attachments && m.attachments.length > 0 && (
          <div className="attach-chips">
            {m.attachments.map((a, i) => <span key={i} className="attach-chip">📎 {a.name}</span>)}
          </div>
        )}

        {isUser ? (
          <div className="body"><p style={{ whiteSpace: "pre-wrap" }}>{m.content}</p></div>
        ) : streaming && !m.content ? (
          <div className="body"><div className="dot-typing"><span /><span /><span /></div></div>
        ) : (
          <Body md={m.content} />
        )}

        {!isUser && !streaming && m.content && (
          <div className="msg-actions">
            <button onClick={() => { navigator.clipboard?.writeText(m.content).catch(()=>{}); toast("متن کپی شد"); }}>⧉ کپی</button>
            <button onClick={() => onRegenerate && onRegenerate()}>↻ تولید دوباره</button>
            <button onClick={() => toast("پاسخ پسندیده شد", "feedback")}>♡ پسندیدم</button>
          </div>
        )}
      </div>
    </div>
  );
}

/* ── Sidebar ─────────────────────────────────────────────────── */
function hl(text, q) {
  if (!q) return text;
  const idx = text.toLowerCase().indexOf(q.toLowerCase());
  if (idx < 0) return text;
  return (<>{text.slice(0, idx)}<mark>{text.slice(idx, idx + q.length)}</mark>{text.slice(idx + q.length)}</>);
}

function Sidebar({ convs, activeId, onSelect, onNew, onCompare, query, setQuery, onPin, onArchive, onDelete, user }) {
  const [tab, setTab] = useState("chats"); // chats | archive

  const q = query.trim();
  const matches = (c) => {
    if (!q) return true;
    if (c.title.toLowerCase().includes(q.toLowerCase())) return true;
    return c.messages.some((m) => m.content.toLowerCase().includes(q.toLowerCase()));
  };
  const inView = convs.filter((c) => (tab === "archive" ? c.archived : !c.archived)).filter(matches);
  const pinned = inView.filter((c) => c.pinned);
  const rest = inView.filter((c) => !c.pinned);

  const Item = (c) => {
    const { p } = window.findModel(c.provider, c.model);
    return (
      <a key={c.id} className={"conv-item" + (c.id === activeId ? " active" : "")}
         onClick={(e) => { e.preventDefault(); onSelect(c.id); }}>
        <span className="title">
          {c.pinned && tab === "chats" && <span className="pin-ico">📌</span>}
          {hl(c.title, q)}
        </span>
        <span className="meta">{c.provider} · {window.findModel(c.provider, c.model).m.label}</span>
        <span className="conv-actions" onClick={(e) => e.preventDefault()}>
          {tab === "chats" && (
            <button className={c.pinned ? "pinned" : ""} title={c.pinned ? "برداشتنِ pin" : "pin"}
                    onClick={(e) => { e.stopPropagation(); onPin(c.id); }}>📌</button>
          )}
          <button title={c.archived ? "بازگردانی" : "آرشیو"}
                  onClick={(e) => { e.stopPropagation(); onArchive(c.id); }}>{c.archived ? "↩" : "▢"}</button>
          <button className="del" title="حذف" onClick={(e) => { e.stopPropagation(); onDelete(c.id); }}>×</button>
        </span>
      </a>
    );
  };

  return (
    <aside className="sidebar">
      <div className="sidebar-head">
        <a className="sidebar-brand" onClick={(e) => { e.preventDefault(); onNew(); }}>
          <span className="mark">◇</span>
          <div className="word">DIVBAND<span className="sub">/chat</span></div>
        </a>
        <button className="icon-btn" title="حالتِ مقایسه" onClick={onCompare}>⊟</button>
      </div>

      <button className="new-conv-btn" onClick={onNew}>+ گفت‌وگوی جدید</button>

      <div className="side-search">
        <span className="ico">⌕</span>
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="جست‌وجو در عنوان و متنِ پیام‌ها…" />
        <button className={"clr" + (query ? " show" : "")} onClick={() => setQuery("")}>×</button>
      </div>

      <div className="side-tabs">
        <button className={tab === "chats" ? "active" : ""} onClick={() => setTab("chats")}>
          گفت‌وگوها
        </button>
        <button className={tab === "archive" ? "active" : ""} onClick={() => setTab("archive")}>
          آرشیو
        </button>
      </div>

      <div className="conv-list">
        {inView.length === 0 && (
          <div className="side-empty">
            {q ? <>نتیجه‌ای برای «{q}» پیدا نشد.</> : (tab === "archive" ? "آرشیو خالی است." : "هنوز گفت‌وگویی نیست.")}
          </div>
        )}
        {tab === "chats" && pinned.length > 0 && <div className="conv-group-label">سنجاق‌شده</div>}
        {tab === "chats" && pinned.map(Item)}
        {tab === "chats" && pinned.length > 0 && rest.length > 0 && <div className="conv-group-label">اخیر</div>}
        {(tab === "archive" ? inView : rest).map(Item)}
      </div>

      <div className="sidebar-foot">
        <div className="user-chip">
          <div className="name">{user.name}</div>
          <div className="email">{user.email}</div>
        </div>
        <button className="icon-btn" title="خروج">→</button>
      </div>
    </aside>
  );
}

/* ── streaming helper ────────────────────────────────────────── */
function streamText(full, onTick, onDone, speed) {
  let i = 0;
  const step = Math.max(2, Math.round((full.length / 90)));
  const tick = () => {
    i = Math.min(full.length, i + step + Math.floor(Math.random() * 3));
    onTick(full.slice(0, i));
    if (i >= full.length) { onDone(); return; }
    setTimeout(tick, speed || 26);
  };
  setTimeout(tick, 380);
}

/* ── ChatView ────────────────────────────────────────────────── */
function ChatView({ conv, onPatch }) {
  const toast = useToast();
  const [provider, setProvider] = useState(conv.provider);
  const [model, setModel] = useState(conv.model);
  const [messages, setMessages] = useState(conv.messages);
  const [streaming, setStreaming] = useState(false);
  const [input, setInput] = useState("");
  const [title, setTitle] = useState(conv.title);
  const [system, setSystem] = useState(conv.system || "");
  const [sysOpen, setSysOpen] = useState(false);
  const [attachments, setAttachments] = useState([]);
  const [pendingImage, setPendingImage] = useState(false);
  const listRef = useRef(null);
  const taRef = useRef(null);
  const sysRef = useRef(null);

  // sync when conversation switches
  useEffect(() => {
    setProvider(conv.provider); setModel(conv.model);
    setMessages(conv.messages); setTitle(conv.title);
    setSystem(conv.system || ""); setInput(""); setAttachments([]); setPendingImage(false);
  }, [conv.id]);

  useEffect(() => { if (listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight; }, [messages, streaming]);
  useEffect(() => {
    const ta = taRef.current; if (!ta) return;
    ta.style.height = "auto"; ta.style.height = Math.min(280, ta.scrollHeight) + "px";
  }, [input]);
  useEffect(() => {
    const h = (e) => { if (sysRef.current && !sysRef.current.contains(e.target)) setSysOpen(false); };
    document.addEventListener("mousedown", h); return () => document.removeEventListener("mousedown", h);
  }, []);

  const { m: modelMeta } = window.findModel(provider, model);

  function commit(next) { setMessages(next); onPatch(conv.id, { messages: next, provider, model, title, system }); }

  function send(text) {
    const content = (text ?? input).trim();
    if ((!content && !pendingImage) || streaming) return;
    const hadImage = pendingImage;
    const userMsg = { role: "user", content: content || "(تصویر پیوست شد)", image: hadImage, attachments: attachments.length ? attachments : undefined };
    const aiMsg = { role: "assistant", content: "", provider, model, modelLabel: modelMeta.label };
    const base = [...messages, userMsg, aiMsg];
    setMessages(base);
    setInput(""); setAttachments([]); setPendingImage(false);
    setStreaming(true);
    const full = window.pickResponse(content, hadImage);
    streamText(full, (partial) => {
      setMessages((cur) => { const n = cur.slice(); n[n.length - 1] = { ...n[n.length - 1], content: partial }; return n; });
    }, () => {
      setStreaming(false);
      setMessages((cur) => {
        const n = cur.slice();
        n[n.length - 1] = { ...n[n.length - 1], model: modelMeta.label, tokens: 120 + Math.floor(Math.random() * 380) };
        onPatch(conv.id, { messages: n, provider, model, title, system, newTitle: messages.length === 0 ? content.slice(0, 32) : undefined });
        return n;
      });
    });
  }

  function regenerate() {
    if (streaming) return;
    // find last user message
    let lastUser = null;
    for (let k = messages.length - 1; k >= 0; k--) if (messages[k].role === "user") { lastUser = messages[k]; break; }
    if (!lastUser) return;
    const trimmed = messages.slice(0, messages.length - 1); // drop last assistant
    const aiMsg = { role: "assistant", content: "", provider, model };
    setMessages([...trimmed, aiMsg]);
    setStreaming(true);
    const full = window.variantFor(window.pickResponse(lastUser.content, lastUser.image), model);
    streamText(full, (partial) => {
      setMessages((cur) => { const n = cur.slice(); n[n.length - 1] = { ...n[n.length - 1], content: partial }; return n; });
    }, () => {
      setStreaming(false);
      setMessages((cur) => { const n = cur.slice(); n[n.length-1] = { ...n[n.length-1], model: modelMeta.label, tokens: 120 + Math.floor(Math.random()*380) }; return n; });
    });
  }

  const empty = messages.length === 0;

  return (
    <main className="main">
      <div className="main-head">
        <div className="head-title">
          {empty ? <span>گفت‌وگوی جدید</span> : (
            <input value={title}
                   onChange={(e) => setTitle(e.target.value)}
                   onBlur={() => onPatch(conv.id, { title })}
                   onKeyDown={(e) => { if (e.key === "Enter") e.target.blur(); }} />
          )}
        </div>
        <ModelPicker provider={provider} model={model}
          onChange={(p, m) => { setProvider(p); setModel(m); onPatch(conv.id, { provider: p, model: m }); }} />
        <div className="head-actions">
          <button className="icon-btn" title="خروجی Markdown" onClick={() => toast("خروجی Markdown دانلود شد", title + ".md")}>MD</button>
          <button className="icon-btn" title="خروجی JSON" onClick={() => toast("خروجی JSON دانلود شد", title + ".json")}>JSON</button>
        </div>
      </div>

      <div className="msg-list" ref={listRef}>
        {empty ? (
          <div className="empty-state">
            <div className="empty-mark">◇</div>
            <div className="empty-title">با چه چیزی می‌توانم کمک کنم؟</div>
            <div className="empty-sub">یکی از پیشنهادهای زیر را انتخاب کنید، یا سؤالِ خودتان را تایپ کنید. می‌توانید فایلِ PDF، متن یا تصویر هم پیوست کنید.</div>
            <div className="empty-grid">
              {window.STARTERS.map((s) => (
                <button key={s.text} className="empty-card" onClick={() => send(s.text)}>
                  <span className="ec-tag">{s.tag}</span>
                  <span>{s.text}</span>
                </button>
              ))}
            </div>
          </div>
        ) : messages.map((m, i) => (
          <MessageRow key={i} m={m}
            streaming={streaming && i === messages.length - 1 && m.role === "assistant"}
            onRegenerate={i === messages.length - 1 ? regenerate : null} />
        ))}
      </div>

      <div className="composer-wrap">
        <div className="composer-inner">
          {(attachments.length > 0 || pendingImage) && (
            <div className="attach-chips" style={{ marginBottom: 8 }}>
              {pendingImage && (
                <span className="attach-chip img">
                  <span className="thumb"></span> موکاپ.png
                  <span className="x" onClick={() => setPendingImage(false)}>×</span>
                </span>
              )}
              {attachments.map((a, i) => (
                <span key={i} className="attach-chip">📎 {a.name}
                  <span className="x" onClick={() => setAttachments((c) => c.filter((_, j) => j !== i))}>×</span>
                </span>
              ))}
            </div>
          )}
          <div className="composer">
            <textarea ref={taRef} value={input} rows={1}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
              placeholder="پیامتان را بنویسید… (Shift+Enter برای خط جدید)" />
            <div className="composer-row">
              <button className="composer-btn" title="پیوست PDF یا متن"
                onClick={() => { setAttachments((a) => [...a, { name: "گزارش.pdf" }]); toast("فایل ضمیمه شد", "PDF · ۲ صفحه"); }}>📎 پیوست</button>
              <button className={"composer-btn" + (pendingImage ? " on" : "")} title="پیوست تصویر (مدل‌های vision)"
                disabled={!modelMeta.vision}
                style={!modelMeta.vision ? { opacity: .4, cursor: "not-allowed" } : null}
                onClick={() => { if (modelMeta.vision) { setPendingImage(true); toast("تصویر ضمیمه شد", "vision"); } }}>🖼 تصویر</button>
              <div className="composer-btn" ref={sysRef} style={{ position: "relative" }}
                   onClick={() => setSysOpen((o) => !o)}>
                <span>⚙ سیستم{system ? " •" : ""}</span>
                {sysOpen && (
                  <div className="sys-pop" onClick={(e) => e.stopPropagation()}>
                    <div className="lbl">System prompt (اختیاری)</div>
                    <textarea value={system} onChange={(e) => setSystem(e.target.value)}
                      placeholder="مثلاً: شما یک مشاور حقوقی هستی؛ پاسخ‌ها مختصر و رسمی باشد." />
                    <div className="sys-presets">
                      {window.SYS_PRESETS.map((p) => (
                        <button key={p.label} className="sys-preset" onClick={() => setSystem(p.text)}>{p.label}</button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              {!modelMeta.vision && (
                <span className="cmp-meta" style={{ fontFamily: "var(--mono)", fontSize: 10 }}>این مدل تصویر نمی‌پذیرد</span>
              )}
              <div className="grow"></div>
              <button className="send-btn" onClick={() => send()} disabled={streaming || (!input.trim() && !pendingImage)}>
                {streaming ? "در حال پاسخ…" : "ارسال ↵"}
              </button>
            </div>
          </div>
          <div className="composer-foot">مدل‌ها ممکن است اشتباه کنند. اطلاعات حساس را با احتیاط ارسال کنید.</div>
        </div>
      </div>
    </main>
  );
}

Object.assign(window, { Toaster, useToast, ModelPicker, MessageRow, Sidebar, ChatView, Body, streamText });
