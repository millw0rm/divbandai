/* ══════════════════════════════════════════════════════════════
   Divband Chat prototype — Compare Mode (v1.2)
   One question → 2–3 models side by side. Pick the best to continue.
   Exports to window: CompareView
   ══════════════════════════════════════════════════════════════ */
const { useState: cUseState, useRef: cUseRef, useEffect: cUseEffect } = React;

function CmpColumn({ slot, onSwap, onPick, picked, anyPicked }) {
  const { p, m } = window.findModel(slot.provider, slot.model);
  const ref = cUseRef(null);
  cUseEffect(() => {
    const el = ref.current; if (!el) return;
    el.querySelectorAll("pre .copy-code").forEach((b) => {
      b.onclick = () => { const c = b.parentElement.querySelector("code"); navigator.clipboard?.writeText(c ? c.innerText : ""); b.textContent = "کپی شد ✓"; setTimeout(() => b.textContent = "کپی", 1000); };
    });
  });
  return (
    <div className={"cmp-col" + (picked ? " best" : "")}>
      <div className="cmp-col-head">
        <span className="prov-dot" style={{ background: window.PROVIDER_COLORS[p.id] }}></span>
        <span className="nm">{m.label}</span>
        <span className="ctx">{m.context || "local"}</span>
        <div className="swap">
          <div className="head-actions">
            <ModelPickerSwap provider={slot.provider} model={slot.model} onChange={onSwap} />
          </div>
        </div>
      </div>
      <div className="cmp-col-body">
        {slot.streaming && !slot.content ? (
          <div className="dot-typing"><span /><span /><span /></div>
        ) : slot.content ? (
          <div className="body" ref={ref} dangerouslySetInnerHTML={{ __html: window.mdToHtml(slot.content) }} />
        ) : (
          <div className="cmp-meta">منتظرِ سؤال…</div>
        )}
      </div>
      <div className="cmp-col-foot">
        <button className={"cmp-pick" + (picked ? " picked" : "")}
          disabled={!slot.content || slot.streaming}
          style={(!slot.content || slot.streaming) ? { opacity: .4, cursor: "not-allowed" } : null}
          onClick={onPick}>
          {picked ? "✓ بهترین — ادامه با این" : "انتخابِ این پاسخ"}
        </button>
        {slot.tokens ? <span className="cmp-meta">{slot.tokens} توکن · {slot.ms}ms</span> : null}
      </div>
    </div>
  );
}

// lightweight inline picker reusing the main one but compact
function ModelPickerSwap({ provider, model, onChange }) {
  return <ModelPicker provider={provider} model={model} onChange={onChange} compact />;
}

function CompareView({ onExit, onContinue }) {
  const toast = window.useToast();
  const [prompt, setPrompt] = cUseState("");
  const [asked, setAsked] = cUseState("");
  const [running, setRunning] = cUseState(false);
  const [picked, setPicked] = cUseState(-1);
  const [slots, setSlots] = cUseState([
    { provider: "anthropic", model: "claude-3-5-sonnet-latest", content: "", streaming: false, tokens: 0, ms: 0 },
    { provider: "openai",    model: "gpt-4o",                   content: "", streaming: false, tokens: 0, ms: 0 },
    { provider: "google",    model: "gemini-1.5-pro-latest",    content: "", streaming: false, tokens: 0, ms: 0 },
  ]);
  const taRef = cUseRef(null);

  function setSlot(i, patch) { setSlots((cur) => { const n = cur.slice(); n[i] = { ...n[i], ...patch }; return n; }); }

  function run(text) {
    const content = (text ?? prompt).trim();
    if (!content || running) return;
    setAsked(content); setPrompt(""); setPicked(-1); setRunning(true);
    const base = window.pickResponse(content, false);
    let remaining = slots.length;
    slots.forEach((s, i) => {
      setSlot(i, { content: "", streaming: true, tokens: 0, ms: 0 });
      const full = window.variantFor(base, s.model);
      const t0 = performance.now();
      // each model streams at a slightly different speed
      const speed = 20 + Math.floor(Math.random() * 26);
      window.streamText(full, (partial) => setSlot(i, { content: partial }), () => {
        setSlot(i, { streaming: false, tokens: 110 + Math.floor(Math.random() * 420), ms: Math.round(performance.now() - t0) });
        remaining--; if (remaining === 0) setRunning(false);
      }, speed);
    });
  }

  function addColumn() {
    if (slots.length >= 3) return;
    setSlots((cur) => [...cur, { provider: "deepseek", model: "deepseek-chat", content: "", streaming: false, tokens: 0, ms: 0 }]);
  }
  function removeColumn() { if (slots.length > 2) setSlots((cur) => cur.slice(0, -1)); }

  function pick(i) {
    setPicked(i);
    const s = slots[i];
    const { m } = window.findModel(s.provider, s.model);
    toast("بهترین پاسخ انتخاب شد", m.label);
  }

  return (
    <main className="main">
      <div className="main-head">
        <div className="head-title" style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span>حالتِ مقایسه</span>
          <span className="cmp-meta">{slots.length} مدل کنار هم</span>
        </div>
        <div className="head-actions">
          <button className="icon-btn" title="افزودنِ مدل" onClick={addColumn} disabled={slots.length >= 3}
            style={slots.length >= 3 ? { opacity: .4 } : null}>＋</button>
          <button className="icon-btn" title="حذفِ مدل" onClick={removeColumn} disabled={slots.length <= 2}
            style={slots.length <= 2 ? { opacity: .4 } : null}>－</button>
          <button className="icon-btn on" title="خروج از مقایسه" onClick={onExit}>✕</button>
        </div>
      </div>

      {asked && (
        <div className="cmp-banner">
          <span className="cmp-meta">سؤال</span>
          <div className="q">{asked}</div>
        </div>
      )}

      <div className="compare-grid">
        {slots.map((s, i) => (
          <CmpColumn key={i} slot={s} picked={picked === i} anyPicked={picked >= 0}
            onSwap={(p, m) => setSlot(i, { provider: p, model: m })}
            onPick={() => {
              if (picked === i) { onContinue(s, asked); }
              else pick(i);
            }} />
        ))}
      </div>

      <div className="composer-wrap">
        <div className="composer-inner" style={{ maxWidth: 980 }}>
          <div className="composer">
            <textarea ref={taRef} value={prompt} rows={1}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); run(); } }}
              placeholder="یک سؤال بنویس تا هم‌زمان به همه‌ی مدل‌ها ارسال شود…" />
            <div className="composer-row">
              <span className="cmp-meta" style={{ fontFamily: "var(--mono)", fontSize: 11 }}>
                {picked >= 0 ? "روی «ادامه با این» بزن تا گفت‌وگو با مدلِ منتخب ادامه یابد" : "یک پاسخ را به‌عنوانِ بهترین انتخاب کن"}
              </span>
              <div className="grow"></div>
              <button className="send-btn" onClick={() => run()} disabled={running || !prompt.trim()}>
                {running ? "در حال پاسخ…" : "ارسال به همه ↵"}
              </button>
            </div>
          </div>
          <div className="composer-foot">یک سؤال، چند مدل. پاسخِ منتخب را pin کن تا گفت‌وگو را با همان مدل ادامه دهی.</div>
        </div>
      </div>
    </main>
  );
}

Object.assign(window, { CompareView });
